<?php

/**
 * 第三方课程对接插件 — 入口文件
 *
 * 同时实现两个接口（implements 多接口）：
 * - PluginInterface：框架加载、注册、启动、卸载的生命周期
 * - ProductAdapterInterface：商品类型、编辑组件、验证 meta、履约交付
 *
 * 职责：只做注册和委派，具体业务逻辑分布在：
 * - Controllers/  — HTTP 请求处理
 * - Services/     — 业务逻辑（履约、查询合并）
 * - Models/       — Eloquent 模型
 * - views/        — Blade 模板
 * - assets/js/    — 前端交互脚本
 * - routes.php    — 路由定义（无闭包，指向 Controller）
 *
 * 插件无命名空间（入口文件），子模块使用命名空间（ThirdParty\*）。
 * 不走 Composer autoload，由 register() 手动 require_once 加载。
 */

use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Core\Plugin\FulfillResult;
use App\Core\Contracts\ManualRetryableAdapterInterface;
use App\Core\Contracts\ProductAdapterInterface;
use App\Core\Hook\Hook;
use App\Core\Admin\AdminMenu;
use App\Core\Event\OrderFailed;
use App\Core\Plugin\ManualRetryResult;
use App\Core\Notification\Notification;
use App\Models\PaymentOrder;
use Illuminate\Container\Attributes\Log;

class ThirdPartyPlugin implements PluginInterface, ProductAdapterInterface, ManualRetryableAdapterInterface
{
    /** @var string 插件根目录（在 register 中初始化） */
    private string $pluginPath;

    // ==================== PluginInterface ====================

    public function id(): string
    {
        return 'adapter-thirdparty';
    }
    public function name(): string
    {
        return '第三方课程对接';
    }
    public function version(): string
    {
        return '1.0.0';
    }
    public function type(): PluginType
    {
        return PluginType::ProductAdapter;
    }

    /**
     * 注册阶段：加载子模块、注册视图/菜单/路由
     */
    public function register(): void
    {
        $this->pluginPath = dirname(__FILE__);

        // 加载子模块（插件不走 Composer autoload）
        $this->loadDependencies();

        // 注册视图命名空间：view('adapter-thirdparty::settings')
        app('view')->addNamespace('adapter-thirdparty', $this->pluginPath . '/views');

        // 注册后台菜单（侧边栏只保留一个入口，页面内 Tab 切换设置/订单）
        AdminMenu::add([
            'group' => AdminMenu::GROUP_PRODUCT_ADAPTER,
            'items' => [
                [
                    'label' => '课程对接',
                    'icon'  => 'academic-cap',
                    'route' => 'admin.plugin.adapter-thirdparty',
                    'order' => 51,
                ],
            ],
        ]);

        // 加载路由文件（Controller 类路由，无闭包）
        require $this->pluginPath . '/routes.php';
    }

    /**
     * 启动阶段：注册 Hook + 定时任务
     */
    public function boot(): void
    {
        $this->registerFormHooks();
        $this->registerOrderHooks();
        $this->registerQueryHooks();
        $this->registerDisplayHooks();
        $this->registerScheduledTasks();
    }

    public function uninstall(): void
    {
        AdminMenu::remove('admin.plugin.adapter-thirdparty');
    }

    public function config(): array
    {
        return [
            'api_key'      => '',
            'api_base_url' => '',
            'api_timeout'  => '60',
        ];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }

    // ==================== ProductAdapterInterface ====================

    public function productType(): string
    {
        return 'course';
    }
    public function productTypeLabel(): string
    {
        return '课程代刷';
    }
    public function editorComponent(): string
    {
        return 'third-party-editor';
    }

    /**
     * 验证商品 meta（后台保存商品时调用）
     *
     * 课程商品必须指定 platform_id（对接平台标识）。
     */
    public function validateMeta(array $meta): array
    {
        if (empty($meta['platform_id'])) {
            throw new \InvalidArgumentException('platform_id（平台标识）不能为空');
        }
        return ['platform_id' => trim($meta['platform_id'])];
    }

    /**
     * 履约入口 — 委派给 FulfillService
     */
    public function fulfill(PaymentOrder $order): FulfillResult
    {
        return (new \ThirdParty\Services\FulfillService())->fulfill($order);
    }

    /**
     * 手动重试履约（框架统一入口调用）
     *
     * 约束：
     * - 不允许调用 resetOrder（/api/reset）
     * - 必须走 createOrder（/api/add）重新下单
     */
    public function manualRetry(PaymentOrder $order, array $context = []): ManualRetryResult
    {
        $logger = plugin_context('adapter-thirdparty')->logger();
        $logger->info('开始手动重试下单', [
            'payment_order_id' => $order->id,
            'order_no' => $order->order_no,
            'context' => $context,
        ]);

        $studyOrderId = (int) ($context['study_order_id'] ?? 0);
        if ($studyOrderId <= 0) {
            $logger->warning('手动重试失败：缺少 study_order_id', ['context' => $context]);
            return ManualRetryResult::failure('缺少 study_order_id，上下文不完整');
        }

        $studyOrder = \StudyOrder::whereKey($studyOrderId)
            ->where('payment_order_id', $order->id)
            ->first();
        if (!$studyOrder) {
            $logger->error('手动重试失败：学习订单不存在', [
                'study_order_id' => $studyOrderId,
                'payment_order_id' => $order->id
            ]);
            return ManualRetryResult::failure('学习订单不存在或不属于当前支付订单');
        }

        if ((int) $order->payment_status !== PaymentOrder::STATUS_PAID) {
            $logger->warning('手动重试失败：订单未支付', ['order_no' => $order->order_no]);
            return ManualRetryResult::failure('仅已支付订单支持手动重试');
        }

        if ($studyOrder->order_status !== 'failed' && !(bool) $studyOrder->has_error) {
            $logger->info('手动重试跳过：订单状态非失败', [
                'study_order_id' => $studyOrderId,
                'status' => $studyOrder->order_status
            ]);
            return ManualRetryResult::failure('当前学习订单不是失败状态，无需重试');
        }

        $platformId = (string) ($studyOrder->platform_id ?: ($order->product->meta['platform_id'] ?? ''));
        if ($platformId === '') {
            $studyOrder->update([
                'order_status' => 'failed',
                'has_error' => true,
                'error_message' => '缺少平台标识，无法重试下单',
            ]);
            return ManualRetryResult::failure('缺少平台标识，无法重试下单');
        }

        // 并发认领：只有失败态能切到 processing
        $claimed = \StudyOrder::whereKey($studyOrder->id)
            ->where(function ($q) {
                $q->where('order_status', 'failed')
                    ->orWhere('has_error', true);
            })
            ->update([
                'order_status' => 'processing',
                'has_error' => false,
                'error_message' => null,
                'started_at' => now(),
                'completed_at' => null,
            ]);
        if ($claimed !== 1) {
            $logger->warning('手动重试认领失败：状态已变更', [
                'study_order_id' => $studyOrder->id,
                'status' => $studyOrder->order_status
            ]);
            return ManualRetryResult::failure('该学习订单状态已变化，请刷新后重试');
        }

        $studyOrder->refresh();
        $oldPlatformOrderId = (string) ($studyOrder->platform_order_id ?? '');

        try {
            $logger->info('正在调用第三方 API 下单', [
                'platform' => $platformId,
                'user' => $studyOrder->study_username,
                'course' => $studyOrder->course_name
            ]);

            // 手动重试必须走 createOrder（/api/add），不走 resetOrder。
            $apiResult = (new \SubjectService())->createOrder([
                'platform' => $platformId,
                'user' => (string) $studyOrder->study_username,
                'pass' => (string) $studyOrder->study_password,
                'kcname' => (string) $studyOrder->course_name,
                // platform_course_id 可能是合成值（name:hash），传给 API 时还原为空
                'kcid' => str_starts_with((string) $studyOrder->platform_course_id, 'name:')
                    ? ''
                    : (string) $studyOrder->platform_course_id,
                'school' => (string) ($studyOrder->school_name ?? ''),
            ]);

            $newPlatformOrderId = trim((string) ($apiResult['order_id'] ?? ''));
            if ($newPlatformOrderId === '') {
                throw new \RuntimeException('下单接口未返回平台订单号');
            }

            $logger->info('手动重试下单成功', [
                'study_order_id' => $studyOrder->id,
                'platform_order_id' => $newPlatformOrderId
            ]);

            $studyOrder->update([
                'platform_id' => $platformId,
                'platform_order_id' => $newPlatformOrderId,
                'order_status' => 'processing',
                'has_error' => false,
                'error_message' => null,
                'started_at' => now(),
                'completed_at' => null,
            ]);

            return ManualRetryResult::success('手动重试下单成功，等待进度同步', PaymentOrder::FULFILL_PENDING, [
                'study_order_id' => $studyOrder->id,
                'payment_order_id' => $order->id,
                'platform_order_id_before' => $oldPlatformOrderId,
                'platform_order_id_after' => $newPlatformOrderId,
                'study_order_status' => 'processing',
            ]);
        } catch (\Throwable $e) {
            $logger->error('手动重试下单失败：API 异常', [
                'study_order_id' => $studyOrder->id,
                'error' => $e->getMessage()
            ]);
            $studyOrder->update([
                'order_status' => 'failed',
                'has_error' => true,
                'error_message' => $e->getMessage(),
            ]);

            return ManualRetryResult::failure('手动重试下单失败: ' . $e->getMessage(), PaymentOrder::FULFILL_FAILURE, [
                'study_order_id' => $studyOrder->id,
                'payment_order_id' => $order->id,
                'platform_order_id_before' => $oldPlatformOrderId,
                'platform_order_id_after' => (string) ($studyOrder->platform_order_id ?? ''),
                'study_order_status' => 'failed',
            ]);
        }
    }

    // ==================== 私有方法 ====================

    /**
     * 加载插件子模块依赖
     */
    private function loadDependencies(): void
    {
        $p = $this->pluginPath;

        // Models
        require_once $p . '/Models/StudyOrder.php';

        // Services
        require_once $p . '/SubjectService.php';
        require_once $p . '/Services/FulfillService.php';
        require_once $p . '/Services/QueryService.php';
        require_once $p . '/Services/StatusSyncService.php';

        // Controllers
        require_once $p . '/Controllers/SettingsController.php';
        require_once $p . '/Controllers/CourseController.php';
        require_once $p . '/Controllers/StudyOrderController.php';
    }

    // ==================== Hook 注册分组 ====================

    /**
     * 表单相关 Hook（下单页 UI + 数据验证）
     */
    private function registerFormHooks(): void
    {
        // 后台商品编辑页注入 meta 配置表单（platform_id）
        Hook::addFilter('admin.product.meta_form', function (string $html, string $productType) {
            if ($productType !== $this->productType()) {
                return $html;
            }

            return view('adapter-thirdparty::admin-meta-form')->render();
        }, 10);

        // 渲染课程对接表单 UI（账号/密码/查课/课程选择）
        Hook::addFilter('order_form.adapter_ui', function (string $html, $product) {
            if (($product->product_type ?? '') !== 'course') {
                return $html;
            }
            return $this->renderAdapterForm($product);
        }, 10);

        // 验证用户提交的课程对接数据
        Hook::addFilter('order.validate_adapter_data', function (array $validation, $request, $product) {
            if (($product->product_type ?? '') !== 'course') {
                return $validation;
            }
            return $this->validateAdapterData($validation, $request);
        }, 10);
    }

    /**
     * 订单流程相关 Hook（支付后履约）
     */
    private function registerOrderHooks(): void
    {
        // 支付成功后执行履约
        Hook::addAction('order.after_paid', function (PaymentOrder $order) {
            $this->handleAfterPaid($order);
        }, 10);
    }

    /**
     * 查询相关 Hook（订单查询 + 学习账号反查）
     */
    private function registerQueryHooks(): void
    {
        // 订单查询时附加课程进度数据（API 主数据源 + 本地合并）
        Hook::addFilter('order_query.extra_data', function (array $extraData, PaymentOrder $order) {
            return (new \ThirdParty\Services\QueryService())->appendStudyOrderData($extraData, $order);
        }, 10);

        // 按学习账号反查 PaymentOrder（框架查不到时回退）
        Hook::addFilter('order_query.by_identifier', function (array $orderIds, string $identifier) {
            $ids = \StudyOrder::where('study_username', $identifier)
                ->pluck('payment_order_id')
                ->unique()
                ->toArray();
            return array_merge($orderIds, $ids);
        }, 10);
    }

    /**
     * 展示相关 Hook（类型标签 + 详情页）
     */
    private function registerDisplayHooks(): void
    {
        // 商品类型标签映射
        Hook::addFilter('product.type_label', function (string $label, string $type) {
            return $type === 'course' ? '课程代刷' : $label;
        }, 10);

        Hook::addFilter('product.detail_extra', function (string $html, $product) {
            // 前台不展示对接平台标识，但后台配置、查询和履约逻辑仍继续使用该值。
            return $html;
        }, 10);
    }

    /**
     * 注册定时任务：每天 10:00 同步未完成订单状态
     *
     * 通过 PluginContext::scheduler() 注册 cron 任务，
     * 框架在所有插件 boot 完成后统一注入 Laravel Schedule。
     */
    private function registerScheduledTasks(): void
    {
        plugin_context($this->id())->scheduler()->daily(
            '10:00',
            function () {
                $service = new \ThirdParty\Services\StatusSyncService();
                $result = $service->syncAll();
                plugin_context('adapter-thirdparty')->logger()->info('定时状态同步执行完毕', $result);
            },
            '课程订单状态巡检'
        );
    }

    // ==================== Hook 回调实现 ====================

    /**
     * 渲染下单表单 — 委派给 Blade 视图 + JS 文件
     */
    private function renderAdapterForm($product): string
    {
        $platformId = $product->meta['platform_id'] ?? '';

        return view('adapter-thirdparty::adapter-form', [
            'platformId'   => $platformId,
            'coursesRoute' => route('ajax.plugin.adapter-thirdparty.courses'),
            'unitPrice'    => (float) $product->sale_price,
            'adapterJsUrl' => asset('plugins/ProductAdapter/ThirdParty/assets/js/adapter.js'),
        ])->render();
    }

    /**
     * 验证用户提交的课程对接数据
     */
    private function validateAdapterData(array $validation, $request): array
    {
        $studyUsername = trim($request->input('study_username', ''));
        $studyPassword = $request->input('study_password', '');

        if (empty($studyUsername)) {
            return array_merge($validation, ['valid' => false, 'message' => '请输入学习平台账号']);
        }
        if (empty($studyPassword)) {
            return array_merge($validation, ['valid' => false, 'message' => '请输入学习平台密码']);
        }

        // 验证 course_data 数组
        $courseData = $request->input('course_data', []);
        if (!is_array($courseData) || empty($courseData)) {
            return array_merge($validation, ['valid' => false, 'message' => '请先获取课程列表并选择至少一门课程']);
        }

        plugin_context('adapter-thirdparty')->logger()->debug('清洗前的课程数据', $courseData);
        $cleanedCourses = [];
        foreach ($courseData as $course) {
            // kid 和 kname 至少有一个非空即可（部分课程源只返回其中之一）
            if (empty($course['kid']) && empty($course['kname'])) continue;
            $cleanedCourses[] = [
                'kid'    => trim($course['kid'] ?? ''),
                'kname'  => trim($course['kname'] ?? ''),
                'school' => trim($course['school'] ?? ''),
            ];
        }

        if (empty($cleanedCourses)) {
            plugin_context('adapter-thirdparty')->logger()->error('选择的课程数据无效，请重新选择', $cleanedCourses);
            return array_merge($validation, ['valid' => false, 'message' => '选择的课程数据无效，请重新选择']);
        }

        $validation['adapter_data'] = [
            'study_username' => $studyUsername,
            'study_password' => $studyPassword,
            'course_data'    => $cleanedCourses,
            'course_count'   => count($cleanedCourses),
            'school_name'    => trim($request->input('school_name', '')),
        ];

        return $validation;
    }

    /**
     * 支付成功后处理履约
     *
     * fulfill() 只负责“向第三方创建学习订单”：
     * - 全部失败：立即标记为 failure 并派发 OrderFailed（管理员告警）
     * - 有成功（含部分成功）：保持为 pending，等待定时巡检确认最终完成后再派发 OrderFulfilled
     */
    private function handleAfterPaid(PaymentOrder $order): void
    {
        // 幂等保护：已完成/已失败的订单不再重复履约
        if (in_array($order->fulfill_status, [PaymentOrder::FULFILL_SUCCESS, PaymentOrder::FULFILL_FAILURE], true)) {
            plugin_context($this->id())->logger()->warning('跳过重复履约：订单已是终态', [
                'order_no' => $order->order_no,
                'fulfill_status' => $order->fulfill_status,
            ]);
            return;
        }

        $product = $order->product;
        if (!$product || ($product->product_type ?? '') !== 'course') {
            plugin_context($this->id())->logger()->debug('跳过非课程类型订单的履约', [
                'order_no'     => $order->order_no,
                'product_type' => $product->product_type ?? 'null',
            ]);
            return;
        }

        plugin_context($this->id())->logger()->info('开始课程履约', [
            'order_no'     => $order->order_no,
            'product_type' => $product->product_type,
            'product_name' => $product->name,
        ]);

        try {
            $result = $this->fulfill($order);
            $resultData = is_array($result->data) ? $result->data : [];
            $failCount = (int) ($resultData['fail_count'] ?? 0);
            $details = is_array($resultData['details'] ?? null) ? $resultData['details'] : [];
            $hasFailure = !$result->isSuccess() || $failCount > 0;
            $failureDetails = array_values(array_filter($details, static function ($detail) {
                return is_array($detail) && (($detail['status'] ?? '') === 'failed');
            }));
            $failureReasons = Notification::normalizeStringList(array_map(
                static fn(array $detail): string => (string) ($detail['error'] ?? ''),
                $failureDetails
            ));
            $failureSummary = $hasFailure
                ? (
                    $failureReasons !== []
                        ? implode(' | ', $failureReasons)
                        : $result->message
                )
                : null;

            $fulfillStatus = $hasFailure
                ? PaymentOrder::FULFILL_FAILURE
                : PaymentOrder::FULFILL_PENDING;
            $order->update([
                'fulfill_status' => $fulfillStatus,
                'fulfill_data' => array_merge($order->fulfill_data ?? [], [
                    'fulfill_result' => $result->toArray(),
                    'failure_summary' => $failureSummary,
                    'failure_reasons' => $failureReasons,
                ]),
            ]);

            plugin_context($this->id())->logger()->info('课程履约完成', [
                'order_no' => $order->order_no,
                'success' => $result->isSuccess(),
                'has_failure' => $hasFailure,
                'fail_count' => $failCount,
                'message' => $result->message,
                'fulfill_status' => $fulfillStatus,
            ]);

            // 只要存在失败（部分或全部），都告警管理员并记录失败原因
            if ($hasFailure) {
                $totalCourses = max(1, count($details));
                $successCount = max(0, $totalCourses - $failCount);
                $failureType = $successCount > 0 ? 'partial' : 'total';

                plugin_context($this->id())->notifier()->internal(
                    type: 'order.fulfill_failed',
                    subject: "[{$order->order_no}] 课程履约" . ($failureType === 'partial' ? '部分失败' : '全部失败'),
                    body: "订单 {$order->order_no} 共 {$totalCourses} 门课程，成功 {$successCount} 门，失败 {$failCount} 门。"
                        . "\n失败原因: " . ($failureSummary ?: '未知原因'),
                    data: [
                        'order_no' => $order->order_no,
                        'product_name' => $order->product_name,
                        'amount' => (string) $order->final_amount,
                        'notification_email' => $order->notification_email ?? '',
                        'reason' => $failureSummary ?: $result->message,
                        'failure_type' => $failureType,
                        'success_count' => $successCount,
                        'fail_count' => $failCount,
                        'details' => $details,
                    ],
                    options: [
                        'level' => 'error',
                        'tags' => ['order', 'fulfill', $failureType . '-failure', 'internal'],
                        'dedupe_key' => "adapter-thirdparty.fulfill.{$failureType}:{$order->order_no}",
                    ],
                );

                event(new OrderFailed($order, $failureSummary ?: $result->message));
            }
        } catch (\Throwable $e) {
            plugin_context($this->id())->logger()->error('课程履约异常', [
                'order_no' => $order->order_no,
                'error' => $e->getMessage(),
                'exception_class' => get_class($e),
                'file' => $e->getFile() . ':' . $e->getLine(),
                'trace' => $e->getTraceAsString(),
            ]);

            $order->update([
                'fulfill_status' => PaymentOrder::FULFILL_FAILURE,
                'fulfill_data' => array_merge($order->fulfill_data ?? [], [
                    'fulfill_result' => [
                        'success' => false,
                        'message' => '履约异常: ' . $e->getMessage(),
                    ],
                ]),
            ]);

            event(new OrderFailed($order, '履约异常: ' . $e->getMessage()));
        }
    }
}
