<?php

namespace ThirdParty\Controllers;

use App\Helpers\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

/**
 * 前端课程操作控制器
 *
 * 处理查课、刷新进度、补刷等前端 AJAX 请求。
 * 所有方法返回统一 JSON 格式（ApiResponse）。
 */
class CourseController
{
    /**
     * 查询课程列表
     *
     * 前端用户输入账号密码后，调用第三方 API 获取可选课程。
     */
    public function getCourses(Request $request): JsonResponse
    {
        $logger = plugin_context('adapter-thirdparty')->logger();
        $logger->info('前端查课请求', [
            'platform_id' => $request->input('platform_id'),
            'username' => $request->input('username'),
            'has_school' => !empty($request->input('school')),
            'ip' => $request->ip(),
        ]);

        $request->validate([
            'platform_id' => 'required|string|max:50',
            'username'     => 'required|string|max:100',
            'password'     => 'required|string|max:200',
            'school'       => 'nullable|string|max:100',
        ]);

        try {
            // 同一账号+平台 60 秒内不重复查询（缓存课程列表）
            $cacheKey = 'courses:' . md5($request->input('platform_id') . ':' . $request->input('username'));
            $fromCache = Cache::has($cacheKey);
            $result = Cache::remember($cacheKey, 60, function () use ($request, $logger) {
                $logger->debug('课程查询缓存未命中，调用API', [
                    'platform_id' => $request->input('platform_id'),
                    'username' => $request->input('username'),
                ]);
                $service = new \SubjectService();
                return $service->getCourses(
                    $request->input('platform_id'),
                    $request->input('username'),
                    $request->input('password'),
                    $request->input('school')
                );
            });

            $logger->info('前端查课成功', [
                'platform_id' => $request->input('platform_id'),
                'username' => $request->input('username'),
                'course_count' => count($result['courses'] ?? []),
                'from_cache' => $fromCache,
            ]);

            return ApiResponse::success('课程查询成功', $result);
        } catch (\Exception $e) {
            $logger->warning('前端查课失败', [
                'platform_id' => $request->input('platform_id'),
                'username'    => $request->input('username'),
                'error'       => $e->getMessage(),
                'exception_class' => get_class($e),
            ]);
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
     * 刷新单条课程进度
     *
     * 调用第三方 API 获取最新状态，同步更新本地 StudyOrder。
     */
    public function refresh(Request $request): JsonResponse
    {
        $logger = plugin_context('adapter-thirdparty')->logger();
        $logger->info('前端刷新进度请求', [
            'platform_order_id' => $request->input('platform_order_id'),
            'username' => $request->input('username'),
            'ip' => $request->ip(),
        ]);

        $request->validate([
            'platform_order_id' => 'required|string|max:100',
            'username'          => 'required|string|max:100',
        ]);

        try {
            $service = new \SubjectService();
            $result = $service->refreshProgress(
                $request->input('platform_order_id'),
                $request->input('username')
            );

            // 同步更新本地 StudyOrder 状态
            $orderData = $result['order'] ?? null;
            if ($orderData) {
                $studyOrder = \StudyOrder::where('platform_order_id', $request->input('platform_order_id'))->first();
                if ($studyOrder) {
                    $newStatus = \ThirdParty\Services\QueryService::mapApiStatus($orderData['status'] ?? '');
                    $oldStatus = $studyOrder->order_status;
                    if ($newStatus && $newStatus !== $oldStatus) {
                        $studyOrder->update([
                            'order_status' => $newStatus,
                            'completed_at' => $newStatus === 'completed' ? now() : $studyOrder->completed_at,
                        ]);
                        $logger->info('前端刷新：本地StudyOrder状态已更新', [
                            'study_order_id' => $studyOrder->id,
                            'platform_order_id' => $request->input('platform_order_id'),
                            'old_status' => $oldStatus,
                            'new_status' => $newStatus,
                            'api_status_raw' => $orderData['status'] ?? '',
                        ]);
                    } else {
                        $logger->debug('前端刷新：状态未变化，无需更新', [
                            'study_order_id' => $studyOrder->id,
                            'current_status' => $oldStatus,
                            'api_status_raw' => $orderData['status'] ?? '',
                            'mapped_status' => $newStatus,
                        ]);
                    }
                } else {
                    $logger->warning('前端刷新：本地StudyOrder记录不存在', [
                        'platform_order_id' => $request->input('platform_order_id'),
                    ]);
                }
            } else {
                $logger->warning('前端刷新：API未返回订单数据', [
                    'platform_order_id' => $request->input('platform_order_id'),
                    'username' => $request->input('username'),
                ]);
            }

            return ApiResponse::success('进度刷新成功', $result);
        } catch (\Exception $e) {
            $logger->error('前端刷新进度失败', [
                'platform_order_id' => $request->input('platform_order_id'),
                'username' => $request->input('username'),
                'error' => $e->getMessage(),
                'exception_class' => get_class($e),
            ]);
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
     * 补刷/重试失败课程
     *
     * 调用第三方 API 重新下单，重置本地 StudyOrder 状态。
     */
    public function rebrush(Request $request): JsonResponse
    {
        $logger = plugin_context('adapter-thirdparty')->logger();
        $logger->info('前端补刷请求', [
            'platform_order_id' => $request->input('platform_order_id'),
            'username' => $request->input('username'),
            'ip' => $request->ip(),
        ]);

        $request->validate([
            'platform_order_id' => 'required|string|max:100',
            'username'          => 'required|string|max:100',
        ]);

        try {
            $service = new \SubjectService();
            $result = $service->resetOrder(
                $request->input('platform_order_id'),
                $request->input('username')
            );

            // 重置本地 StudyOrder 为处理中
            $studyOrder = \StudyOrder::where('platform_order_id', $request->input('platform_order_id'))->first();
            if ($studyOrder) {
                $oldStatus = $studyOrder->order_status;
                $studyOrder->update([
                    'order_status'  => 'processing',
                    'has_error'     => false,
                    'error_message' => null,
                    'started_at'    => now(),
                ]);
                $logger->info('补刷成功：本地StudyOrder已重置', [
                    'study_order_id' => $studyOrder->id,
                    'platform_order_id' => $request->input('platform_order_id'),
                    'old_status' => $oldStatus,
                    'new_status' => 'processing',
                ]);
            } else {
                $logger->warning('补刷：本地StudyOrder记录不存在', [
                    'platform_order_id' => $request->input('platform_order_id'),
                ]);
            }

            return ApiResponse::success('补刷请求已发送', $result);
        } catch (\Exception $e) {
            $logger->error('补刷请求失败', [
                'platform_order_id' => $request->input('platform_order_id'),
                'username' => $request->input('username'),
                'error' => $e->getMessage(),
                'exception_class' => get_class($e),
            ]);
            return ApiResponse::error($e->getMessage());
        }
    }
}
