<?php

namespace ThirdParty\Services;

use App\Core\Plugin\FulfillResult;
use App\Models\PaymentOrder;
use Illuminate\Database\QueryException;

/**
 * 课程履约服务
 *
 * 遍历 course_data，逐课程调第三方 API 创建 StudyOrder。
 * 单课程失败不影响其他课程（核心设计决策）。
 */
class FulfillService
{
    private string $pluginId = 'adapter-thirdparty';

    /**
     * 执行多课程逐门履约
     *
     * @param PaymentOrder $order 已支付的订单
     * @return FulfillResult 履约结果 DTO
     */
    public function fulfill(PaymentOrder $order): FulfillResult
    {
        $adapterData = $order->fulfill_data['adapter_data'] ?? [];
        $product = $order->product;
        $platformId = $product->meta['platform_id'] ?? '';

        $studyUsername = $adapterData['study_username'] ?? '';
        $studyPassword = $adapterData['study_password'] ?? '';
        $courseData = $adapterData['course_data'] ?? [];
        $schoolName = $adapterData['school_name'] ?? '';

        if (empty($studyUsername) || empty($studyPassword)) {
            $logger = plugin_context($this->pluginId)->logger();
            $logger->error('履约失败：学习账号或密码为空', ['order_no' => $order->order_no]);
            return FulfillResult::failure('学习账号或密码为空');
        }

        if (empty($courseData) || !is_array($courseData)) {
            $logger = plugin_context($this->pluginId)->logger();
            $logger->error('履约失败：课程数据为空', ['order_no' => $order->order_no]);
            return FulfillResult::failure('课程数据为空');
        }

        $service = new \SubjectService();
        $successCount = 0;
        $failCount = 0;
        $results = [];
        $logger = plugin_context($this->pluginId)->logger();

        $logger->info('开始逐课程履约', [
            'order_no' => $order->order_no,
            'platform_id' => $platformId,
            'study_username' => $studyUsername,
            'course_count' => count($courseData),
        ]);

        foreach ($courseData as $course) {
            $courseName = $course['kname'] ?? $product->name;
            $courseId = $course['kid'] ?? '';

            // 幂等：同一支付订单+课程仅允许存在一条 StudyOrder，避免重复回调导致重复履约。
            $existingStudyOrder = \StudyOrder::where('payment_order_id', $order->id)
                ->where('platform_course_id', $courseId)
                ->first();
            if ($existingStudyOrder) {
                $logger->warning('课程履约跳过：发现已存在的学习订单（幂等命中）', [
                    'order_no' => $order->order_no,
                    'course_name' => $courseName,
                    'course_id' => $courseId,
                    'study_order_id' => $existingStudyOrder->id,
                    'existing_status' => $existingStudyOrder->order_status,
                ]);

                $successCount++;
                $results[] = [
                    'course_name' => $courseName,
                    'study_order_id' => $existingStudyOrder->id,
                    'platform_order_id' => $existingStudyOrder->platform_order_id ?? '',
                    'status' => 'skipped_existing',
                ];
                continue;
            }

            try {
                $apiResult = $service->createOrder([
                    'platform' => $platformId,
                    'user'     => $studyUsername,
                    'pass'     => $studyPassword,
                    'kcname'   => $courseName,
                    'kcid'     => $courseId,
                    'school'   => $course['school'] ?? $schoolName,
                ]);

                try {
                    $studyOrder = \StudyOrder::create([
                        'payment_order_id'  => $order->id,
                        'platform_id'       => $platformId,
                        'platform_order_id' => $apiResult['order_id'] ?? '',
                        'platform_course_id' => $courseId,
                        'course_name'       => $courseName,
                        'study_username'    => $studyUsername,
                        'study_password'    => $studyPassword,
                        'school_name'       => $course['school'] ?? $schoolName ?: null,
                        'order_status'      => 'processing',
                        'started_at'        => now(),
                    ]);
                } catch (QueryException $e) {
                    // 命中数据库唯一约束（并发重复），降级为复用既有记录
                    $existingAfterConflict = \StudyOrder::where('payment_order_id', $order->id)
                        ->where('platform_course_id', $courseId)
                        ->first();
                    if ($existingAfterConflict) {
                        $logger->warning('课程履约并发冲突：复用已存在学习订单', [
                            'order_no' => $order->order_no,
                            'course_name' => $courseName,
                            'course_id' => $courseId,
                            'study_order_id' => $existingAfterConflict->id,
                            'db_error' => $e->getMessage(),
                        ]);

                        $successCount++;
                        $results[] = [
                            'course_name' => $courseName,
                            'study_order_id' => $existingAfterConflict->id,
                            'platform_order_id' => $existingAfterConflict->platform_order_id ?? '',
                            'status' => 'skipped_existing',
                        ];
                        continue;
                    }

                    throw $e;
                }

                $successCount++;
                $results[] = [
                    'course_name'       => $courseName,
                    'study_order_id'    => $studyOrder->id,
                    'platform_order_id' => $apiResult['order_id'] ?? '',
                    'status'            => 'success',
                ];

                $logger->info('课程下单成功', [
                    'order_no'          => $order->order_no,
                    'course_name'       => $courseName,
                    'platform_order_id' => $apiResult['order_id'] ?? '',
                ]);

            } catch (\Exception $e) {
                \StudyOrder::create([
                    'payment_order_id'  => $order->id,
                    'platform_id'       => $platformId,
                    'platform_course_id' => $courseId,
                    'course_name'       => $courseName,
                    'study_username'    => $studyUsername,
                    'study_password'    => $studyPassword,
                    'school_name'       => $course['school'] ?? $schoolName ?: null,
                    'order_status'      => 'failed',
                    'has_error'         => true,
                    'error_message'     => $e->getMessage(),
                ]);

                $failCount++;
                $results[] = [
                    'course_name' => $courseName,
                    'status'      => 'failed',
                    'error'       => $e->getMessage(),
                ];

                $logger->error('课程下单失败', [
                    'order_no'    => $order->order_no,
                    'course_name' => $courseName,
                    'error'       => $e->getMessage(),
                ]);
            }
        }

        $totalCourses = count($courseData);

        $logger->info('逐课程履约完成', [
            'order_no' => $order->order_no,
            'total' => $totalCourses,
            'success_count' => $successCount,
            'fail_count' => $failCount,
        ]);

        if ($successCount > 0) {
            $msg = $failCount > 0
                ? "共 {$totalCourses} 门课程，成功 {$successCount} 门，失败 {$failCount} 门"
                : "全部 {$totalCourses} 门课程下单成功";

            if ($failCount > 0) {
                $this->notifyAdminAboutFulfillFailure(
                    order: $order,
                    subject: "[{$order->order_no}] 课程履约部分失败",
                    body: "订单 {$order->order_no} 共 {$totalCourses} 门课程，成功 {$successCount} 门，失败 {$failCount} 门，请检查失败课程。",
                    data: [
                        'reason' => $msg,
                        'failure_type' => 'partial',
                        'success_count' => $successCount,
                        'fail_count' => $failCount,
                        'details' => $results,
                    ],
                    tags: ['order', 'fulfill', 'partial-failure', 'internal'],
                    dedupeKey: "adapter-thirdparty.fulfill.partial:{$order->order_no}",
                );
            }

            return FulfillResult::success($msg, [
                'success_count' => $successCount,
                'fail_count'    => $failCount,
                'details'       => $results,
            ]);
        }

        $this->notifyAdminAboutFulfillFailure(
            order: $order,
            subject: "[{$order->order_no}] 课程履约全部失败",
            body: "订单 {$order->order_no} 共 {$totalCourses} 门课程全部下单失败，请立即检查。",
            data: [
                'reason'       => "全部 {$totalCourses} 门课程下单失败",
                'failure_type' => 'total',
                'fail_count'   => $failCount,
                'details'      => $results,
            ],
            tags: ['order', 'fulfill', 'total-failure', 'internal'],
            dedupeKey: "adapter-thirdparty.fulfill.total:{$order->order_no}",
        );

        return FulfillResult::failure("全部 {$totalCourses} 门课程下单失败", [
            'fail_count' => $failCount,
            'details'    => $results,
        ]);
    }

    /**
     * 统一发送管理员履约告警。
     *
     * ThirdParty 插件通过 plugin_context()->notifier() 获取的是 forSource(pluginId) 后的 Notifier，
     * 因此这里发出的通知会自动带上 source=adapter-thirdparty。
     *
     * @param array<string, mixed> $data
     * @param array<int, string> $tags
     */
    private function notifyAdminAboutFulfillFailure(
        PaymentOrder $order,
        string $subject,
        string $body,
        array $data,
        array $tags,
        string $dedupeKey,
    ): void {
        plugin_context($this->pluginId)->notifier()->internal(
            type: 'order.fulfill_failed',
            subject: $subject,
            body: $body,
            data: array_merge([
                'order_no' => $order->order_no,
                'product_name' => $order->product_name,
                'amount' => (string) $order->final_amount,
                'notification_email' => $order->notification_email ?? '',
            ], $data),
            options: [
                'level' => 'error',
                'tags' => $tags,
                'dedupe_key' => $dedupeKey,
            ],
        );
    }
}
