<?php

namespace ThirdParty\Services;

use App\Core\Plugin\FulfillResult;
use App\Models\PaymentOrder;

/**
 * 课程履约服务
 *
 * 遍历 course_data，逐课程调第三方 API 创建 StudyOrder。
 * 单课程失败不影响其他课程（核心设计决策）。
 */
class FulfillService
{
    private string $pluginId = 'adapter-thirdparty';

    /**
     * 执行多课程逐门履约
     *
     * @param PaymentOrder $order 已支付的订单
     * @return FulfillResult 履约结果 DTO
     */
    public function fulfill(PaymentOrder $order): FulfillResult
    {
        $adapterData = $order->fulfill_data['adapter_data'] ?? [];
        $product = $order->product;
        $platformId = $product->meta['platform_id'] ?? '';

        $studyUsername = $adapterData['study_username'] ?? '';
        $studyPassword = $adapterData['study_password'] ?? '';
        $courseData = $adapterData['course_data'] ?? [];
        $schoolName = $adapterData['school_name'] ?? '';

        if (empty($studyUsername) || empty($studyPassword)) {
            $logger = plugin_context($this->pluginId)->logger();
            $logger->error('履约失败：学习账号或密码为空', ['order_no' => $order->order_no]);
            return FulfillResult::failure('学习账号或密码为空');
        }

        if (empty($courseData) || !is_array($courseData)) {
            $logger = plugin_context($this->pluginId)->logger();
            $logger->error('履约失败：课程数据为空', ['order_no' => $order->order_no]);
            return FulfillResult::failure('课程数据为空');
        }

        $service = new \SubjectService();
        $successCount = 0;
        $failCount = 0;
        $results = [];
        $logger = plugin_context($this->pluginId)->logger();

        $logger->info('开始逐课程履约', [
            'order_no' => $order->order_no,
            'platform_id' => $platformId,
            'study_username' => $studyUsername,
            'course_count' => count($courseData),
        ]);

        foreach ($courseData as $course) {
            $courseName = $course['kname'] ?? $product->name;
            $courseId = $course['kid'] ?? '';

            try {
                $apiResult = $service->createOrder([
                    'platform' => $platformId,
                    'user'     => $studyUsername,
                    'pass'     => $studyPassword,
                    'kcname'   => $courseName,
                    'kcid'     => $courseId,
                    'school'   => $course['school'] ?? $schoolName,
                ]);

                $studyOrder = \StudyOrder::create([
                    'payment_order_id'  => $order->id,
                    'platform_id'       => $platformId,
                    'platform_order_id' => $apiResult['order_id'] ?? '',
                    'platform_course_id' => $courseId,
                    'course_name'       => $courseName,
                    'study_username'    => $studyUsername,
                    'study_password'    => $studyPassword,
                    'school_name'       => $course['school'] ?? $schoolName ?: null,
                    'order_status'      => 'processing',
                    'started_at'        => now(),
                ]);

                $successCount++;
                $results[] = [
                    'course_name'       => $courseName,
                    'study_order_id'    => $studyOrder->id,
                    'platform_order_id' => $apiResult['order_id'] ?? '',
                    'status'            => 'success',
                ];

                $logger->info('课程下单成功', [
                    'order_no'          => $order->order_no,
                    'course_name'       => $courseName,
                    'platform_order_id' => $apiResult['order_id'] ?? '',
                ]);

            } catch (\Exception $e) {
                \StudyOrder::create([
                    'payment_order_id'  => $order->id,
                    'platform_id'       => $platformId,
                    'platform_course_id' => $courseId,
                    'course_name'       => $courseName,
                    'study_username'    => $studyUsername,
                    'study_password'    => $studyPassword,
                    'school_name'       => $course['school'] ?? $schoolName ?: null,
                    'order_status'      => 'failed',
                    'has_error'         => true,
                    'error_message'     => $e->getMessage(),
                ]);

                $failCount++;
                $results[] = [
                    'course_name' => $courseName,
                    'status'      => 'failed',
                    'error'       => $e->getMessage(),
                ];

                $logger->error('课程下单失败', [
                    'order_no'    => $order->order_no,
                    'course_name' => $courseName,
                    'error'       => $e->getMessage(),
                ]);
            }
        }

        $totalCourses = count($courseData);

        $logger->info('逐课程履约完成', [
            'order_no' => $order->order_no,
            'total' => $totalCourses,
            'success_count' => $successCount,
            'fail_count' => $failCount,
        ]);

        if ($successCount > 0) {
            $msg = $failCount > 0
                ? "共 {$totalCourses} 门课程，成功 {$successCount} 门，失败 {$failCount} 门"
                : "全部 {$totalCourses} 门课程下单成功";
            return FulfillResult::success($msg, [
                'success_count' => $successCount,
                'fail_count'    => $failCount,
                'details'       => $results,
            ]);
        }

        return FulfillResult::failure("全部 {$totalCourses} 门课程下单失败", [
            'fail_count' => $failCount,
            'details'    => $results,
        ]);
    }
}
