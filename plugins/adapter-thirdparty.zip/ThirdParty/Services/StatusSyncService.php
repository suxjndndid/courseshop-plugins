<?php

namespace ThirdParty\Services;

use App\Core\Event\OrderFulfilled;
use App\Core\Plugin\FulfillResult;
use App\Models\PaymentOrder;

/**
 * 订单状态同步服务
 *
 * 定时巡检未完成的 StudyOrder，通过第三方 API 同步最新状态。
 * 检测到全部课程完成时派发 OrderFulfilled 事件（触发邮件通知）。
 *
 * 对应旧项目：WangKeLava/app/Console/Commands/CheckOrderStatusCommand.php
 */
class StatusSyncService
{
    private string $pluginId = 'adapter-thirdparty';

    /**
     * 执行完整状态同步
     *
     * 1. 查所有未完成 StudyOrder
     * 2. 按 study_username 分组
     * 3. 每个用户调 queryProgress() 批量同步
     * 4. 检查是否有订单全部完成 → 派发事件 + 更新通知状态
     *
     * @return array 同步结果统计
     */
    public function syncAll(): array
    {
        $logger = plugin_context($this->pluginId)->logger();
        $logger->info('开始定时状态同步');

        // 查所有未完成的 StudyOrder，按 study_username 分组
        $pendingOrders = \StudyOrder::whereNotIn('order_status', ['completed', 'failed'])
            ->get()
            ->groupBy('study_username');

        $logger->info('定时同步：待同步用户数', [
            'user_count' => $pendingOrders->count(),
            'total_pending_orders' => $pendingOrders->flatten()->count(),
        ]);

        $stats = [
            'users_checked'    => 0,
            'orders_updated'   => 0,
            'orders_completed' => 0,
            'notify_sent'      => 0,
            'errors'           => 0,
        ];

        foreach ($pendingOrders as $username => $studyOrders) {
            if (empty($username)) {
                $logger->debug('定时同步：跳过空用户名');
                continue;
            }

            $stats['users_checked']++;
            $logger->debug('定时同步：开始同步用户', [
                'username' => $username,
                'order_count' => $studyOrders->count(),
            ]);

            try {
                $updated = $this->syncUserOrders($username, $studyOrders);
                $stats['orders_updated'] += $updated;
                $logger->info('定时同步：用户同步完成', [
                    'username' => $username,
                    'updated' => $updated,
                ]);
            } catch (\Exception $e) {
                $stats['errors']++;
                $logger->error('定时同步：用户状态同步失败', [
                    'username' => $username,
                    'error'    => $e->getMessage(),
                    'exception_class' => get_class($e),
                ]);
            }
        }

        // 检查是否有 PaymentOrder 的全部 StudyOrder 已完成
        $notified = $this->checkAndNotifyCompleted();
        $stats['orders_completed'] = $notified['completed'];
        $stats['notify_sent'] = $notified['notified'];

        $logger->info('定时状态同步完成', $stats);

        return $stats;
    }

    /**
     * 同步单个用户的所有 StudyOrder 状态
     *
     * @param string $username 学习账号
     * @param \Illuminate\Support\Collection $studyOrders 该用户的 StudyOrder 集合
     * @return int 更新的记录数
     */
    private function syncUserOrders(string $username, $studyOrders): int
    {
        $logger = plugin_context($this->pluginId)->logger();
        $service = new \SubjectService();

        $updated = 0;
        $errors = 0;

        // 逐单调 /api/refresh 获取最新进度（而非仅查询缓存数据）
        foreach ($studyOrders as $studyOrder) {
            if (empty($studyOrder->platform_order_id)) {
                $logger->debug('定时同步跳过：无平台订单号', [
                    'study_order_id' => $studyOrder->id,
                    'username' => $username,
                ]);
                continue;
            }

            try {
                $refreshResult = $service->refreshProgress(
                    $studyOrder->platform_order_id,
                    $username
                );

                $orderData = $refreshResult['order'] ?? null;
                if (!$orderData) {
                    $logger->debug('定时同步：刷新未返回数据', [
                        'study_order_id' => $studyOrder->id,
                        'platform_order_id' => $studyOrder->platform_order_id,
                    ]);
                    continue;
                }

                $newStatus = QueryService::mapApiStatus($orderData['status'] ?? '');
                if (empty($newStatus) || $newStatus === $studyOrder->order_status) {
                    continue;
                }

                $logger->info('定时同步：更新订单状态', [
                    'study_order_id' => $studyOrder->id,
                    'platform_order_id' => $studyOrder->platform_order_id,
                    'old_status' => $studyOrder->order_status,
                    'new_status' => $newStatus,
                    'api_status_raw' => $orderData['status'] ?? '',
                    'progress' => $orderData['progress'] ?? '',
                ]);

                $studyOrder->update([
                    'order_status' => $newStatus,
                    'completed_at' => $newStatus === 'completed' ? now() : $studyOrder->completed_at,
                ]);
                $updated++;
            } catch (\Exception $e) {
                $errors++;
                $logger->warning('定时同步：单条刷新失败', [
                    'study_order_id' => $studyOrder->id,
                    'platform_order_id' => $studyOrder->platform_order_id,
                    'username' => $username,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        if ($errors > 0) {
            $logger->warning('定时同步：用户同步部分失败', [
                'username' => $username,
                'updated' => $updated,
                'errors' => $errors,
            ]);
        }

        return $updated;
    }

    /**
     * 检查已支付但未通知的订单，若全部课程完成则派发事件
     *
     * 对应旧项目：CheckOrderStatusCommand::checkAndNotifyCompletedOrders()
     *
     * @return array ['completed' => int, 'notified' => int]
     */
    private function checkAndNotifyCompleted(): array
    {
        $logger = plugin_context($this->pluginId)->logger();

        // 查已支付、未通知的订单
        $orders = PaymentOrder::where('payment_status', PaymentOrder::STATUS_PAID)
            ->where('is_notified', 0)
            ->get();

        $completed = 0;
        $notified = 0;

        foreach ($orders as $order) {
            $studyOrders = \StudyOrder::byPaymentOrderId($order->id)->get();
            if ($studyOrders->isEmpty()) {
                continue;
            }

            // 检查是否全部完成
            $allCompleted = $studyOrders->every(fn($so) => $so->order_status === 'completed');
            if (!$allCompleted) {
                continue;
            }

            $completed++;

            // 更新履约状态
            if ($order->fulfill_status !== PaymentOrder::FULFILL_SUCCESS) {
                $order->update(['fulfill_status' => PaymentOrder::FULFILL_SUCCESS]);
            }

            // 派发 OrderFulfilled 事件（邮件插件会监听此事件发通知）
            try {
                $result = FulfillResult::success('全部课程已完成', [
                    'study_order_count' => $studyOrders->count(),
                    'source'            => 'status_sync',
                ]);
                event(new OrderFulfilled($order, $result));

                // 更新通知状态
                $order->update([
                    'is_notified'    => 1,
                    'notified_at'    => now(),
                    'notification_count' => ($order->notification_count ?? 0) + 1,
                ]);
                $notified++;

                $logger->info('全部课程完成，已派发通知', [
                    'order_no'     => $order->order_no,
                    'course_count' => $studyOrders->count(),
                ]);
            } catch (\Exception $e) {
                // 通知失败记录错误，但不影响后续处理
                $order->update([
                    'notification_error' => $e->getMessage(),
                ]);
                $logger->error('完成通知派发失败', [
                    'order_no' => $order->order_no,
                    'error'    => $e->getMessage(),
                ]);
            }
        }

        return ['completed' => $completed, 'notified' => $notified];
    }
}
