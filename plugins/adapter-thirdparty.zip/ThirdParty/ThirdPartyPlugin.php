<?php

/**
 * 第三方课程对接插件 — 入口文件
 *
 * 同时实现两个接口（implements 多接口）：
 * - PluginInterface：框架加载、注册、启动、卸载的生命周期
 * - ProductAdapterInterface：商品类型、编辑组件、验证 meta、履约交付
 *
 * 职责：只做注册和委派，具体业务逻辑分布在：
 * - Controllers/  — HTTP 请求处理
 * - Services/     — 业务逻辑（履约、查询合并）
 * - Models/       — Eloquent 模型
 * - views/        — Blade 模板
 * - assets/js/    — 前端交互脚本
 * - routes.php    — 路由定义（无闭包，指向 Controller）
 *
 * 插件无命名空间（入口文件），子模块使用命名空间（ThirdParty\*）。
 * 不走 Composer autoload，由 register() 手动 require_once 加载。
 */

use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Core\Plugin\FulfillResult;
use App\Core\Contracts\ProductAdapterInterface;
use App\Core\Hook\Hook;
use App\Core\Admin\AdminMenu;
use App\Core\Event\OrderFulfilled;
use App\Core\Event\OrderFailed;
use App\Models\PaymentOrder;

class ThirdPartyPlugin implements PluginInterface, ProductAdapterInterface
{
    /** @var string 插件根目录（在 register 中初始化） */
    private string $pluginPath;

    // ==================== PluginInterface ====================

    public function id(): string { return 'adapter-thirdparty'; }
    public function name(): string { return '第三方课程对接'; }
    public function version(): string { return '1.0.0'; }
    public function type(): PluginType { return PluginType::ProductAdapter; }

    /**
     * 注册阶段：加载子模块、注册视图/菜单/路由
     */
    public function register(): void
    {
        $this->pluginPath = dirname(__FILE__);

        // 加载子模块（插件不走 Composer autoload）
        $this->loadDependencies();

        // 注册视图命名空间：view('adapter-thirdparty::settings')
        app('view')->addNamespace('adapter-thirdparty', $this->pluginPath . '/views');

        // 注册后台菜单（侧边栏只保留一个入口，页面内 Tab 切换设置/订单）
        AdminMenu::add([
            'group' => AdminMenu::GROUP_PRODUCT_ADAPTER,
            'items' => [
                [
                    'label' => '课程对接',
                    'icon'  => 'academic-cap',
                    'route' => 'admin.plugin.adapter-thirdparty',
                    'order' => 51,
                ],
            ],
        ]);

        // 加载路由文件（Controller 类路由，无闭包）
        require $this->pluginPath . '/routes.php';
    }

    /**
     * 启动阶段：注册 Hook + 定时任务
     */
    public function boot(): void
    {
        $this->registerFormHooks();
        $this->registerOrderHooks();
        $this->registerQueryHooks();
        $this->registerDisplayHooks();
        $this->registerScheduledTasks();
    }

    public function uninstall(): void
    {
        AdminMenu::remove('admin.plugin.adapter-thirdparty');
    }

    public function config(): array
    {
        return [
            'api_key'      => '',
            'api_base_url' => '',
            'api_timeout'  => '60',
        ];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }

    // ==================== ProductAdapterInterface ====================

    public function productType(): string { return 'course'; }
    public function productTypeLabel(): string { return '课程代刷'; }
    public function editorComponent(): string { return 'third-party-editor'; }

    /**
     * 验证商品 meta（后台保存商品时调用）
     *
     * 课程商品必须指定 platform_id（对接平台标识）。
     */
    public function validateMeta(array $meta): array
    {
        if (empty($meta['platform_id'])) {
            throw new \InvalidArgumentException('platform_id（平台标识）不能为空');
        }
        return ['platform_id' => trim($meta['platform_id'])];
    }

    /**
     * 履约入口 — 委派给 FulfillService
     */
    public function fulfill(PaymentOrder $order): FulfillResult
    {
        return (new \ThirdParty\Services\FulfillService())->fulfill($order);
    }

    // ==================== 私有方法 ====================

    /**
     * 加载插件子模块依赖
     */
    private function loadDependencies(): void
    {
        $p = $this->pluginPath;

        // Models
        require_once $p . '/Models/StudyOrder.php';

        // Services
        require_once $p . '/SubjectService.php';
        require_once $p . '/Services/FulfillService.php';
        require_once $p . '/Services/QueryService.php';
        require_once $p . '/Services/StatusSyncService.php';

        // Controllers
        require_once $p . '/Controllers/SettingsController.php';
        require_once $p . '/Controllers/CourseController.php';
        require_once $p . '/Controllers/StudyOrderController.php';
    }

    // ==================== Hook 注册分组 ====================

    /**
     * 表单相关 Hook（下单页 UI + 数据验证）
     */
    private function registerFormHooks(): void
    {
        // 后台商品编辑页注入 meta 配置表单（platform_id）
        Hook::addFilter('admin.product.meta_form', function (string $html, string $productType) {
            if ($productType !== $this->productType()) {
                return $html;
            }

            return view('adapter-thirdparty::admin-meta-form')->render();
        }, 10);

        // 渲染课程对接表单 UI（账号/密码/查课/课程选择）
        Hook::addFilter('order_form.adapter_ui', function (string $html, $product) {
            if (($product->product_type ?? '') !== 'course') {
                return $html;
            }
            return $this->renderAdapterForm($product);
        }, 10);

        // 验证用户提交的课程对接数据
        Hook::addFilter('order.validate_adapter_data', function (array $validation, $request, $product) {
            if (($product->product_type ?? '') !== 'course') {
                return $validation;
            }
            return $this->validateAdapterData($validation, $request);
        }, 10);
    }

    /**
     * 订单流程相关 Hook（支付后履约）
     */
    private function registerOrderHooks(): void
    {
        // 支付成功后执行履约
        Hook::addAction('order.after_paid', function (PaymentOrder $order) {
            $this->handleAfterPaid($order);
        }, 10);
    }

    /**
     * 查询相关 Hook（订单查询 + 学习账号反查）
     */
    private function registerQueryHooks(): void
    {
        // 订单查询时附加课程进度数据（API 主数据源 + 本地合并）
        Hook::addFilter('order_query.extra_data', function (array $extraData, PaymentOrder $order) {
            return (new \ThirdParty\Services\QueryService())->appendStudyOrderData($extraData, $order);
        }, 10);

        // 按学习账号反查 PaymentOrder（框架查不到时回退）
        Hook::addFilter('order_query.by_identifier', function (array $orderIds, string $identifier) {
            $ids = \StudyOrder::where('study_username', $identifier)
                ->pluck('payment_order_id')
                ->unique()
                ->toArray();
            return array_merge($orderIds, $ids);
        }, 10);
    }

    /**
     * 展示相关 Hook（类型标签 + 详情页 + 成功页）
     */
    private function registerDisplayHooks(): void
    {
        // 商品类型标签映射
        Hook::addFilter('product.type_label', function (string $label, string $type) {
            return $type === 'course' ? '课程代刷' : $label;
        }, 10);

        // 商品详情页显示平台信息
        Hook::addFilter('product.detail_extra', function (string $html, $product) {
            if (($product->product_type ?? '') !== 'course') return $html;
            $pid = $product->meta['platform_id'] ?? '';
            if (empty($pid)) return $html;
            return $html . '<div class="text-sm text-gray-500 mt-2">'
                . '<span class="font-medium">对接平台：</span>' . htmlspecialchars($pid)
                . '</div>';
        }, 10);

        // 订单成功页显示学习状态 — 委派给 Blade 视图
        Hook::addFilter('order_success.extra_info', function (string $extraInfo, PaymentOrder $order) {
            return $this->renderSuccessExtraInfo($extraInfo, $order);
        }, 10);
    }

    /**
     * 注册定时任务：每天 10:00 同步未完成订单状态
     *
     * 通过 PluginContext::scheduler() 注册 cron 任务，
     * 框架在所有插件 boot 完成后统一注入 Laravel Schedule。
     */
    private function registerScheduledTasks(): void
    {
        plugin_context($this->id())->scheduler()->daily(
            '10:00',
            function () {
                $service = new \ThirdParty\Services\StatusSyncService();
                $result = $service->syncAll();
                plugin_context('adapter-thirdparty')->logger()->info('定时状态同步执行完毕', $result);
            },
            '课程订单状态巡检'
        );
    }

    // ==================== Hook 回调实现 ====================

    /**
     * 渲染下单表单 — 委派给 Blade 视图 + JS 文件
     */
    private function renderAdapterForm($product): string
    {
        $platformId = $product->meta['platform_id'] ?? '';

        return view('adapter-thirdparty::adapter-form', [
            'platformId'   => $platformId,
            'coursesRoute' => route('ajax.plugin.adapter-thirdparty.courses'),
            'unitPrice'    => (float) $product->sale_price,
            'adapterJsUrl' => asset('plugins/ProductAdapter/ThirdParty/assets/js/adapter.js'),
        ])->render();
    }

    /**
     * 验证用户提交的课程对接数据
     */
    private function validateAdapterData(array $validation, $request): array
    {
        $studyUsername = trim($request->input('study_username', ''));
        $studyPassword = $request->input('study_password', '');

        if (empty($studyUsername)) {
            return array_merge($validation, ['valid' => false, 'message' => '请输入学习平台账号']);
        }
        if (empty($studyPassword)) {
            return array_merge($validation, ['valid' => false, 'message' => '请输入学习平台密码']);
        }

        // 验证 course_data 数组
        $courseData = $request->input('course_data', []);
        if (!is_array($courseData) || empty($courseData)) {
            return array_merge($validation, ['valid' => false, 'message' => '请先获取课程列表并选择至少一门课程']);
        }

        $cleanedCourses = [];
        foreach ($courseData as $course) {
            if (empty($course['kid']) || empty($course['kname'])) continue;
            $cleanedCourses[] = [
                'kid'    => trim($course['kid']),
                'kname'  => trim($course['kname']),
                'school' => trim($course['school'] ?? ''),
            ];
        }

        if (empty($cleanedCourses)) {
            return array_merge($validation, ['valid' => false, 'message' => '选择的课程数据无效，请重新选择']);
        }

        $validation['adapter_data'] = [
            'study_username' => $studyUsername,
            'study_password' => $studyPassword,
            'course_data'    => $cleanedCourses,
            'course_count'   => count($cleanedCourses),
            'school_name'    => trim($request->input('school_name', '')),
        ];

        return $validation;
    }

    /**
     * 支付成功后处理履约
     *
     * fulfill() → 更新 fulfill_status → 派发事件
     */
    private function handleAfterPaid(PaymentOrder $order): void
    {
        // 幂等保护：已完成/已失败的订单不再重复履约
        if (in_array($order->fulfill_status, [PaymentOrder::FULFILL_SUCCESS, PaymentOrder::FULFILL_FAILURE], true)) {
            plugin_context($this->id())->logger()->warning('跳过重复履约：订单已是终态', [
                'order_no' => $order->order_no,
                'fulfill_status' => $order->fulfill_status,
            ]);
            return;
        }

        $product = $order->product;
        if (!$product || ($product->product_type ?? '') !== 'course') {
            plugin_context($this->id())->logger()->debug('跳过非课程类型订单的履约', [
                'order_no'     => $order->order_no,
                'product_type' => $product->product_type ?? 'null',
            ]);
            return;
        }

        plugin_context($this->id())->logger()->info('开始课程履约', [
            'order_no'     => $order->order_no,
            'product_type' => $product->product_type,
            'product_name' => $product->name,
        ]);

        try {
            $result = $this->fulfill($order);

            $order->update([
                'fulfill_status' => $result->isSuccess()
                    ? PaymentOrder::FULFILL_SUCCESS
                    : PaymentOrder::FULFILL_FAILURE,
                'fulfill_data' => array_merge($order->fulfill_data ?? [], [
                    'fulfill_result' => $result->toArray(),
                ]),
            ]);

            plugin_context($this->id())->logger()->info('课程履约完成', [
                'order_no' => $order->order_no,
                'success' => $result->isSuccess(),
                'message' => $result->message,
                'fulfill_status' => $result->isSuccess() ? 'success' : 'failure',
            ]);

            // 派发事件
            if ($result->isSuccess()) {
                event(new OrderFulfilled($order, $result));
            } else {
                event(new OrderFailed($order, $result->message));
            }

        } catch (\Throwable $e) {
            plugin_context($this->id())->logger()->error('课程履约异常', [
                'order_no' => $order->order_no,
                'error' => $e->getMessage(),
                'exception_class' => get_class($e),
                'file' => $e->getFile() . ':' . $e->getLine(),
                'trace' => $e->getTraceAsString(),
            ]);

            $order->update([
                'fulfill_status' => PaymentOrder::FULFILL_FAILURE,
                'fulfill_data' => array_merge($order->fulfill_data ?? [], [
                    'fulfill_result' => [
                        'success' => false,
                        'message' => '履约异常: ' . $e->getMessage(),
                    ],
                ]),
            ]);

            event(new OrderFailed($order, '履约异常: ' . $e->getMessage()));
        }
    }

    /**
     * 订单成功页显示学习状态 — 委派给 Blade 视图
     */
    private function renderSuccessExtraInfo(string $extraInfo, PaymentOrder $order): string
    {
        $product = $order->product;
        if (!$product || ($product->product_type ?? '') !== 'course') {
            return $extraInfo;
        }

        $studyOrders = \StudyOrder::byPaymentOrderId($order->id)->get();
        if ($studyOrders->isEmpty()) {
            return $extraInfo;
        }

        return $extraInfo . view('adapter-thirdparty::order-success-extra', [
            'studyOrders' => $studyOrders,
        ])->render();
    }
}
