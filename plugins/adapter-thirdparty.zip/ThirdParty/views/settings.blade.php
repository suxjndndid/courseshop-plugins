{{-- 第三方课程对接插件 — 后台设置页 --}}
@extends('admin.layouts.app')

@section('title', '课程对接设置')

@section('content')
@include('adapter-thirdparty::_nav-tabs', ['currentTab' => 'settings'])
<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 class="text-xl font-semibold mb-4 flex items-center">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
            </svg>
            第三方课程对接配置
        </h2>

        @if(session('success'))
        <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded mb-4">
            {{ session('success') }}
        </div>
        @endif

        @if($errors->any())
        <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
            @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach
        </div>
        @endif

        <form action="{{ route('admin.plugin.adapter-thirdparty.save') }}" method="POST">
            @csrf

            {{-- API 密钥（敏感字段，password 类型） --}}
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">API 密钥</label>
                <input type="password"
                       name="api_key"
                       value=""
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                       placeholder="{{ !empty($settings['api_key']) ? '已设置（留空不修改）' : '请输入第三方平台 API 密钥' }}">
                <p class="text-sm text-gray-500 mt-1">敏感信息，留空表示不修改。也可通过 .env 设置：ADAPTER_THIRDPARTY_API_KEY</p>
            </div>

            {{-- API 基础 URL --}}
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">API 基础 URL</label>
                <input type="url"
                       name="api_base_url"
                       value="{{ $settings['api_base_url'] ?? '' }}"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                       placeholder="https://api.example.com"
                       required>
                <p class="text-sm text-gray-500 mt-1">第三方刷课平台的 API 地址（不含末尾斜杠）</p>
            </div>

            {{-- API 超时时间 --}}
            <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-1">API 超时时间（秒）</label>
                <input type="number"
                       name="api_timeout"
                       value="{{ $settings['api_timeout'] ?? '60' }}"
                       min="5"
                       max="300"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                       required>
                <p class="text-sm text-gray-500 mt-1">API 请求超时时间，建议 30-120 秒</p>
            </div>

            {{-- 配置说明 --}}
            <div class="bg-gray-50 rounded-md p-4 mb-6">
                <h3 class="text-sm font-medium text-gray-700 mb-2">配置说明</h3>
                <div class="text-sm text-gray-600 space-y-1">
                    <p>配置优先级（从高到低）：</p>
                    <ol class="list-decimal list-inside ml-2">
                        <li>此页面保存的值（存入数据库 settings 表）</li>
                        <li>.env 环境变量（如 ADAPTER_THIRDPARTY_API_KEY）</li>
                        <li>插件默认值</li>
                    </ol>
                </div>
            </div>

            <button type="submit"
                    class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors">
                保存配置
            </button>
        </form>
    </div>
</div>
@endsection
