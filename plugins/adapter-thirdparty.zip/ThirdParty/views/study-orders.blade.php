@extends('admin.layouts.app')

@section('title', '刷课订单管理')

@section('content')
@include('adapter-thirdparty::_nav-tabs', ['currentTab' => 'study-orders'])
<div class="container mx-auto px-4 py-6"
     x-data="studyOrderPage()"
     x-init="init()">
    <h2 class="text-xl font-bold text-gray-800 mb-4">刷课订单管理</h2>

    {{-- 统计卡片 --}}
    <div class="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
        <div class="bg-white rounded-lg shadow p-4 text-center">
            <div class="text-gray-400 mb-1"><svg class="inline w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg></div>
            <div class="text-2xl font-bold text-gray-800">{{ $stats['total'] }}</div>
            <div class="text-sm text-gray-500">总订单</div>
        </div>
        <div class="bg-white rounded-lg shadow p-4 text-center border-t-2 border-blue-500">
            <div class="text-blue-400 mb-1"><svg class="inline w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg></div>
            <div class="text-2xl font-bold text-blue-600">{{ $stats['processing'] }}</div>
            <div class="text-sm text-gray-500">进行中</div>
        </div>
        <div class="bg-white rounded-lg shadow p-4 text-center border-t-2 border-green-500">
            <div class="text-green-400 mb-1"><svg class="inline w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg></div>
            <div class="text-2xl font-bold text-green-600">{{ $stats['completed'] }}</div>
            <div class="text-sm text-gray-500">已完成</div>
        </div>
        <div class="bg-white rounded-lg shadow p-4 text-center border-t-2 border-red-500">
            <div class="text-red-400 mb-1"><svg class="inline w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg></div>
            <div class="text-2xl font-bold text-red-600">{{ $stats['failed'] }}</div>
            <div class="text-sm text-gray-500">失败</div>
        </div>
        <div class="bg-white rounded-lg shadow p-4 text-center border-t-2 border-amber-500">
            <div class="text-amber-400 mb-1"><svg class="inline w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg></div>
            <div class="text-2xl font-bold text-amber-600">{{ $stats['errors'] }}</div>
            <div class="text-sm text-gray-500">有错误</div>
        </div>
    </div>

    {{-- 搜索和筛选 --}}
    <div class="bg-white rounded-lg shadow p-4 mb-4">
        <form method="GET" class="flex flex-wrap gap-3 items-end">
            <div class="flex-1 min-w-[200px]">
                <label class="block text-sm text-gray-600 mb-1">搜索</label>
                <input type="text" name="search" value="{{ $search }}" placeholder="用户名 / 课程名 / 平台订单号"
                       class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
            </div>
            <div>
                <label class="block text-sm text-gray-600 mb-1">状态</label>
                <select name="status" class="px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
                    <option value="">全部</option>
                    <option value="pending" {{ $status === 'pending' ? 'selected' : '' }}>待处理</option>
                    <option value="processing" {{ $status === 'processing' ? 'selected' : '' }}>进行中</option>
                    <option value="completed" {{ $status === 'completed' ? 'selected' : '' }}>已完成</option>
                    <option value="failed" {{ $status === 'failed' ? 'selected' : '' }}>失败</option>
                </select>
            </div>
            <div>
                <label class="block text-sm text-gray-600 mb-1">错误</label>
                <select name="has_error" class="px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
                    <option value="">全部</option>
                    <option value="1" {{ $hasError === '1' ? 'selected' : '' }}>仅错误</option>
                </select>
            </div>
            <button type="submit" class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">筛选</button>
            <a href="{{ route('admin.plugin.adapter-thirdparty.study-orders') }}" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">重置</a>
            <button type="button" @click="doSyncAll($el)" class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">全量同步</button>
        </form>
    </div>

    {{-- 订单列表 --}}
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <table class="w-full text-sm">
            <thead class="bg-gray-50 text-gray-600 uppercase text-xs">
                <tr>
                    <th class="px-4 py-3 text-left">ID</th>
                    <th class="px-4 py-3 text-left">用户名</th>
                    <th class="px-4 py-3 text-left">课程名</th>
                    <th class="px-4 py-3 text-left">平台订单号</th>
                    <th class="px-4 py-3 text-left">状态</th>
                    <th class="px-4 py-3 text-left">支付订单</th>
                    <th class="px-4 py-3 text-left">创建时间</th>
                    <th class="px-4 py-3 text-left">操作</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                @forelse($studyOrders as $so)
                <tr class="{{ $so->has_error ? 'border-l-4 border-red-400' : '' }}" id="row-{{ $so->id }}">
                    <td class="px-4 py-3 text-gray-500">{{ $so->id }}</td>
                    <td class="px-4 py-3 font-medium">{{ $so->study_username }}</td>
                    <td class="px-4 py-3">{{ Str::limit($so->course_name, 30) }}</td>
                    <td class="px-4 py-3">
                        <code class="text-xs bg-gray-100 px-1 rounded">{{ $so->platform_order_id ?: '-' }}</code>
                    </td>
                    <td class="px-4 py-3">
                        @switch($so->order_status)
                            @case('completed')
                                <span class="px-2 py-0.5 rounded-full text-xs bg-green-100 text-green-700">已完成</span>
                                @break
                            @case('processing')
                                <span class="px-2 py-0.5 rounded-full text-xs bg-blue-100 text-blue-700">进行中</span>
                                @break
                            @case('failed')
                                <span class="px-2 py-0.5 rounded-full text-xs bg-red-100 text-red-700">失败</span>
                                @break
                            @default
                                <span class="px-2 py-0.5 rounded-full text-xs bg-gray-100 text-gray-700">待处理</span>
                        @endswitch
                        @if($so->has_error)
                            <span class="text-red-500 text-xs ml-1" title="{{ $so->error_message }}">&#9888;</span>
                        @endif
                    </td>
                    <td class="px-4 py-3">
                        <code class="text-xs">{{ $so->paymentOrder->order_no ?? '-' }}</code>
                    </td>
                    <td class="px-4 py-3 text-gray-500 text-xs">{{ $so->created_at?->format('m-d H:i') }}</td>
                    <td class="px-4 py-3">
                        <div class="flex gap-1">
                            {{-- 状态切换下拉 --}}
                            <select @change="doUpdateStatus({{ $so->id }}, $el.value); $el.value=''" class="text-xs border rounded px-1 py-0.5">
                                <option value="">修改状态</option>
                                <option value="pending">待处理</option>
                                <option value="processing">进行中</option>
                                <option value="completed">已完成</option>
                                <option value="failed">失败</option>
                            </select>
                            {{-- 单用户同步 --}}
                            <button @click="doSyncUser('{{ $so->study_username }}')"
                                    class="text-xs px-2 py-0.5 bg-blue-50 text-blue-600 rounded hover:bg-blue-100"
                                    title="同步该用户所有订单">同步</button>
                            {{-- 查看详情 --}}
                            <button @click="showDetail(@js($so->toArray()))"
                                    class="text-xs px-2 py-0.5 bg-indigo-50 text-indigo-600 rounded hover:bg-indigo-100"
                                    title="查看订单详情">详情</button>
                        </div>
                    </td>
                </tr>
                @if($so->has_error && $so->error_message)
                <tr class="bg-red-50">
                    <td colspan="8" class="px-4 py-1 text-xs text-red-600">
                        <strong>错误：</strong>{{ $so->error_message }}
                    </td>
                </tr>
                @endif
                @empty
                <tr>
                    <td colspan="8" class="px-4 py-8 text-center text-gray-400">暂无刷课订单</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    {{-- 分页 --}}
    <div class="mt-4">
        {{ $studyOrders->withQueryString()->links() }}
    </div>

    {{-- ==================== 详情弹窗 ==================== --}}
    <div x-show="detailOpen" x-cloak
         class="fixed inset-0 z-50 flex items-center justify-center"
         @keydown.escape.window="detailOpen = false">
        {{-- 遮罩 --}}
        <div class="fixed inset-0 bg-black/50" @click="detailOpen = false"></div>
        {{-- 弹窗内容 --}}
        <div class="relative bg-white rounded-xl shadow-2xl w-full max-w-lg mx-4 max-h-[85vh] overflow-y-auto"
             x-transition>
            <div class="flex items-center justify-between px-6 py-4 border-b">
                <h3 class="text-lg font-semibold text-gray-800">订单详情</h3>
                <button @click="detailOpen = false" class="text-gray-400 hover:text-gray-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>
            <div class="px-6 py-4 space-y-3" x-show="detail">
                <template x-if="detail">
                    <div class="space-y-3">
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <p class="text-xs text-gray-500">ID</p>
                                <p class="font-mono text-sm" x-text="detail.id"></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500">状态</p>
                                <p class="text-sm font-semibold" x-text="statusText(detail.order_status)"></p>
                            </div>
                        </div>
                        <div>
                            <p class="text-xs text-gray-500">课程名称</p>
                            <p class="text-sm font-medium text-indigo-600" x-text="detail.course_name"></p>
                        </div>
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <p class="text-xs text-gray-500">学习账号</p>
                                <p class="font-mono text-sm" x-text="detail.study_username"></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500">学习密码</p>
                                <div class="flex items-center gap-1">
                                    <p class="font-mono text-sm" x-text="showPwd ? detail.study_password : '••••••••'"></p>
                                    <button @click="showPwd = !showPwd" class="text-gray-400 hover:text-gray-600">
                                        <svg x-show="!showPwd" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                        <svg x-show="showPwd" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L6.59 6.59m7.532 7.532l3.29 3.29M3 3l18 18"/></svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <p class="text-xs text-gray-500">学校</p>
                                <p class="text-sm" x-text="detail.school_name || '-'"></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500">平台 ID</p>
                                <p class="font-mono text-xs" x-text="detail.platform_id || '-'"></p>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <p class="text-xs text-gray-500">平台订单号</p>
                                <p class="font-mono text-xs" x-text="detail.platform_order_id || '-'"></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500">平台课程 ID</p>
                                <p class="font-mono text-xs" x-text="detail.platform_course_id || '-'"></p>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <p class="text-xs text-gray-500">创建时间</p>
                                <p class="text-sm" x-text="detail.created_at || '-'"></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500">开始时间</p>
                                <p class="text-sm" x-text="detail.started_at || '-'"></p>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <p class="text-xs text-gray-500">完成时间</p>
                                <p class="text-sm" x-text="detail.completed_at || '-'"></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500">支付订单 ID</p>
                                <p class="font-mono text-xs" x-text="detail.payment_order_id || '-'"></p>
                            </div>
                        </div>
                        <template x-if="detail.has_error">
                            <div class="bg-red-50 rounded-lg p-3">
                                <p class="text-xs text-red-500 font-semibold mb-1">错误信息</p>
                                <p class="text-sm text-red-700" x-text="detail.error_message"></p>
                            </div>
                        </template>
                    </div>
                </template>
            </div>
            <div class="px-6 py-3 border-t bg-gray-50 rounded-b-xl flex justify-end">
                <button @click="detailOpen = false" class="px-4 py-2 text-sm bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">关闭</button>
            </div>
        </div>
    </div>
</div>

{{-- Alpine.js 组件（使用 Alpine.data 注册，兼容 Livewire wire:navigate SPA 模式） --}}
<script>
document.addEventListener('alpine:init', () => {
    /**
     * Alpine 组件在 alpine:init 时注册，确保 wire:navigate 重新进入页面时
     * Alpine 会重新初始化 x-data，函数始终可用。
     */
    Alpine.data('studyOrderPage', () => ({
        detailOpen: false,
        detail: null,
        showPwd: false,

        CSRF: document.querySelector('meta[name="csrf-token"]')?.content || '',
        routes: {
            updateStatus: @json(route('admin.plugin.adapter-thirdparty.study-orders.update-status')),
            syncUser: @json(route('admin.plugin.adapter-thirdparty.study-orders.sync-user')),
            syncAll: @json(route('admin.plugin.adapter-thirdparty.study-orders.sync-all')),
        },

        init() {},

        showDetail(data) {
            this.detail = data;
            this.showPwd = false;
            this.detailOpen = true;
        },

        statusText(s) {
            return { pending: '待处理', processing: '进行中', completed: '已完成', failed: '失败' }[s] || s;
        },

        async doUpdateStatus(id, status) {
            if (!status) return;
            try {
                const resp = await fetch(this.routes.updateStatus, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': this.CSRF, 'Accept': 'application/json' },
                    body: JSON.stringify({ id, status })
                });
                const result = await resp.json();
                if (result.success) {
                    location.reload();
                } else {
                    alert(result.message || '操作失败');
                }
            } catch (e) { alert('网络错误'); }
        },

        async doSyncUser(username) {
            if (!await confirm('确认同步用户 ' + username + ' 的所有订单？')) return;
            try {
                const resp = await fetch(this.routes.syncUser, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': this.CSRF, 'Accept': 'application/json' },
                    body: JSON.stringify({ username })
                });
                const result = await resp.json();
                alert(result.message || (result.success ? '同步完成' : '同步失败'));
                if (result.success) location.reload();
            } catch (e) { alert('网络错误'); }
        },

        async doSyncAll(btn) {
            if (!await confirm('确认执行全量同步？这可能需要较长时间。')) return;
            if (btn) { btn.disabled = true; btn.textContent = '同步中...'; }
            try {
                const resp = await fetch(this.routes.syncAll, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': this.CSRF, 'Accept': 'application/json' }
                });
                const result = await resp.json();
                alert(result.message || (result.success ? '同步完成' : '同步失败'));
                if (result.success) location.reload();
            } catch (e) { alert('网络错误'); }
            finally {
                if (btn) { btn.disabled = false; btn.textContent = '全量同步'; }
            }
        }
    }));
});
</script>
@endsection
