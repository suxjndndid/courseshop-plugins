<?php

namespace ThirdParty\Services;

use App\Models\PaymentOrder;

/**
 * 订单查询服务
 *
 * 以第三方 API 为主数据源，本地 StudyOrder 为补充。
 * 查询时顺带同步 API 返回的最新状态到本地。
 */
class QueryService
{
    private string $pluginId = 'adapter-thirdparty';

    /**
     * 附加学习订单进度数据到查询结果
     *
     * @param array $extraData 现有的附加数据
     * @param PaymentOrder $order 支付订单
     * @return array 含 study_orders + plugin_routes 的附加数据
     */
    public function appendStudyOrderData(array $extraData, PaymentOrder $order): array
    {
        $logger = plugin_context($this->pluginId)->logger();
        $adapterData = $order->fulfill_data['adapter_data'] ?? [];
        $studyUsername = $adapterData['study_username'] ?? '';

        $localOrders = \StudyOrder::byPaymentOrderId($order->id)->get();

        $logger->debug('QueryService: 附加学习订单数据', [
            'payment_order_id' => $order->id,
            'order_no' => $order->order_no,
            'study_username' => $studyUsername,
            'local_order_count' => $localOrders->count(),
        ]);

        if ($localOrders->isEmpty() && empty($studyUsername)) {
            $logger->debug('QueryService: 无本地订单且无学习账号，跳过', [
                'payment_order_id' => $order->id,
            ]);
            return $extraData;
        }

        // 建本地 Map（以 platform_order_id 为 key）
        $localMap = [];
        foreach ($localOrders as $lo) {
            if (!empty($lo->platform_order_id)) {
                $localMap[$lo->platform_order_id] = $lo;
            }
        }

        // 尝试从第三方 API 查询最新进度（30 秒缓存避免频繁请求）
        $apiOrders = [];
        if (!empty($studyUsername)) {
            try {
                $cacheKey = 'query_progress:' . md5($studyUsername);
                $cacheStore = cache()->store();
                $fromCache = $cacheStore->has($cacheKey);
                $apiResult = $cacheStore->remember($cacheKey, 30, function () use ($studyUsername, $logger) {
                    $logger->debug('QueryService: 进度缓存未命中，调用API', [
                        'username' => $studyUsername,
                    ]);
                    $service = new \SubjectService();
                    return $service->queryProgress($studyUsername);
                });
                $apiOrders = $apiResult['orders'] ?? [];

                $logger->info('QueryService: API查询进度完成', [
                    'username' => $studyUsername,
                    'api_order_count' => count($apiOrders),
                    'from_cache' => $fromCache,
                ]);
            } catch (\Exception $e) {
                $logger->warning('QueryService: 查询学习进度失败，回退到本地数据', [
                    'username' => $studyUsername,
                    'error'    => $e->getMessage(),
                ]);
            }
        }

        $studyOrderData = [];

        if (!empty($apiOrders)) {
            // API 主模式：遍历 API 结果，只展示属于当前支付订单的记录。
            // API 按用户名查返回该用户全部订单，必须用 localMap 过滤归属。
            foreach ($apiOrders as $apiOrder) {
                $apiOrderId = $apiOrder['order_id'] ?? '';
                $localOrder = $localMap[$apiOrderId] ?? null;

                // 不属于当前支付订单的 API 记录跳过（会在对应订单查询时展示）
                if (!$localOrder) {
                    continue;
                }

                // 同步状态到本地
                $newStatus = self::mapApiStatus($apiOrder['status'] ?? '');
                if ($newStatus && $newStatus !== $localOrder->order_status) {
                    $logger->info('QueryService: 自动同步本地状态', [
                        'study_order_id' => $localOrder->id,
                        'platform_order_id' => $apiOrderId,
                        'old_status' => $localOrder->order_status,
                        'new_status' => $newStatus,
                        'api_status_raw' => $apiOrder['status'] ?? '',
                        'progress' => $apiOrder['progress'] ?? '',
                    ]);
                    $localOrder->update([
                        'order_status' => $newStatus,
                        'completed_at' => $newStatus === 'completed' ? now() : $localOrder->completed_at,
                    ]);
                }
                unset($localMap[$apiOrderId]);

                $studyOrderData[] = $this->formatStudyOrderItem($apiOrder, $localOrder, $studyUsername);
            }

            // 补充 API 中没有但本地有的记录（如创建失败的）
            if (!empty($localMap)) {
                $logger->debug('QueryService: 补充本地独有记录', [
                    'count' => count($localMap),
                    'platform_order_ids' => array_keys($localMap),
                ]);
            }
            foreach ($localMap as $lo) {
                $studyOrderData[] = $this->formatLocalOnlyItem($lo, $studyUsername);
            }
        } else {
            // API 不可用时回退纯本地数据
            $logger->debug('QueryService: API无数据，使用纯本地数据', [
                'local_count' => $localOrders->count(),
            ]);
            foreach ($localOrders as $lo) {
                $studyOrderData[] = $this->formatLocalOnlyItem($lo, $studyUsername);
            }
        }

        $extraData['study_orders'] = $studyOrderData;
        // 注入插件路由 URL（route() 可能在测试环境或未完全注册时失败，降级为空）
        try {
            $extraData['plugin_routes'] = [
                'refresh' => route('ajax.plugin.adapter-thirdparty.refresh'),
                'rebrush' => route('ajax.plugin.adapter-thirdparty.rebrush'),
            ];
        } catch (\Throwable) {
            $extraData['plugin_routes'] = [
                'refresh' => '/ajax/plugin/adapter-thirdparty/refresh',
                'rebrush' => '/ajax/plugin/adapter-thirdparty/rebrush',
            ];
        }

        return $extraData;
    }

    /**
     * 将第三方 API 中文状态映射为本地英文状态
     */
    public static function mapApiStatus(string $apiStatus): string
    {
        return match ($apiStatus) {
            '未开始', '排队中' => 'pending',
            '进行中'          => 'processing',
            '已完成'          => 'completed',
            '创建失败', '失败', '暂停' => 'failed',
            default           => '',
        };
    }

    /**
     * 格式化 API+本地合并的单条数据
     */
    private function formatStudyOrderItem(array $apiOrder, ?\StudyOrder $localOrder, string $username): array
    {
        return [
            'id'                => $localOrder->id ?? null,
            'platform_order_id' => $apiOrder['order_id'] ?? '',
            'course_name'       => $apiOrder['course_name'] ?? ($localOrder->course_name ?? ''),
            'school'            => $apiOrder['school'] ?? ($localOrder->school_name ?? ''),
            'order_status'      => $apiOrder['status'] ?? ($localOrder->order_status ?? 'pending'),
            'progress'          => $apiOrder['progress'] ?? '0%',
            'remarks'           => $apiOrder['remarks'] ?? '',
            'has_error'         => $localOrder->has_error ?? false,
            'error_message'     => $localOrder->error_message ?? null,
            'started_at'        => $localOrder?->started_at?->format('Y-m-d H:i'),
            'completed_at'      => $localOrder?->completed_at?->format('Y-m-d H:i'),
            'has_local_data'    => $localOrder !== null,
            'username'          => $username,
        ];
    }

    /**
     * 格式化纯本地数据的单条
     */
    private function formatLocalOnlyItem(\StudyOrder $lo, string $username): array
    {
        return [
            'id'                => $lo->id,
            'platform_order_id' => $lo->platform_order_id,
            'course_name'       => $lo->course_name,
            'school'            => $lo->school_name ?? '',
            'order_status'      => $lo->order_status,
            'progress'          => '0%',
            'remarks'           => '',
            'has_error'         => $lo->has_error,
            'error_message'     => $lo->error_message,
            'started_at'        => $lo->started_at?->format('Y-m-d H:i'),
            'completed_at'      => $lo->completed_at?->format('Y-m-d H:i'),
            'has_local_data'    => true,
            'username'          => $username,
        ];
    }
}
