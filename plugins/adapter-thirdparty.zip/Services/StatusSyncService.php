<?php

namespace ThirdParty\Services;

use App\Core\Event\OrderFulfilled;
use App\Core\Plugin\FulfillResult;
use App\Models\PaymentOrder;

/**
 * 订单状态同步服务
 *
 * 定时巡检未完成的 StudyOrder，通过第三方 API 同步最新状态。
 * 检测到全部课程完成时派发 OrderFulfilled 事件（触发邮件通知）。
 *
 * 对应旧项目：WangKeLava/app/Console/Commands/CheckOrderStatusCommand.php
 */
class StatusSyncService
{
    private string $pluginId = 'adapter-thirdparty';

    /**
     * 执行完整状态同步
     *
     * 1. 查所有未完成 StudyOrder
     * 2. 按 study_username 分组
     * 3. 每个用户调 queryProgress() 批量同步
     * 4. 检查是否有订单全部完成 → 派发事件 + 更新通知状态
     *
     * @return array 同步结果统计
     */
    public function syncAll(): array
    {
        $logger = plugin_context($this->pluginId)->logger();
        $logger->info('开始定时状态同步');

        // 查所有未完成的 StudyOrder，按 study_username 分组
        $pendingOrders = \StudyOrder::whereNotIn('order_status', ['completed', 'failed'])
            ->get()
            ->groupBy('study_username');

        $logger->info('定时同步：待同步用户数', [
            'user_count' => $pendingOrders->count(),
            'total_pending_orders' => $pendingOrders->flatten()->count(),
        ]);

        $stats = [
            'users_checked'    => 0,
            'orders_updated'   => 0,
            'orders_completed' => 0,
            'missing_fulfill_alerts' => 0,
            'notify_sent'      => 0,
            'errors'           => 0,
        ];

        foreach ($pendingOrders as $username => $studyOrders) {
            if (empty($username)) {
                $logger->debug('定时同步：跳过空用户名');
                continue;
            }

            $stats['users_checked']++;
            $logger->debug('定时同步：开始同步用户', [
                'username' => $username,
                'order_count' => $studyOrders->count(),
            ]);

            try {
                $updated = $this->syncUserOrders($username, $studyOrders);
                $stats['orders_updated'] += $updated;
                $logger->info('定时同步：用户同步完成', [
                    'username' => $username,
                    'updated' => $updated,
                ]);
            } catch (\Exception $e) {
                $stats['errors']++;
                $logger->error('定时同步：用户状态同步失败', [
                    'username' => $username,
                    'error'    => $e->getMessage(),
                    'exception_class' => get_class($e),
                ]);
            }
        }

        $stats['missing_fulfill_alerts'] = $this->detectMissingFulfillOrders();

        // 检查是否有 PaymentOrder 的全部 StudyOrder 已完成
        $notified = $this->checkAndNotifyCompleted();
        $stats['orders_completed'] = $notified['completed'];
        $stats['notify_sent'] = $notified['notified'];

        $logger->info('定时状态同步完成', $stats);

        return $stats;
    }

    /**
     * 同步单个用户的所有 StudyOrder 状态
     *
     * @param string $username 学习账号
     * @param \Illuminate\Support\Collection $studyOrders 该用户的 StudyOrder 集合
     * @return int 更新的记录数
     */
    private function syncUserOrders(string $username, $studyOrders): int
    {
        $logger = plugin_context($this->pluginId)->logger();
        $service = new \SubjectService();

        $updated = 0;
        $errors = 0;
        $failedItems = [];

        // 逐单调 /api/refresh 获取最新进度（而非仅查询缓存数据）
        foreach ($studyOrders as $studyOrder) {
            if (empty($studyOrder->platform_order_id)) {
                $logger->debug('定时同步跳过：无平台订单号', [
                    'study_order_id' => $studyOrder->id,
                    'username' => $username,
                ]);
                continue;
            }

            try {
                $refreshResult = $service->refreshProgress(
                    $studyOrder->platform_order_id,
                    $username
                );

                $orderData = $refreshResult['order'] ?? null;
                if (!$orderData) {
                    $logger->debug('定时同步：刷新未返回数据', [
                        'study_order_id' => $studyOrder->id,
                        'platform_order_id' => $studyOrder->platform_order_id,
                    ]);
                    continue;
                }

                $newStatus = QueryService::mapApiStatus($orderData['status'] ?? '');
                if (empty($newStatus) || $newStatus === $studyOrder->order_status) {
                    continue;
                }

                $logger->info('定时同步：更新订单状态', [
                    'study_order_id' => $studyOrder->id,
                    'platform_order_id' => $studyOrder->platform_order_id,
                    'old_status' => $studyOrder->order_status,
                    'new_status' => $newStatus,
                    'api_status_raw' => $orderData['status'] ?? '',
                    'progress' => $orderData['progress'] ?? '',
                ]);

                $studyOrder->update([
                    'order_status' => $newStatus,
                    'completed_at' => $newStatus === 'completed' ? now() : $studyOrder->completed_at,
                ]);
                $updated++;
            } catch (\Exception $e) {
                $errors++;
                $logger->warning('定时同步：单条刷新失败', [
                    'study_order_id' => $studyOrder->id,
                    'platform_order_id' => $studyOrder->platform_order_id,
                    'username' => $username,
                    'error' => $e->getMessage(),
                ]);
                $failedItems[] = [
                    'order_no' => $studyOrder->paymentOrder?->order_no ?? '',
                    'study_order_id' => $studyOrder->id,
                    'platform_order_id' => $studyOrder->platform_order_id,
                    'course_name' => $studyOrder->course_name,
                    'reason' => $e->getMessage(),
                ];
            }
        }

        if ($errors > 0) {
            $logger->warning('定时同步：用户同步部分失败', [
                'username' => $username,
                'updated' => $updated,
                'errors' => $errors,
            ]);
            $this->notifyAdminAboutSyncFailure(
                subject: "[ThirdParty] 用户同步部分失败：{$username}",
                body: "学习账号 {$username} 的状态同步出现部分失败，成功更新 {$updated} 条，失败 {$errors} 条。",
                data: [
                    'study_username' => $username,
                    'updated_count' => $updated,
                    'error_count' => $errors,
                    'sync_scope' => 'user_partial',
                    'details' => $failedItems,
                ],
                tags: ['sync', 'partial-failure', 'internal'],
                dedupeKey: "adapter-thirdparty.sync.user_partial:{$username}",
            );
        }

        return $updated;
    }

    /**
     * 检测“已支付但学习单未完整落库”的订单并通知管理员。
     *
     * 设计目标：
     * - 不改变支付主链路
     * - 不自动补单
     * - 只把隐性漏履约变成可观测、可人工处理的问题
     */
    private function detectMissingFulfillOrders(): int
    {
        $logger = plugin_context($this->pluginId)->logger();
        $graceMinutes = max(1, (int) plugin_context($this->pluginId)->config('missing_fulfill_grace_minutes', 5));
        $cutoff = now()->subMinutes($graceMinutes);

        $orders = PaymentOrder::query()
            ->where('payment_status', PaymentOrder::STATUS_PAID)
            ->where('fulfill_status', PaymentOrder::FULFILL_PENDING)
            ->where('created_at', '<=', $cutoff)
            ->get();

        $alerts = 0;

        foreach ($orders as $order) {
            $product = $order->product;
            if (($product->product_type ?? '') !== 'course') {
                continue;
            }

            $adapterData = $order->fulfill_data['adapter_data'] ?? [];
            $expectedCourseCount = max(1, (int) ($adapterData['course_count'] ?? 1));
            $createdCourseCount = \StudyOrder::where('payment_order_id', $order->id)->count();

            if ($createdCourseCount >= $expectedCourseCount) {
                continue;
            }

            $missingCount = $expectedCourseCount - $createdCourseCount;

            $logger->warning('检测到已支付订单学习单缺失', [
                'order_no' => $order->order_no,
                'payment_order_id' => $order->id,
                'expected_course_count' => $expectedCourseCount,
                'created_course_count' => $createdCourseCount,
                'missing_count' => $missingCount,
                'grace_minutes' => $graceMinutes,
            ]);

            $this->notifyAdminAboutSyncFailure(
                subject: "[ThirdParty] 发现疑似漏履约订单：{$order->order_no}",
                body: "订单 {$order->order_no} 已支付超过 {$graceMinutes} 分钟，预期 {$expectedCourseCount} 门课程，当前仅落库 {$createdCourseCount} 门。请检查后按需手动补单。",
                data: [
                    'order_no' => $order->order_no,
                    'payment_order_id' => $order->id,
                    'product_name' => $order->product_name,
                    'amount' => (string) $order->final_amount,
                    'notification_email' => $order->notification_email ?? '',
                    'expected_course_count' => $expectedCourseCount,
                    'created_course_count' => $createdCourseCount,
                    'missing_count' => $missingCount,
                    'study_username' => (string) ($adapterData['study_username'] ?? ''),
                    'sync_scope' => 'missing_fulfill',
                ],
                tags: ['fulfill', 'missing-study-order', 'internal'],
                dedupeKey: "adapter-thirdparty.fulfill.missing:{$order->order_no}",
            );

            $alerts++;
        }

        return $alerts;
    }

    /**
     * 检查已支付但未通知的订单，若全部课程完成则派发事件
     *
     * 对应旧项目：CheckOrderStatusCommand::checkAndNotifyCompletedOrders()
     *
     * @return array ['completed' => int, 'notified' => int]
     */
    private function checkAndNotifyCompleted(): array
    {
        $logger = plugin_context($this->pluginId)->logger();

        // 只处理“待通知”订单，已被其他进程抢占（processing）的订单跳过。
        $orders = PaymentOrder::where('payment_status', PaymentOrder::STATUS_PAID)
            ->where('is_notified', PaymentOrder::NOTIFY_PENDING)
            ->get();

        $completed = 0;
        $notified = 0;

        foreach ($orders as $order) {
            $studyOrders = \StudyOrder::byPaymentOrderId($order->id)->get();
            if ($studyOrders->isEmpty()) {
                continue;
            }

            // 检查是否全部完成
            $allCompleted = $studyOrders->every(fn($so) => $so->order_status === 'completed');
            if (!$allCompleted) {
                continue;
            }

            $completed++;

            // 更新履约状态
            if ($order->fulfill_status !== PaymentOrder::FULFILL_SUCCESS) {
                $order->update(['fulfill_status' => PaymentOrder::FULFILL_SUCCESS]);
            }

            // 抢占通知发送资格：仅第一个将 is_notified:0 -> 2 的进程可以继续发送
            $claimed = $order->getConnection()->transaction(function () use ($order) {
                return PaymentOrder::query()
                    ->whereKey($order->id)
                    ->where('is_notified', PaymentOrder::NOTIFY_PENDING)
                    ->lockForUpdate()
                    ->update(['is_notified' => PaymentOrder::NOTIFY_PROCESSING]) === 1;
            });

            if (!$claimed) {
                $logger->debug('完成通知抢占失败，跳过（可能被其他进程处理）', [
                    'order_no' => $order->order_no,
                ]);
                continue;
            }

            // 派发 OrderFulfilled 事件（框架统一监听并分发到通知渠道）
            try {
                $result = FulfillResult::success('全部课程已完成', [
                    'study_order_count' => $studyOrders->count(),
                    'source'            => 'status_sync',
                    'course_list'       => $studyOrders
                        ->pluck('course_name')
                        ->filter(static fn ($name) => is_string($name) && trim($name) !== '')
                        ->values()
                        ->all(),
                ]);
                event(new OrderFulfilled($order, $result));

                // 订单级通知状态由框架统一监听分发结果后更新
                $order->refresh();
                if ((int) $order->is_notified === 1) {
                    $notified++;
                }

                $logger->info('全部课程完成，已派发通知', [
                    'order_no'     => $order->order_no,
                    'course_count' => $studyOrders->count(),
                    'is_notified'  => (int) $order->is_notified,
                ]);
            } catch (\Exception $e) {
                // 通知失败：释放抢占标记，允许下次扫描重试
                $order->markNotificationFailed($e->getMessage(), true);
                $logger->error('完成通知派发失败', [
                    'order_no' => $order->order_no,
                    'error'    => $e->getMessage(),
                ]);
            }
        }

        return ['completed' => $completed, 'notified' => $notified];
    }

    /**
     * 统一发送管理员同步告警。
     *
     * 同步失败属于运维侧问题，统一使用 internal 受众。
     *
     * @param array<string, mixed> $data
     * @param array<int, string> $tags
     */
    private function notifyAdminAboutSyncFailure(
        string $subject,
        string $body,
        array $data,
        array $tags,
        string $dedupeKey,
    ): void {
        plugin_context($this->pluginId)->notifier()->internal(
            type: 'order.sync_failed',
            subject: $subject,
            body: $body,
            data: $data,
            options: [
                'level' => 'warning',
                'tags' => $tags,
                'dedupe_key' => $dedupeKey,
            ],
        );
    }
}
