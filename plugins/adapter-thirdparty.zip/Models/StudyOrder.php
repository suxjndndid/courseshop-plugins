<?php

/**
 * 学习订单 Eloquent 模型
 *
 * 无命名空间（插件通过 require_once 加载）。
 * 对应 study_orders 表，记录每条课程代刷订单的状态和进度。
 *
 * Eloquent 模型说明：
 * - 继承 Model 获得 ORM 能力（自动映射表字段为对象属性）
 * - $fillable 白名单：只允许这些字段通过 create()/update() 批量赋值
 * - $casts 类型转换：查询时自动将数据库字段转为 PHP 类型
 * - 关系方法（belongsTo）：定义与 PaymentOrder 的一对多关系
 * - Scope 方法：可复用的查询约束，链式调用如 StudyOrder::pending()->get()
 */

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\PaymentOrder;

class StudyOrder extends Model
{
    protected $table = 'study_orders';

    protected $fillable = [
        'payment_order_id',
        'platform_id',
        'platform_order_id',
        'platform_course_id',
        'course_name',
        'study_username',
        'study_password',
        'school_name',
        'order_status',
        'has_error',
        'error_message',
        'started_at',
        'completed_at',
    ];

    /**
     * $casts 属性类型转换：
     * - 'boolean'：数据库 tinyint(1) → PHP bool
     * - 'datetime'：数据库 datetime → Carbon 实例（支持 ->format() 等方法）
     */
    protected $casts = [
        'has_error' => 'boolean',
        'started_at' => 'datetime',
        'completed_at' => 'datetime',
    ];

    // ==================== 关系 ====================

    /**
     * 所属支付订单（多对一关系）
     *
     * belongsTo() 定义"多对一"关系：多条 StudyOrder 对应同一条 PaymentOrder。
     * 用法：$studyOrder->paymentOrder 自动查询关联的支付订单。
     */
    public function paymentOrder(): BelongsTo
    {
        return $this->belongsTo(PaymentOrder::class);
    }

    // ==================== Query Scopes ====================

    /**
     * Scope：按支付订单 ID 查询
     *
     * Scope 说明：以 scope 为前缀的方法可在查询时以静态方式调用。
     * 用法：StudyOrder::byPaymentOrderId(123)->get()
     * 等价于：StudyOrder::where('payment_order_id', 123)->get()
     *
     * @param \Illuminate\Database\Eloquent\Builder $query 查询构造器（框架自动注入）
     * @param int $paymentOrderId 支付订单 ID
     */
    public function scopeByPaymentOrderId($query, int $paymentOrderId)
    {
        return $query->where('payment_order_id', $paymentOrderId);
    }

    /**
     * Scope：待处理的订单
     */
    public function scopePending($query)
    {
        return $query->where('order_status', 'pending');
    }

    /**
     * Scope：已完成的订单
     */
    public function scopeCompleted($query)
    {
        return $query->where('order_status', 'completed');
    }

    /**
     * Scope：有错误的订单
     */
    public function scopeWithErrors($query)
    {
        return $query->where('has_error', true);
    }
}
