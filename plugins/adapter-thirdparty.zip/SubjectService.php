<?php

/**
 * 刷课平台 API 服务
 *
 * 从老项目 WangKeLava/app/Services/ThirdParty/SubjectService.php 迁移。
 * 核心变更：
 * - 无命名空间（插件通过 require_once 加载）
 * - 使用 plugin_config() 三层合并读取配置（DB > .env > 默认值），
 *   替代老项目的 config('api...') 方式
 * - 日志统一写入 'business' 通道
 *
 * 封装第三方刷课平台的 API 调用：查课、下单、查询进度、刷新进度、补单。
 */

use Illuminate\Support\Facades\Http;

class SubjectService
{
    /** @var string API 密钥 */
    private string $apiKey;

    /** @var string API 基础 URL */
    private string $baseUrl;

    /** @var int 请求超时秒数 */
    private int $timeout;

    public function __construct()
    {
        // plugin_config() 三层合并：DB settings 表 > .env 变量 > 插件默认值
        $this->apiKey = plugin_context('adapter-thirdparty')->config('api_key', '');
        $this->baseUrl = plugin_context('adapter-thirdparty')->config('api_base_url', '');
        $this->timeout = (int) plugin_context('adapter-thirdparty')->config('api_timeout', 60);

        $logger = plugin_context('adapter-thirdparty')->logger();
        $logger->debug('SubjectService 初始化', [
            'has_api_key' => !empty($this->apiKey),
            'base_url' => $this->baseUrl,
            'timeout' => $this->timeout,
        ]);

        if (empty($this->apiKey)) {
            $logger->error('SubjectService 初始化失败：API密钥未配置');
            throw new Exception('API密钥未配置，请在后台【课程对接设置】中配置');
        }

        if (empty($this->baseUrl)) {
            $logger->error('SubjectService 初始化失败：API基础URL未配置');
            throw new Exception('API基础URL未配置，请在后台【课程对接设置】中配置');
        }
    }

    /**
     * 发送 API 请求的通用方法
     *
     * 使用 Laravel HTTP Client（基于 Guzzle）发起 POST 请求。
     * Http::timeout() 设置连接+读取超时，withOptions() 强制 IPv4 避免阻塞。
     *
     * @param string $endpoint API 端点路径（如 '/api/get'）
     * @param array $params 请求参数
     * @param string $action 操作名称（用于日志前缀）
     * @param array $logContext 日志附加上下文
     * @return array API 返回的 JSON 数据
     * @throws Exception
     */
    private function sendRequest(string $endpoint, array $params, string $action, array $logContext = []): array
    {
        $startTime = microtime(true);
        $logger = plugin_context('adapter-thirdparty')->logger();
        $fullUrl = $this->baseUrl . $endpoint;

        $logger->info("{$action} 开始发送API请求", array_merge($logContext, [
            'endpoint' => $endpoint,
            'url' => $fullUrl,
            'timeout' => $this->timeout,
            'param_keys' => array_keys($params),
        ]));

        try {
            $response = Http::timeout($this->timeout)
                ->withOptions([
                    'http_version' => CURL_HTTP_VERSION_1_1,
                    'curl' => [
                        CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
                    ],
                ])
                ->withHeaders([
                    'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
                ])
                ->post($fullUrl, $params);

            $duration = round(microtime(true) - $startTime, 3);

            if (!$response->successful()) {
                $logger->error("{$action} HTTP请求失败", array_merge($logContext, [
                    'status' => $response->status(),
                    'endpoint' => $endpoint,
                    'response_body' => mb_substr($response->body(), 0, 500),
                    'duration' => $duration . '秒',
                ]));
                throw new Exception("{$action}请求失败，HTTP状态码：{$response->status()}");
            }

            $data = $response->json();

            $logger->debug("{$action} 收到API响应", array_merge($logContext, [
                'endpoint' => $endpoint,
                'http_status' => $response->status(),
                'response_code' => $data['code'] ?? null,
                'response_msg' => $data['msg'] ?? null,
                'data_count' => isset($data['data']) ? (is_array($data['data']) ? count($data['data']) : 'non-array') : 'no-data',
                'duration' => $duration . '秒',
            ]));

            if (!is_array($data) || !isset($data['code'])) {
                $logger->error("{$action} API返回格式错误", array_merge($logContext, [
                    'endpoint' => $endpoint,
                    'response' => mb_substr($response->body(), 0, 1000),
                    'duration' => $duration . '秒',
                ]));
                throw new Exception("{$action} API返回数据格式错误");
            }

            if ($data['code'] !== 1) {
                $errorMsg = $data['msg'] ?? '未知错误';
                $logger->warning("{$action} 业务失败", array_merge($logContext, [
                    'code' => $data['code'],
                    'message' => $errorMsg,
                    'endpoint' => $endpoint,
                    'duration' => $duration . '秒',
                ]));
                throw new Exception($errorMsg);
            }

            $logger->info("{$action} API请求成功", array_merge($logContext, [
                'endpoint' => $endpoint,
                'duration' => $duration . '秒',
            ]));

            return $data;

        } catch (Exception $e) {
            $duration = round(microtime(true) - $startTime, 3);
            if (!$this->isLoggedException($e->getMessage(), $action)) {
                $logger->error("{$action} 异常", array_merge($logContext, [
                    'error' => $e->getMessage(),
                    'exception_class' => get_class($e),
                    'endpoint' => $endpoint,
                    'duration' => $duration . '秒',
                ]));
            }
            throw $e;
        }
    }

    /**
     * 判断异常消息是否已被 sendRequest 内部记录（避免重复记录日志）
     */
    private function isLoggedException(string $message, string $action): bool
    {
        return str_contains($message, "{$action}失败")
            || str_contains($message, "{$action}请求失败")
            || str_contains($message, "{$action}业务失败");
    }

    /**
     * 验证必需参数，缺少时抛异常
     *
     * @param array $data 待验证的数据
     * @param array $requiredFields 必需字段名列表
     * @throws Exception
     */
    private function validateRequiredFields(array $data, array $requiredFields): void
    {
        foreach ($requiredFields as $field) {
            if (!isset($data[$field]) || $data[$field] === '' || $data[$field] === null) {
                throw new Exception("缺少必需参数：{$field}");
            }
        }
    }

    /**
     * 获取课程列表
     *
     * @param string $platform 平台课程 ID
     * @param string $user 用户账号
     * @param string $pass 用户密码
     * @param string|null $school 用户所在学校（可选）
     * @return array 格式化后的课程数据
     * @throws Exception
     */
    public function getCourses(string $platform, string $user, string $pass, ?string $school = null): array
    {
        $this->validateRequiredFields(
            ['platform' => $platform, 'user' => $user, 'pass' => $pass],
            ['platform', 'user', 'pass']
        );

        $params = [
            'token' => $this->apiKey,
            'platform' => $platform,
            'user' => $user,
            'pass' => $pass,
        ];

        if (!empty($school)) {
            $params['school'] = $school;
        }

        $logContext = [
            'platform' => $platform,
            'user' => $user,
        ];

        $result = $this->sendRequest('/api/get', $params, '查询课程列表', $logContext);

        // array_map：对数组每个元素执行回调，返回新数组
        $courses = array_map(function ($course) {
            return [
                'course_id' => $course['id'] ?? '',
                'course_name' => $course['name'] ?? '',
                'teacher_name' => $course['teachername'] ?? '',
                'class_name' => $course['class'] ?? '',
                'start_date' => $course['startDate'] ?? '',
                'end_date' => $course['endDate'] ?? '',
                'image_url' => $course['imageurl'] ?? '',
            ];
        }, $result['data'] ?? []);

        plugin_context('adapter-thirdparty')->logger()->info('课程列表查询成功', [
            'user' => $user,
            'course_count' => count($courses),
        ]);

        return [
            'courses' => $courses,
            'user_name' => $result['userName'] ?? '',
            'user_info' => $result['userinfo'] ?? '',
            'term_info' => $result['termInfo'] ?? null,
            'statistics' => [
                'total' => $result['statistics']['total'] ?? count($courses),
                'fetched' => count($courses),
            ],
        ];
    }

    /**
     * 课程下单
     *
     * @param array $orderData 下单数据，必须包含 platform/user/pass，kcname/kcid 至少一个
     * @return array 格式化后的订单数据
     * @throws Exception
     */
    public function createOrder(array $orderData): array
    {
        // kcid 和 kcname 至少需要一个（部分课程源只返回其中之一）
        $this->validateRequiredFields($orderData, ['platform', 'user', 'pass']);
        if (empty($orderData['kcid']) && empty($orderData['kcname'])) {
            throw new Exception('缺少必需参数：kcid 和 kcname 至少需要一个');
        }

        $params = [
            'token' => $this->apiKey,
            'platform' => $orderData['platform'],
            'user' => $orderData['user'],
            'pass' => $orderData['pass'],
            'kcname' => $orderData['kcname'] ?? '',
            'kcid' => $orderData['kcid'] ?? '',
        ];

        if (!empty($orderData['school'])) {
            $params['school'] = $orderData['school'];
        }

        $logContext = [
            'platform' => $orderData['platform'],
            'user' => $orderData['user'],
            'kcname' => $orderData['kcname'] ?? '',
        ];

        $result = $this->sendRequest('/api/add', $params, '创建课程订单', $logContext);

        $formattedResult = [
            'order_id' => $result['id'] ?? '',
            'username' => $result['user'] ?? $orderData['user'],
            'course_name' => $result['kcname'] ?? $orderData['kcname'] ?? '',
            'message' => $result['msg'] ?? '',
        ];

        plugin_context('adapter-thirdparty')->logger()->info('API课程订单创建成功', [
            'order_id' => $formattedResult['order_id'],
            'course_name' => $formattedResult['course_name'],
        ]);

        return $formattedResult;
    }

    /**
     * 查询学习进度
     *
     * @param string $username 用户账号
     * @return array 格式化后的进度数据
     * @throws Exception
     */
    public function queryProgress(string $username): array
    {
        $this->validateRequiredFields(['username' => $username], ['username']);

        $logger = plugin_context('adapter-thirdparty')->logger();
        $logger->info('开始查询学习进度', ['username' => $username, 'endpoint' => '/api/query']);

        $params = [
            'username' => $username,
        ];

        $result = $this->sendRequest('/api/query', $params, '查询学习进度', ['username' => $username]);

        $orders = array_map(function ($order) {
            return [
                'order_id' => $order['id'] ?? '',
                'platform_id' => $order['cid'] ?? '',
                'platform_name' => $order['ptname'] ?? '',
                'username' => $order['user'] ?? '',
                'course_name' => $order['kcname'] ?? '',
                'school' => $order['school'] ?? '自动识别',
                'created_at' => $order['addtime'] ?? '',
                'status' => $order['status'] ?? '',
                'progress' => $order['process'] ?? '0%',
                'remarks' => $order['remarks'] ?? '',
                'order_no' => $order['order'] ?? '',
            ];
        }, $result['data'] ?? []);

        $logger->info('查询学习进度完成', [
            'username' => $username,
            'order_count' => count($orders),
            'statuses' => array_count_values(array_column($orders, 'status')),
        ]);

        return [
            'orders' => $orders,
            'total' => count($orders),
            'message' => $result['msg'] ?? '',
        ];
    }

    /**
     * 刷新学习进度（从第三方平台获取最新状态）
     *
     * @param string $orderId 第三方平台订单 ID
     * @param string $username 用户账号
     * @return array 格式化后的进度数据
     * @throws Exception
     */
    public function refreshProgress(string $orderId, string $username): array
    {
        $this->validateRequiredFields(
            ['id' => $orderId, 'username' => $username],
            ['id', 'username']
        );

        $logger = plugin_context('adapter-thirdparty')->logger();
        $logger->info('开始刷新学习进度', [
            'order_id' => $orderId,
            'username' => $username,
            'endpoint' => '/api/refresh',
        ]);

        $params = [
            'id' => $orderId,
            'username' => $username,
        ];

        $logContext = [
            'order_id' => $orderId,
            'username' => $username,
        ];

        $result = $this->sendRequest('/api/refresh', $params, '更新学习进度', $logContext);

        $orderData = $result['data'][0] ?? null;
        $formattedOrder = null;

        if ($orderData) {
            $formattedOrder = [
                'order_id' => $orderData['id'] ?? '',
                'platform_name' => $orderData['ptname'] ?? '',
                'username' => $orderData['user'] ?? '',
                'course_name' => $orderData['kcname'] ?? '',
                'status' => $orderData['status'] ?? '',
                'progress' => $orderData['process'] ?? '',
                'remarks' => $orderData['remarks'] ?? '',
            ];

            $logger->info('刷新学习进度成功', [
                'order_id' => $orderId,
                'username' => $username,
                'new_status' => $formattedOrder['status'],
                'progress' => $formattedOrder['progress'],
                'remarks' => mb_substr($formattedOrder['remarks'], 0, 100),
            ]);
        } else {
            $logger->warning('刷新学习进度：API未返回订单数据', [
                'order_id' => $orderId,
                'username' => $username,
                'raw_data_count' => count($result['data'] ?? []),
            ]);
        }

        return [
            'order' => $formattedOrder,
            'message' => $result['msg'] ?? '',
        ];
    }

    /**
     * 课程补单（重新下单）
     *
     * @param string $orderId 第三方平台订单 ID
     * @param string $username 用户账号
     * @return array 格式化后的结果
     * @throws Exception
     */
    public function resetOrder(string $orderId, string $username): array
    {
        $this->validateRequiredFields(
            ['id' => $orderId, 'username' => $username],
            ['id', 'username']
        );

        $params = [
            'id' => $orderId,
            'username' => $username,
        ];

        $logContext = [
            'order_id' => $orderId,
            'username' => $username,
        ];

        $result = $this->sendRequest('/api/reset', $params, '课程补单', $logContext);

        plugin_context('adapter-thirdparty')->logger()->info('课程补单成功', $logContext);

        return [
            'success' => true,
            'order_id' => $orderId,
            'username' => $username,
            'message' => $result['msg'] ?? '',
        ];
    }
}
