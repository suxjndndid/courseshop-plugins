<?php

namespace ThirdParty\Controllers;

use App\Models\Setting;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;

/**
 * 后台设置控制器
 *
 * 管理第三方课程对接插件的 API 配置（api_key / api_base_url / api_timeout）。
 */
class SettingsController
{
    /**
     * 显示设置页
     */
    public function index()
    {
        $settings = Setting::getGroup('adapter-thirdparty');
        return view('adapter-thirdparty::settings', ['settings' => $settings]);
    }

    /**
     * 保存设置
     */
    public function save(Request $request)
    {
        $request->validate([
            'api_base_url' => 'required|url|max:255',
            'api_timeout'  => 'required|integer|min:5|max:300',
        ]);

        Setting::setGroup('adapter-thirdparty', [
            'api_base_url' => $request->input('api_base_url'),
            'api_timeout'  => $request->input('api_timeout'),
        ]);

        // api_key 是敏感字段，只在有输入时更新（留空不修改）
        if ($request->filled('api_key')) {
            Setting::setGroup('adapter-thirdparty', [
                'api_key' => $request->input('api_key'),
            ]);
        }

        app(ActivityLogService::class)->log('setting', '更新第三方课程对接配置');

        return redirect()->route('admin.plugin.adapter-thirdparty')
            ->with('success', '课程对接配置已保存');
    }
}
