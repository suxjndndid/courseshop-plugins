<?php

namespace ThirdParty\Controllers;

use App\Helpers\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * 后台刷课订单管理控制器
 *
 * 提供刷课订单列表、搜索、筛选、状态修改、同步操作。
 * 对应旧项目：WangKeLava/app/Livewire/Admin/StudyOrderList.php
 */
class StudyOrderController
{
    /**
     * 刷课订单列表页
     */
    public function index(Request $request)
    {
        $query = \StudyOrder::with('paymentOrder');

        // 搜索
        if ($search = $request->input('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('study_username', 'like', "%{$search}%")
                  ->orWhere('course_name', 'like', "%{$search}%")
                  ->orWhere('platform_order_id', 'like', "%{$search}%");
            });
        }

        // 状态筛选
        if ($status = $request->input('status')) {
            $query->where('order_status', $status);
        }

        // 错误筛选
        if ($request->input('has_error') === '1') {
            $query->where('has_error', true);
        }

        $studyOrders = $query->orderByDesc('created_at')->paginate(20);

        // 统计
        $stats = [
            'total'      => \StudyOrder::count(),
            'processing' => \StudyOrder::where('order_status', 'processing')->count(),
            'completed'  => \StudyOrder::where('order_status', 'completed')->count(),
            'failed'     => \StudyOrder::where('order_status', 'failed')->count(),
            'errors'     => \StudyOrder::where('has_error', true)->count(),
        ];

        return view('adapter-thirdparty::study-orders', [
            'studyOrders' => $studyOrders,
            'stats'       => $stats,
            'search'      => $request->input('search', ''),
            'status'      => $request->input('status', ''),
            'hasError'    => $request->input('has_error', ''),
        ]);
    }

    /**
     * AJAX: 手动修改状态
     */
    public function updateStatus(Request $request): JsonResponse
    {
        $logger = plugin_context('adapter-thirdparty')->logger();
        $logger->info('后台手动修改订单状态请求', [
            'study_order_id' => $request->input('id'),
            'target_status' => $request->input('status'),
        ]);

        $request->validate([
            'id'     => 'required|integer',
            'status' => 'required|in:pending,processing,completed,failed',
        ]);

        try {
            $studyOrder = \StudyOrder::findOrFail($request->input('id'));
            $oldStatus = $studyOrder->order_status;

            $studyOrder->update([
                'order_status' => $request->input('status'),
                'completed_at' => $request->input('status') === 'completed' ? now() : $studyOrder->completed_at,
            ]);

            $logger->info('后台手动修改刷课订单状态成功', [
                'study_order_id' => $studyOrder->id,
                'course_name' => $studyOrder->course_name,
                'old_status'     => $oldStatus,
                'new_status'     => $request->input('status'),
            ]);

            app(\App\Services\ActivityLogService::class)->log(
                'study_order',
                "修改刷课订单状态: {$studyOrder->course_name} ({$oldStatus} → {$request->input('status')})"
            );

            return ApiResponse::success('状态已更新');
        } catch (\Exception $e) {
            $logger->error('后台修改订单状态失败', [
                'study_order_id' => $request->input('id'),
                'target_status' => $request->input('status'),
                'error' => $e->getMessage(),
            ]);
            return ApiResponse::error('状态更新失败: ' . $e->getMessage());
        }
    }

    /**
     * AJAX: 单用户同步
     *
     * 先调 /api/refresh 逐单刷新最新进度，再同步到本地。
     */
    public function syncUser(Request $request): JsonResponse
    {
        $logger = plugin_context('adapter-thirdparty')->logger();
        $logger->info('后台单用户同步请求', [
            'username' => $request->input('username'),
        ]);

        $request->validate([
            'username' => 'required|string|max:100',
        ]);

        try {
            $username = $request->input('username');

            // 获取该用户所有未完成的本地 StudyOrder
            $localOrders = \StudyOrder::where('study_username', $username)
                ->whereNotIn('order_status', ['completed', 'failed'])
                ->get();

            $logger->info('后台单用户同步：找到待同步订单', [
                'username' => $username,
                'pending_count' => $localOrders->count(),
            ]);

            $service = new \SubjectService();
            $updated = 0;
            $errors = 0;

            // 逐单调用 /api/refresh 获取最新进度
            foreach ($localOrders as $studyOrder) {
                if (empty($studyOrder->platform_order_id)) {
                    $logger->debug('后台同步跳过：无平台订单号', [
                        'study_order_id' => $studyOrder->id,
                    ]);
                    continue;
                }

                try {
                    $refreshResult = $service->refreshProgress(
                        $studyOrder->platform_order_id,
                        $username
                    );

                    $orderData = $refreshResult['order'] ?? null;
                    if ($orderData) {
                        $newStatus = \ThirdParty\Services\QueryService::mapApiStatus($orderData['status'] ?? '');
                        $oldStatus = $studyOrder->order_status;

                        if ($newStatus && $newStatus !== $oldStatus) {
                            $studyOrder->update([
                                'order_status' => $newStatus,
                                'completed_at' => $newStatus === 'completed' ? now() : $studyOrder->completed_at,
                            ]);
                            $updated++;

                            $logger->info('后台同步：订单状态已更新', [
                                'study_order_id' => $studyOrder->id,
                                'platform_order_id' => $studyOrder->platform_order_id,
                                'old_status' => $oldStatus,
                                'new_status' => $newStatus,
                                'progress' => $orderData['progress'] ?? '',
                            ]);
                        } else {
                            $logger->debug('后台同步：订单状态未变化', [
                                'study_order_id' => $studyOrder->id,
                                'platform_order_id' => $studyOrder->platform_order_id,
                                'current_status' => $oldStatus,
                                'api_status' => $orderData['status'] ?? '',
                            ]);
                        }
                    }
                } catch (\Exception $e) {
                    $errors++;
                    $logger->warning('后台同步：单条刷新失败', [
                        'study_order_id' => $studyOrder->id,
                        'platform_order_id' => $studyOrder->platform_order_id,
                        'error' => $e->getMessage(),
                    ]);
                }
            }

            $logger->info('后台单用户同步完成', [
                'username' => $username,
                'total_checked' => $localOrders->count(),
                'updated' => $updated,
                'errors' => $errors,
            ]);

            $msg = "同步完成，更新 {$updated} 条记录";
            if ($errors > 0) {
                $msg .= "，{$errors} 条失败";
            }
            return ApiResponse::success($msg);
        } catch (\Exception $e) {
            $logger->error('后台单用户同步异常', [
                'username' => $request->input('username'),
                'error' => $e->getMessage(),
                'exception_class' => get_class($e),
            ]);
            return ApiResponse::error('同步失败: ' . $e->getMessage());
        }
    }

    /**
     * AJAX: 全量同步
     */
    public function syncAll(): JsonResponse
    {
        $logger = plugin_context('adapter-thirdparty')->logger();
        $logger->info('后台全量同步请求');

        try {
            $syncService = new \ThirdParty\Services\StatusSyncService();
            $result = $syncService->syncAll();

            $logger->info('后台全量同步完成', $result);

            return ApiResponse::success('全量同步完成', $result);
        } catch (\Exception $e) {
            $logger->error('后台全量同步异常', [
                'error' => $e->getMessage(),
                'exception_class' => get_class($e),
            ]);
            return ApiResponse::error('全量同步失败: ' . $e->getMessage());
        }
    }

}
