<?php

/**
 * 学习订单表迁移
 *
 * 从老项目 WangKeLava 迁移，关键变更：
 * - order_status 改为 varchar（老项目用 tinyint），更具语义性
 * - 新增 has_error / error_message 字段，便于错误追踪
 * - 索引覆盖：payment_order_id, platform_order_id, order_status, has_error
 * - 使用 Laravel timestamps() 替代手动 created_at/updated_at 定义
 *
 * 匿名类迁移（return new class extends Migration）：
 * PHP 7.0+ 特性，避免迁移类名冲突。Laravel 自动为每个文件创建独立的匿名类实例。
 */

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('study_orders', function (Blueprint $table) {
            $table->id()->comment('学习订单ID，主键');
            $table->unsignedBigInteger('payment_order_id')->comment('关联支付订单ID');
            $table->string('platform_id', 100)->comment('平台标识');
            $table->string('platform_order_id', 100)->nullable()->comment('第三方刷课平台返回的订单ID');
            $table->string('platform_course_id', 100)->comment('第三方平台的课程ID');
            $table->string('course_name', 255)->comment('课程名称');
            $table->string('study_username', 100)->comment('学习账号用户名');
            $table->string('study_password', 255)->comment('学习账号密码（明文存储）');
            $table->string('school_name', 255)->nullable()->comment('学校名称');
            $table->string('order_status', 20)->default('pending')->comment('订单状态：pending/processing/completed/failed');
            $table->boolean('has_error')->default(false)->comment('是否有错误');
            $table->text('error_message')->nullable()->comment('错误信息');
            $table->datetime('started_at')->nullable()->comment('开始处理时间');
            $table->datetime('completed_at')->nullable()->comment('完成时间');
            $table->timestamps();
            $table->softDeletes();

            // 索引：加速常用查询
            $table->index('payment_order_id', 'idx_study_payment_order_id');
            $table->index('platform_order_id', 'idx_study_platform_order_id');
            $table->index('order_status', 'idx_study_order_status');
            $table->index('has_error', 'idx_study_has_error');

            // 外键约束：删除支付订单时限制（不允许删除有学习订单的支付订单）
            $table->foreign('payment_order_id')
                ->references('id')
                ->on('payment_orders')
                ->onDelete('restrict');
        });

        // 表注释仅在 MySQL 下生效，SQLite 不支持 COMMENT 语法
        if (DB::getDriverName() === 'mysql') {
            DB::statement("ALTER TABLE `study_orders` COMMENT = '学习订单表 — adapter-thirdparty 插件'");
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('study_orders');
    }
};
