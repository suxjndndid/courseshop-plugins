<?php

/**
 * study_orders 幂等唯一键
 *
 * 目标：防止同一 payment_order_id + platform_course_id 被重复插入，
 * 避免支付回调重入/并发导致重复履约记录。
 */

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('study_orders', function (Blueprint $table) {
            $table->unique(
                ['payment_order_id', 'platform_course_id'],
                'uk_study_payment_course'
            );
        });
    }

    public function down(): void
    {
        Schema::table('study_orders', function (Blueprint $table) {
            $table->dropUnique('uk_study_payment_course');
        });
    }
};
