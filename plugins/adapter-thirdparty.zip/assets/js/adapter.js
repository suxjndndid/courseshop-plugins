/**
 * ThirdParty 插件 — 课程选择交互脚本
 *
 * 功能：查课 AJAX → 渲染卡片式课程列表 → 勾选高亮 + 价格计算 → 收集 course_data[]
 * 配置从 window.__ADAPTER_THIRDPARTY_CONFIG__ 读取（由 adapter-form.blade.php 注入）。
 */
(function() {
    'use strict';

    const cfg = window.__ADAPTER_THIRDPARTY_CONFIG__ || {};
    const PLATFORM_ID = cfg.platformId || '';
    const COURSES_ROUTE = cfg.coursesRoute || '';
    const UNIT_PRICE = parseFloat(cfg.unitPrice) || 0;
    const CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]')?.content || '';

    let allCourses = [];

    const fetchBtn = document.getElementById('fetchCoursesBtn');
    const courseListContainer = document.getElementById('courseListContainer');
    const courseList = document.getElementById('courseList');
    const selectedCountEl = document.getElementById('selectedCount');
    const subtotalEl = document.getElementById('coursesSubtotal');
    const selectAllBtn = document.getElementById('selectAllBtn');
    const deselectAllBtn = document.getElementById('deselectAllBtn');

    // ==================== 查课 ====================

    /** 查课假进度定时器 */
    let queryProgressTimer = null;

    fetchBtn?.addEventListener('click', async function() {
        const username = document.getElementById('studyUsername')?.value?.trim();
        const password = document.getElementById('studyPassword')?.value;
        const school = document.getElementById('schoolName')?.value?.trim();

        if (!username) {
            shakeElement(document.getElementById('studyUsername'));
            return;
        }
        if (!password) {
            shakeElement(document.getElementById('studyPassword'));
            return;
        }

        // 启动假进度（卡在90%，收到数据后跳100%）
        fetchBtn.disabled = true;
        fetchBtn.classList.add('loading');
        let progress = 0;
        fetchBtn.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>查询中 0%';
        clearInterval(queryProgressTimer);
        queryProgressTimer = setInterval(() => {
            const remaining = 90 - progress;
            progress += remaining * 0.03;
            const rounded = Math.min(Math.round(progress), 90);
            fetchBtn.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>查询中 ' + rounded + '%';
        }, 100);

        try {
            const resp = await fetch(COURSES_ROUTE, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': CSRF_TOKEN,
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    platform_id: PLATFORM_ID,
                    username,
                    password,
                    school: school || undefined
                })
            });
            const result = await resp.json();

            // 收到数据，跳到100%
            clearInterval(queryProgressTimer);
            queryProgressTimer = null;
            fetchBtn.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>查询中 100%';

            if (!result.success || !result.data?.courses?.length) {
                showNotification(result.message || '未查询到课程，请检查账号密码', 'warning');
                return;
            }

            allCourses = result.data.courses;
            renderCourseList(allCourses);
            courseListContainer.style.display = 'block';
            courseListContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

            showNotification('查询到 ' + allCourses.length + ' 门课程', 'success');

        } catch (e) {
            clearInterval(queryProgressTimer);
            queryProgressTimer = null;
            showNotification('查询失败：' + (e.message || '网络错误'), 'error');
        } finally {
            // 延迟400ms恢复按钮，让用户看到100%
            setTimeout(function() {
                fetchBtn.classList.remove('loading');
                fetchBtn.disabled = false;
                fetchBtn.innerHTML = '<i class="bi bi-search me-1"></i>获取课程列表';
            }, 400);
        }
    });

    // ==================== 课程列表渲染（卡片式） ====================

    function renderCourseList(courses) {
        // 清除旧的隐藏字段
        document.querySelectorAll('.course-data-hidden').forEach(el => el.remove());

        courseList.innerHTML = courses.map((c, i) => {
            const teacher = c.teacher_name ? escapeHtml(c.teacher_name) : '';
            const className = c.class_name ? escapeHtml(c.class_name) : '';
            const dateRange = (c.start_date && c.end_date)
                ? escapeHtml(c.start_date) + ' ~ ' + escapeHtml(c.end_date)
                : '';

            return '<label class="course-card" for="course_' + i + '">'
                + '<input class="course-checkbox" type="checkbox" '
                + 'value="' + i + '" id="course_' + i + '" '
                + 'data-kid="' + escapeHtml(c.course_id) + '" '
                + 'data-kname="' + escapeHtml(c.course_name) + '">'
                + '<div class="course-card-body">'
                + '<div class="course-card-check"><i class="bi bi-check-lg"></i></div>'
                + '<div class="course-card-info">'
                + '<div class="course-card-name">' + escapeHtml(c.course_name) + '</div>'
                + (teacher ? '<div class="course-card-meta"><i class="bi bi-person me-1"></i>' + teacher + '</div>' : '')
                + (className ? '<div class="course-card-meta"><i class="bi bi-people me-1"></i>' + className + '</div>' : '')
                + (dateRange ? '<div class="course-card-meta"><i class="bi bi-calendar me-1"></i>' + dateRange + '</div>' : '')
                + '</div>'
                + '</div>'
                + '</label>';
        }).join('');

        // 绑定选中事件
        courseList.querySelectorAll('.course-checkbox').forEach(cb => {
            cb.addEventListener('change', updateSelection);
        });

        updateSelection();
    }

    // ==================== 选中更新 ====================

    function updateSelection() {
        const checked = courseList.querySelectorAll('.course-checkbox:checked');
        const count = checked.length;
        const subtotal = count * UNIT_PRICE;

        selectedCountEl.textContent = count;
        subtotalEl.textContent = '¥' + subtotal.toFixed(2);

        // 更新卡片选中态
        courseList.querySelectorAll('.course-card').forEach(card => {
            const cb = card.querySelector('.course-checkbox');
            card.classList.toggle('selected', cb?.checked);
        });

        // 清除旧隐藏字段
        document.querySelectorAll('.course-data-hidden').forEach(el => el.remove());

        // 为每门选中课程生成隐藏字段
        const form = fetchBtn?.closest('form')
            || document.getElementById('adapterFormThirdparty')?.closest('form')
            || document.querySelector('form');

        checked.forEach((cb, idx) => {
            const course = allCourses[cb.value];
            const school = document.getElementById('schoolName')?.value?.trim() || '';

            [
                { name: 'course_data[' + idx + '][kid]', value: course.course_id },
                { name: 'course_data[' + idx + '][kname]', value: course.course_name },
                { name: 'course_data[' + idx + '][school]', value: school },
            ].forEach(f => {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = f.name;
                input.value = f.value;
                input.className = 'course-data-hidden';
                if (form) form.appendChild(input);
            });
        });

        // 通知框架 product-detail.js 更新价格
        document.dispatchEvent(new CustomEvent('adapter:price-update', {
            detail: { courseCount: count, count: count, subtotal: subtotal }
        }));
    }

    // ==================== 全选/取消 ====================

    selectAllBtn?.addEventListener('click', function() {
        courseList.querySelectorAll('.course-checkbox').forEach(cb => cb.checked = true);
        updateSelection();
    });

    deselectAllBtn?.addEventListener('click', function() {
        courseList.querySelectorAll('.course-checkbox').forEach(cb => cb.checked = false);
        updateSelection();
    });

    // ==================== 工具 ====================

    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str || '';
        return div.innerHTML;
    }

    /** 输入框抖动提示（未填写时） */
    function shakeElement(el) {
        if (!el) return;
        el.focus();
        el.classList.add('shake');
        setTimeout(() => el.classList.remove('shake'), 500);
    }

    /** 使用全局通知（如可用），否则回退 alert */
    function showNotification(msg, type) {
        if (typeof window.showNotification === 'function') {
            window.showNotification(msg, type);
        } else if (type === 'error' || type === 'warning') {
            alert(msg);
        }
    }

    // 与 Self 适配器保持一致：初始未选课程时，基础金额应为 0，避免优惠券基价使用商品单价造成显示困惑。
    document.dispatchEvent(new CustomEvent('adapter:price-update', {
        detail: { courseCount: 0, count: 0, subtotal: 0 }
    }));
})();
