{{--
    课程对接订单表单 — adapter-form.blade.php

    由 ThirdPartyPlugin::renderAdapterForm() 渲染并通过 order_form.adapter_ui Hook 注入。
    接收变量：$platformId, $coursesRoute, $unitPrice, $adapterJsUrl
--}}

<div class="adapter-form-thirdparty" id="adapterFormThirdparty">
    {{-- 学习账号 --}}
    <div class="mb-3">
        <label class="form-label fw-semibold">
            <i class="bi bi-person-circle me-1"></i>学习账号 <span class="text-danger">*</span>
        </label>
        <input type="text"
               id="studyUsername"
               name="study_username"
               class="form-control"
               data-adapter-field="study_username"
               placeholder="请输入学习平台账号"
               required
               autocomplete="username">
    </div>

    {{-- 学习密码 --}}
    <div class="mb-3">
        <label class="form-label fw-semibold">
            <i class="bi bi-lock-fill me-1"></i>学习密码 <span class="text-danger">*</span>
        </label>
        <div class="input-group password-input-group">
            <input type="password"
                   id="studyPassword"
                   name="study_password"
                   class="form-control"
                   data-adapter-field="study_password"
                   placeholder="请输入学习平台密码"
                   required
                   autocomplete="current-password">
            <button type="button" class="btn btn-toggle-password" onclick="togglePasswordVisibility()">
                <i class="bi bi-eye" id="togglePasswordIcon"></i>
            </button>
        </div>
    </div>

    {{-- 学校名（可选） --}}
    <div class="mb-3">
        <label class="form-label fw-semibold">
            <i class="bi bi-building me-1"></i>学校名称 <span class="text-muted fw-normal">(可选)</span>
        </label>
        <input type="text"
               id="schoolName"
               name="school_name"
               class="form-control"
               data-adapter-field="school_name"
               placeholder="选填，部分平台需要">
    </div>

    {{-- 获取课程按钮 --}}
    <div class="mb-3">
        <button type="button"
                id="fetchCoursesBtn"
                class="btn btn-primary w-100 btn-fetch-courses">
            <i class="bi bi-search me-1"></i>获取课程列表
        </button>
    </div>

    {{-- 课程列表区域（默认隐藏，查课成功后显示） --}}
    <div id="courseListContainer" class="course-list-container mb-3" style="display: none;">
        {{-- 工具栏：全选/取消 + 已选统计 --}}
        <div class="course-toolbar d-flex justify-content-between align-items-center mb-2">
            <div class="d-flex gap-2">
                <button type="button" id="selectAllBtn" class="btn btn-sm btn-outline-primary">
                    <i class="bi bi-check-all me-1"></i>全选
                </button>
                <button type="button" id="deselectAllBtn" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-x-circle me-1"></i>取消
                </button>
            </div>
            <div class="course-summary text-muted small">
                已选 <span id="selectedCount" class="fw-bold text-primary">0</span> 门课程，
                小计 <span id="coursesSubtotal" class="fw-bold text-danger">¥0.00</span>
            </div>
        </div>

        {{-- 课程网格 --}}
        <div id="courseList" class="course-grid">
            {{-- adapter.js 动态渲染课程卡片 --}}
        </div>
    </div>
</div>

{{-- 注入插件配置和脚本 --}}
<script>
window.__ADAPTER_THIRDPARTY_CONFIG__ = {
    platformId: '{{ $platformId }}',
    coursesRoute: '{{ $coursesRoute }}',
    unitPrice: {{ $unitPrice }}
};
</script>
<script src="{{ $adapterJsUrl }}"></script>
<script>
/**
 * 切换密码可见性（与老仓库一致，图标在 eye/eye-slash 之间切换）
 */
function togglePasswordVisibility() {
    const passwordInput = document.getElementById('studyPassword');
    const toggleIcon = document.getElementById('togglePasswordIcon');
    if (!passwordInput || !toggleIcon) return;

    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleIcon.classList.remove('bi-eye');
        toggleIcon.classList.add('bi-eye-slash');
    } else {
        passwordInput.type = 'password';
        toggleIcon.classList.remove('bi-eye-slash');
        toggleIcon.classList.add('bi-eye');
    }
}
</script>
