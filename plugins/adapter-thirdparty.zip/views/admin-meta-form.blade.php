{{--
    ThirdParty 插件：后台商品 Meta 配置片段
    由 Hook admin.product.meta_form 注入
--}}
<div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
    <h4 class="text-sm font-medium text-blue-800 mb-3">
        <svg class="inline w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
        </svg>
        课程对接配置
    </h4>
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">
            平台标识 (platform_id) <span class="text-red-500">*</span>
        </label>
        <input type="text" wire:model="form_meta.platform_id"
               placeholder="第三方刷课平台的标识 ID"
               class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none">
        <p class="text-xs text-gray-500 mt-1">此 ID 用于向第三方 API 查询该平台的课程列表</p>
    </div>
</div>
