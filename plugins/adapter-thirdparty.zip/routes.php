<?php

/**
 * ThirdParty 插件路由定义
 *
 * 所有路由集中注册，不使用闭包，统一指向 Controller 方法。
 * 由 ThirdPartyPlugin::register() 中 require 加载。
 */

use Illuminate\Support\Facades\Route;

// ==================== 后台路由 ====================

Route::prefix('admin')
    ->middleware('admin.auth')
    ->group(function () {
        Route::get('/plugin/adapter-thirdparty', [\ThirdParty\Controllers\SettingsController::class, 'index'])
            ->name('admin.plugin.adapter-thirdparty');

        Route::post('/plugin/adapter-thirdparty', [\ThirdParty\Controllers\SettingsController::class, 'save'])
            ->name('admin.plugin.adapter-thirdparty.save');

        // 刷课订单管理
        Route::get('/plugin/adapter-thirdparty/study-orders', [\ThirdParty\Controllers\StudyOrderController::class, 'index'])
            ->name('admin.plugin.adapter-thirdparty.study-orders');

        Route::post('/plugin/adapter-thirdparty/study-orders/update-status', [\ThirdParty\Controllers\StudyOrderController::class, 'updateStatus'])
            ->name('admin.plugin.adapter-thirdparty.study-orders.update-status');

        Route::post('/plugin/adapter-thirdparty/study-orders/sync-user', [\ThirdParty\Controllers\StudyOrderController::class, 'syncUser'])
            ->name('admin.plugin.adapter-thirdparty.study-orders.sync-user');

        Route::post('/plugin/adapter-thirdparty/study-orders/sync-all', [\ThirdParty\Controllers\StudyOrderController::class, 'syncAll'])
            ->name('admin.plugin.adapter-thirdparty.study-orders.sync-all');

    });

// ==================== 前端 AJAX 路由 ====================

// 前端 AJAX 路由（Laravel throttle 限流，每分钟 20 次）
Route::prefix('ajax/plugin/adapter-thirdparty')
    ->middleware('throttle:20,1')
    ->group(function () {
        // 查课
        Route::post('/courses', [\ThirdParty\Controllers\CourseController::class, 'getCourses'])
            ->name('ajax.plugin.adapter-thirdparty.courses');

        // 刷新进度
        Route::post('/refresh', [\ThirdParty\Controllers\CourseController::class, 'refresh'])
            ->name('ajax.plugin.adapter-thirdparty.refresh');

        // 补刷
        Route::post('/rebrush', [\ThirdParty\Controllers\CourseController::class, 'rebrush'])
            ->name('ajax.plugin.adapter-thirdparty.rebrush');
    });
