<?php

/**
 * ThirdParty 插件路由定义
 *
 * 所有路由集中注册，不使用闭包，统一指向 Controller 方法。
 * 由 ThirdPartyPlugin::register() 中 require 加载。
 */

use ThirdParty\Controllers\CourseController;
use ThirdParty\Controllers\SettingsController;
use ThirdParty\Controllers\StudyOrderController;
use Illuminate\Support\Facades\Route;

// ==================== 后台路由 ====================

admin_route_group(function () {
    Route::get('/plugin/adapter-thirdparty', [SettingsController::class, 'index'])
        ->name('admin.plugin.adapter-thirdparty');

    Route::post('/plugin/adapter-thirdparty', [SettingsController::class, 'save'])
        ->name('admin.plugin.adapter-thirdparty.save');

    // 刷课订单管理
    Route::get('/plugin/adapter-thirdparty/study-orders', [StudyOrderController::class, 'index'])
        ->name('admin.plugin.adapter-thirdparty.study-orders');

    Route::post('/plugin/adapter-thirdparty/study-orders/update-status', [StudyOrderController::class, 'updateStatus'])
        ->name('admin.plugin.adapter-thirdparty.study-orders.update-status');

    Route::post('/plugin/adapter-thirdparty/study-orders/sync-user', [StudyOrderController::class, 'syncUser'])
        ->name('admin.plugin.adapter-thirdparty.study-orders.sync-user');

    Route::post('/plugin/adapter-thirdparty/study-orders/sync-all', [StudyOrderController::class, 'syncAll'])
        ->name('admin.plugin.adapter-thirdparty.study-orders.sync-all');
});

// ==================== 前端 AJAX 路由 ====================

// 前端 AJAX 路由（Laravel throttle 限流，每分钟 20 次）
Route::prefix('ajax/plugin/adapter-thirdparty')
    ->middleware('throttle:20,1')
    ->group(function () {
        // 查课
        Route::post('/courses', [CourseController::class, 'getCourses'])
            ->name('ajax.plugin.adapter-thirdparty.courses');

        // 刷新进度
        Route::post('/refresh', [CourseController::class, 'refresh'])
            ->name('ajax.plugin.adapter-thirdparty.refresh');

        // 补刷
        Route::post('/rebrush', [CourseController::class, 'rebrush'])
            ->name('ajax.plugin.adapter-thirdparty.rebrush');
    });
