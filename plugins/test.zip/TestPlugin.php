<?php

use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Core\Admin\AdminMenu;

/**
 * 测试插件
 *
 * 用于验证插件系统是否正常工作。
 * 实现 PluginInterface 的所有 9 个方法。
 */
class TestPlugin implements PluginInterface
{
    public function id(): string
    {
        return 'test';
    }

    public function name(): string
    {
        return '测试插件';
    }

    public function version(): string
    {
        return '1.0.0';
    }

    public function type(): PluginType
    {
        return PluginType::Notification;
    }

    public function register(): void
    {
        // 注册一个测试菜单项，验证动态菜单系统
        AdminMenu::add([
            'group' => '测试',
            'items' => [
                ['label' => '测试页面', 'icon' => 'beaker', 'route' => 'admin.test', 'order' => 99],
            ],
        ]);
    }

    public function boot(): void
    {
        // 测试插件无需启动逻辑
    }

    public function uninstall(): void
    {
        // 清理注册的菜单
        AdminMenu::remove('admin.test');
    }

    public function config(): array
    {
        return [
            'test_key' => 'default_value',
        ];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }
}
