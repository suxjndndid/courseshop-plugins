body.frontend-body .frontend-brand,
body.frontend-body .frontend-nav-link,
body.frontend-body .frontend-footer-links a,
body.frontend-body .frontend-theme-switcher-trigger-copy strong,
body.frontend-body .frontend-theme-switcher-trigger-action,
body.frontend-body .frontend-theme-switcher-head strong,
body.frontend-body .frontend-theme-option strong,
body.frontend-body .brutal-hero-title,
body.frontend-body .brutal-section-title,
body.frontend-body .brutal-panel-title,
body.frontend-body .results-head h2,
body.frontend-body .brutal-query-title-bar h1,
body.frontend-body .brutal-product-name,
body.frontend-body .payment-wait-title,
body.frontend-body .payment-redirect-title {
    font-family: 'Courier Prime', 'IBM Plex Mono', 'Noto Sans Mono CJK SC', monospace;
    letter-spacing: 0.03em;
    text-transform: uppercase;
}

body.frontend-body .frontend-brand-mark,
body.frontend-body .frontend-footer-mark,
body.frontend-body .frontend-nav-toggle,
body.frontend-body .frontend-theme-switcher-trigger,
body.frontend-body .frontend-theme-switcher-trigger-action,
body.frontend-body .frontend-theme-switcher-panel,
body.frontend-body .frontend-theme-switcher-close,
body.frontend-body .frontend-theme-option,
body.frontend-body .custom-toast,
body.frontend-body .confirm-dialog,
body.frontend-body .confirm-btn,
body.frontend-body .brutal-home-hero,
body.frontend-body .brutal-hitokoto-box,
body.frontend-body .brutal-announcement-strip,
body.frontend-body .brutal-query-title-bar,
body.frontend-body .brutal-query-shell,
body.frontend-body .results-shell,
body.frontend-body .brutal-detail-ticker,
body.frontend-body .brutal-product-hero,
body.frontend-body .brutal-hero-media,
body.frontend-body .brutal-panel,
body.frontend-body .brutal-detail-block,
body.frontend-body .brutal-price-card,
body.frontend-body .brutal-status-card,
body.frontend-body .brutal-price-breakdown,
body.frontend-body .query-help,
body.frontend-body .order-card,
body.frontend-body .order-remarks,
body.frontend-body .payment-redirect-card,
body.frontend-body .payment-wait-card,
body.frontend-body .payment-wait-meta,
body.frontend-body .payment-wait-status,
body.frontend-body .brutal-product,
body.frontend-body .brutal-biz-result,
body.frontend-body .query-tab,
body.frontend-body .brutal-chip,
body.frontend-body .frontend-pagination .page-link,
body.frontend-body .brutal-input,
body.frontend-body .brutal-textarea,
body.frontend-body .query-input,
body.frontend-body #product-adapter-ui .form-control,
body.frontend-body .brutal-button,
body.frontend-body .brutal-ghost-button,
body.frontend-body .query-btn,
body.frontend-body .clear-btn,
body.frontend-body .brutal-submit-btn,
body.frontend-body .brutal-coupon-btn,
body.frontend-body .brutal-buy-btn,
body.frontend-body .payment-wait-button,
body.frontend-body #product-adapter-ui .btn,
body.frontend-body .order-actions .btn,
body.frontend-body .course-card-body,
body.frontend-body .course-card-check,
body.frontend-body #selfCourseResult {
    border-radius: 0 !important;
}

body.frontend-body .frontend-brand-mark,
body.frontend-body .frontend-footer-mark,
body.frontend-body .frontend-nav-toggle,
body.frontend-body .frontend-theme-switcher-trigger,
body.frontend-body .frontend-theme-switcher-panel,
body.frontend-body .frontend-theme-switcher-close,
body.frontend-body .frontend-theme-option,
body.frontend-body .custom-toast,
body.frontend-body .confirm-dialog,
body.frontend-body .confirm-btn,
body.frontend-body .brutal-home-hero,
body.frontend-body .brutal-hitokoto-box,
body.frontend-body .brutal-query-title-bar,
body.frontend-body .brutal-query-shell,
body.frontend-body .results-shell,
body.frontend-body .brutal-detail-ticker,
body.frontend-body .brutal-product-hero,
body.frontend-body .brutal-panel,
body.frontend-body .brutal-detail-block,
body.frontend-body .brutal-price-card,
body.frontend-body .brutal-status-card,
body.frontend-body .brutal-price-breakdown,
body.frontend-body .query-help,
body.frontend-body .order-card,
body.frontend-body .order-remarks,
body.frontend-body .payment-redirect-card,
body.frontend-body .payment-wait-card,
body.frontend-body .payment-wait-meta,
body.frontend-body .payment-wait-status,
body.frontend-body .brutal-product,
body.frontend-body .brutal-biz-result,
body.frontend-body .query-tab,
body.frontend-body .brutal-chip,
body.frontend-body .frontend-pagination .page-link,
body.frontend-body .brutal-input,
body.frontend-body .brutal-textarea,
body.frontend-body .query-input,
body.frontend-body #product-adapter-ui .form-control,
body.frontend-body .brutal-button,
body.frontend-body .brutal-ghost-button,
body.frontend-body .query-btn,
body.frontend-body .clear-btn,
body.frontend-body .brutal-submit-btn,
body.frontend-body .brutal-coupon-btn,
body.frontend-body .brutal-buy-btn,
body.frontend-body .payment-wait-button,
body.frontend-body #product-adapter-ui .btn,
body.frontend-body .order-actions .btn,
body.frontend-body .course-card-body,
body.frontend-body .course-card-check,
body.frontend-body #selfCourseResult {
    border-width: 2px !important;
    border-color: var(--theme-line) !important;
    box-shadow: var(--theme-shadow-sm) !important;
}

body.frontend-body .frontend-nav-shell,
body.frontend-body .frontend-footer-shell {
    border-color: var(--theme-line);
}

body.frontend-body .frontend-brand-mark,
body.frontend-body .frontend-footer-mark,
body.frontend-body .brutal-hitokoto-box,
body.frontend-body .brutal-product,
body.frontend-body .order-card,
body.frontend-body .payment-wait-card,
body.frontend-body .payment-redirect-card,
body.frontend-body .brutal-query-shell,
body.frontend-body .results-shell,
body.frontend-body .brutal-panel,
body.frontend-body .brutal-product-hero {
    background:
        linear-gradient(180deg, rgba(255, 255, 255, 0.42) 0, rgba(255, 255, 255, 0.42) 2px, transparent 2px),
        var(--theme-panel-gradient) !important;
}

body.frontend-body .frontend-theme-switcher-trigger,
body.frontend-body .frontend-theme-switcher-panel {
    background: linear-gradient(180deg, #fffbe8 0%, #ffe8a0 100%) !important;
}

body.frontend-body .frontend-theme-switcher-trigger-action,
body.frontend-body .query-tab.active,
body.frontend-body .query-tab:hover,
body.frontend-body .brutal-chip.is-active,
body.frontend-body .brutal-chip:hover,
body.frontend-body .frontend-pagination .page-item.active .page-link,
body.frontend-body .frontend-pagination .page-link:hover,
body.frontend-body .course-card.selected .course-card-check {
    background: var(--theme-accent-2) !important;
    color: #0d2847 !important;
    border-color: var(--theme-line) !important;
}

body.frontend-body .frontend-nav-link.active,
body.frontend-body .frontend-nav-link:hover,
body.frontend-body .frontend-footer-links a:hover,
body.frontend-body .frontend-theme-switcher-trigger-copy strong,
body.frontend-body .frontend-theme-switcher-trigger-action,
body.frontend-body .frontend-theme-switcher-head strong,
body.frontend-body .brutal-hitokoto-head,
body.frontend-body .brutal-announcement-btn,
body.frontend-body .brutal-announcement-title,
body.frontend-body .brutal-announcement-tag,
body.frontend-body .brutal-product-price,
body.frontend-body .price-value,
body.frontend-body .payment-wait-badge,
body.frontend-body .payment-wait-status,
body.frontend-body .query-help-item strong {
    color: var(--theme-accent) !important;
}

body.frontend-body .brutal-button,
body.frontend-body .query-btn,
body.frontend-body .brutal-submit-btn,
body.frontend-body .payment-wait-button,
body.frontend-body .brutal-buy-btn,
body.frontend-body #product-adapter-ui .btn-primary,
body.frontend-body .btn-refresh,
body.frontend-body .confirm-btn.confirm-btn-accept {
    border: 2px solid var(--theme-line) !important;
    background: linear-gradient(180deg, #ff91b6 0%, var(--theme-accent) 100%) !important;
    color: #fff !important;
}

body.frontend-body .brutal-ghost-button,
body.frontend-body .clear-btn,
body.frontend-body .brutal-coupon-btn,
body.frontend-body .btn-toggle-password,
body.frontend-body #product-adapter-ui .btn,
body.frontend-body .order-actions .btn {
    border: 2px solid var(--theme-line) !important;
    background: linear-gradient(180deg, #8eeeff 0%, var(--theme-accent-2) 100%) !important;
    color: #0d2847 !important;
}

body.frontend-body .brutal-announcement-strip {
    border-left-width: 4px;
    border-radius: 0;
    background:
        repeating-linear-gradient(
            -45deg,
            rgba(255, 79, 139, 0.08),
            rgba(255, 79, 139, 0.08) 10px,
            rgba(53, 214, 255, 0.08) 10px,
            rgba(53, 214, 255, 0.08) 20px
        ),
        var(--theme-accent-soft);
}

body.frontend-body .brutal-announcement-btn {
    width: 28px;
    height: 28px;
    display: inline-grid;
    place-items: center;
    border: 2px solid var(--theme-line);
    background: #fff7d1;
    box-shadow: var(--theme-shadow-sm);
}

body.frontend-body .brutal-announcement-dot {
    width: 8px;
    height: 8px;
    border: 2px solid var(--theme-line);
    background: #fff;
}

body.frontend-body .brutal-announcement-dot.is-active {
    background: var(--theme-accent);
}

body.frontend-body .brutal-product-image img {
    image-rendering: pixelated;
}

body.frontend-body .brutal-input,
body.frontend-body .brutal-textarea,
body.frontend-body .query-input,
body.frontend-body #product-adapter-ui .form-control {
    background: #fffdf2 !important;
    box-shadow: inset -3px -3px 0 rgba(53, 214, 255, 0.14) !important;
    font-family: 'Courier Prime', 'IBM Plex Mono', 'Noto Sans Mono CJK SC', monospace;
}

body.frontend-body .brutal-input:focus,
body.frontend-body .brutal-textarea:focus,
body.frontend-body .query-input:focus,
body.frontend-body #product-adapter-ui .form-control:focus {
    border-color: var(--theme-accent) !important;
    box-shadow: 0 0 0 3px rgba(255, 79, 139, 0.18) !important;
}

body.frontend-body .brutal-tag,
body.frontend-body .ticker-label,
body.frontend-body .ticker-note,
body.frontend-body .brutal-panel-kicker,
body.frontend-body .brutal-eyebrow,
body.frontend-body .count-badge,
body.frontend-body .remark-item,
body.frontend-body .badge-status {
    border: 2px solid var(--theme-line);
    border-radius: 0;
    box-shadow: var(--theme-shadow-sm);
    font-family: 'Courier Prime', 'IBM Plex Mono', 'Noto Sans Mono CJK SC', monospace;
    text-transform: uppercase;
}

body.frontend-body .payment-wait-countdown-number {
    border: 2px solid var(--theme-line);
    border-radius: 0;
    box-shadow: var(--theme-shadow);
    font-family: 'Courier Prime', 'IBM Plex Mono', 'Noto Sans Mono CJK SC', monospace;
}

@media (max-width: 991px) {
    body.frontend-body .brutal-home-hero,
    body.frontend-body .brutal-product-hero,
    body.frontend-body .brutal-query-shell,
    body.frontend-body .brutal-work-grid {
        grid-template-columns: 1fr;
    }

    body.frontend-body .brutal-work-grid {
        grid-template-areas:
            'buy'
            'biz';
    }

    body.frontend-body #brutal-buy-panel {
        position: static;
    }
}

@media (max-width: 720px) {
    body.frontend-body .frontend-theme-switcher-trigger,
    body.frontend-body .frontend-nav-shell {
        align-items: flex-start;
        flex-direction: column;
    }

    body.frontend-body .brutal-detail-ticker,
    body.frontend-body .brutal-price-strip,
    body.frontend-body .query-form,
    body.frontend-body .brutal-coupon-row,
    body.frontend-body .order-actions {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 575px) {
    body.frontend-body .brutal-home-hero {
        margin-top: 28px;
    }

    body.frontend-body .brutal-products-grid {
        grid-template-columns: 1fr;
    }

    body.frontend-body .frontend-footer-shell,
    body.frontend-body .frontend-footer-brand,
    body.frontend-body .frontend-footer-links {
        width: 100%;
    }
}
