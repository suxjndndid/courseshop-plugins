:root {
    --theme-paper: #fff4d8;
    --theme-ink: #24173d;
    --theme-muted: #6d6188;
    --theme-line: #2d2147;
    --theme-accent: #ff4f8b;
    --theme-accent-2: #35d6ff;
    --theme-success: #18b779;
    --theme-info: #35d6ff;
    --theme-warning: #ffbe0b;
    --theme-danger: #ff5b6e;
    --theme-accent-soft: #fff0b6;
    --theme-success-soft: #d9ffe7;
    --theme-image-bg: #ffe99a;
    --theme-panel-alt: #fff9eb;
    --theme-shadow: 6px 6px 0 rgba(45, 33, 71, 0.24);
    --theme-shadow-sm: 4px 4px 0 rgba(45, 33, 71, 0.18);
    --theme-panel-gradient: linear-gradient(180deg, #fff8df 0%, #ffe9a9 100%);
    --theme-body-background:
        linear-gradient(rgba(53, 214, 255, 0.08) 1px, transparent 1px),
        linear-gradient(90deg, rgba(53, 214, 255, 0.08) 1px, transparent 1px),
        linear-gradient(180deg, #ffd35c 0%, #fff1bf 100%);
}

body.frontend-body {
    color: var(--theme-ink);
    background: var(--theme-body-background);
    background-size: 16px 16px, 16px 16px, auto;
    font-family: 'Courier Prime', 'IBM Plex Mono', 'Noto Sans Mono CJK SC', monospace;
}

body.frontend-body .frontend-nav {
    padding: 0;
}

body.frontend-body .frontend-nav-shell {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    padding: 18px 0;
    border-bottom: 1px solid var(--theme-line);
    flex-wrap: wrap;
}

body.frontend-body .frontend-brand {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    color: var(--theme-accent) !important;
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: 16px;
    font-weight: 700;
    letter-spacing: 0.04em;
}

body.frontend-body .frontend-brand-mark,
body.frontend-body .frontend-footer-mark {
    width: 34px;
    height: 34px;
    display: inline-grid;
    place-items: center;
    border: 1px solid rgba(44, 90, 160, 0.18);
    border-radius: 8px;
    background: var(--theme-accent-soft);
    box-shadow: none;
}

body.frontend-body .frontend-nav-toggle {
    border: 1px solid var(--theme-line);
    border-radius: 8px;
    padding: 7px 10px;
    box-shadow: none;
}

body.frontend-body .frontend-nav-toggle:focus {
    box-shadow: 0 0 0 3px rgba(44, 90, 160, 0.14);
}

body.frontend-body .frontend-nav-collapse {
    align-items: center;
    gap: 14px;
    flex-grow: 0;
}

body.frontend-body .frontend-nav-links {
    display: flex;
    align-items: center;
    gap: 24px;
    flex-wrap: wrap;
    margin-bottom: 0;
}

body.frontend-body .frontend-nav-links .nav-item {
    list-style: none;
}

body.frontend-body .frontend-nav-link {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 0 !important;
    border: 0;
    background: transparent;
    color: var(--theme-muted) !important;
    box-shadow: none;
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: 13px;
    font-weight: 500;
    text-transform: none;
}

body.frontend-body .frontend-nav-link.active,
body.frontend-body .frontend-nav-link:hover {
    background: transparent;
    color: var(--theme-accent) !important;
    font-weight: 600;
}

body.frontend-body .frontend-nav-actions {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

body.frontend-body .frontend-footer {
    padding: 0 0 28px;
    margin-top: 24px;
}

body.frontend-body .frontend-footer-shell {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    padding: 20px 0 0;
    border-top: 1px solid var(--theme-line);
    flex-wrap: wrap;
}

body.frontend-body .frontend-footer-brand {
    display: inline-flex;
    align-items: center;
    gap: 12px;
}

body.frontend-body .frontend-footer-copy {
    display: grid;
    gap: 2px;
}

body.frontend-body .frontend-footer-copy strong {
    color: var(--theme-ink);
    font-size: 13px;
}

body.frontend-body .frontend-footer-copy p,
body.frontend-body .frontend-footer-note {
    margin: 0;
    color: #94a3b8;
    font-size: 11px;
}

body.frontend-body .frontend-footer-links {
    display: flex;
    align-items: center;
    gap: 14px;
    flex-wrap: wrap;
}

body.frontend-body .frontend-footer-links a {
    border: 0;
    background: transparent;
    padding: 0;
    box-shadow: none;
    color: var(--theme-muted);
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: 12px;
    font-weight: 500;
    text-transform: none;
}

body.frontend-body .frontend-footer-links a:hover {
    color: var(--theme-accent);
}

body.frontend-body .custom-toast {
    background: var(--theme-paper);
    color: var(--theme-ink);
    border: 1px solid var(--theme-line);
    border-radius: 10px;
    box-shadow: var(--theme-shadow-sm);
}

body.frontend-body .custom-toast.toast-success { border-left: 4px solid var(--theme-success); }
body.frontend-body .custom-toast.toast-error { border-left: 4px solid var(--theme-danger); }
body.frontend-body .custom-toast.toast-warning { border-left: 4px solid var(--theme-warning); }
body.frontend-body .custom-toast.toast-info { border-left: 4px solid var(--theme-info); }

body.frontend-body .custom-toast .toast-title {
    color: var(--theme-ink);
}

body.frontend-body .custom-toast .toast-message,
body.frontend-body .custom-toast .toast-close,
body.frontend-body .confirm-dialog-body .confirm-description {
    color: var(--theme-muted);
}

body.frontend-body .confirm-dialog {
    border: 1px solid var(--theme-line);
    border-radius: 12px;
    background: var(--theme-paper);
    color: var(--theme-ink);
    box-shadow: var(--theme-shadow);
}

body.frontend-body .confirm-dialog-header {
    border-bottom: 1px solid var(--theme-line);
}

body.frontend-body .confirm-dialog-footer {
    border-top: 1px solid var(--theme-line);
}

body.frontend-body .confirm-btn {
    border: 1px solid var(--theme-line);
    border-radius: 8px;
    background: var(--theme-paper);
    color: var(--theme-ink);
}

body.frontend-body .confirm-btn.confirm-btn-accept {
    background: linear-gradient(135deg, #2c5aa0, #3569b5);
    color: #fff;
    border-color: transparent;
}

body.frontend-body .confirm-btn:hover {
    box-shadow: var(--theme-shadow-sm);
}

body.frontend-body .frontend-theme-switcher {
    position: relative;
}

body.frontend-body .frontend-theme-switcher-trigger {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 14px 16px;
    border: 1px solid var(--theme-line);
    border-radius: 10px;
    background: #fff;
    box-shadow: var(--theme-shadow-sm);
    cursor: pointer;
}

body.frontend-body .frontend-theme-switcher-trigger-copy {
    display: grid;
    gap: 2px;
    text-align: left;
}

body.frontend-body .frontend-theme-switcher-trigger-copy strong,
body.frontend-body .frontend-theme-switcher-trigger-action {
    color: var(--theme-accent);
    font-size: 13px;
    font-weight: 600;
}

body.frontend-body .frontend-theme-switcher-trigger-copy span {
    color: #94a3b8;
    font-size: 11px;
}

body.frontend-body .frontend-theme-switcher-trigger-action {
    padding: 5px 10px;
    border: 1px solid rgba(44, 90, 160, 0.22);
    border-radius: 999px;
    background: var(--theme-accent-soft);
}

body.frontend-body .frontend-theme-switcher-panel {
    position: absolute;
    top: calc(100% + 10px);
    left: 0;
    right: 0;
    z-index: 30;
    display: grid;
    gap: 10px;
    padding: 14px;
    border: 1px solid var(--theme-line);
    border-radius: 12px;
    background: #fff;
    box-shadow: var(--theme-shadow);
}

body.frontend-body .frontend-theme-switcher-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
}

body.frontend-body .frontend-theme-switcher-head strong {
    color: var(--theme-accent);
    font-size: 13px;
    font-weight: 600;
}

body.frontend-body .frontend-theme-switcher-note {
    color: #94a3b8;
    font-size: 11px;
    margin: 0;
}

body.frontend-body .frontend-theme-switcher-close {
    width: 32px;
    height: 32px;
    border: 1px solid var(--theme-line);
    border-radius: 8px;
    background: #fff;
    color: var(--theme-muted);
    font-size: 18px;
    line-height: 1;
    cursor: pointer;
}

body.frontend-body .frontend-theme-switcher-options {
    display: grid;
    gap: 8px;
}

body.frontend-body .frontend-theme-option-form {
    margin: 0;
}

body.frontend-body .frontend-theme-option {
    display: block;
    width: 100%;
    text-align: left;
    border: 1px solid var(--theme-line);
    border-radius: 8px;
    background: var(--theme-paper);
    padding: 10px 12px;
    cursor: pointer;
}

body.frontend-body .frontend-theme-option.is-active,
body.frontend-body .frontend-theme-option:hover {
    border-color: rgba(44, 90, 160, 0.38);
    background: var(--theme-accent-soft);
}

body.frontend-body .frontend-theme-option strong {
    display: block;
    color: var(--theme-ink);
    font-size: 12px;
    font-weight: 600;
}

body.frontend-body .frontend-theme-option span {
    display: block;
    margin-top: 2px;
    color: var(--theme-muted);
    font-size: 11px;
    line-height: 1.5;
}

@media (max-width: 768px) {
    body.frontend-body .frontend-theme-switcher-trigger {
        align-items: flex-start;
        flex-direction: column;
    }
}

body.frontend-body .brutal-home-hero {
    display: grid;
    grid-template-columns: 1.4fr 1fr;
    gap: 36px;
    margin: 40px 0 32px;
}

body.frontend-body .brutal-hero-main,
body.frontend-body .brutal-home-content,
body.frontend-body .brutal-query-main {
    display: grid;
    gap: 14px;
}

body.frontend-body .brutal-hero-main {
    background: transparent;
}

body.frontend-body .brutal-hero-title {
    margin: 0;
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: clamp(26px, 4vw, 36px);
    line-height: 1.25;
    font-weight: 700;
    color: var(--theme-ink);
    text-transform: none;
}

body.frontend-body .brutal-hitokoto-box {
    border: 1px solid var(--theme-line);
    border-radius: 8px;
    background: #fff;
    padding: 12px 14px;
    box-shadow: var(--theme-shadow-sm);
}

body.frontend-body .brutal-hitokoto-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 6px;
    color: var(--theme-accent);
    font-size: 12px;
    font-weight: 600;
}

body.frontend-body .hitokoto-copy {
    margin: 0;
    color: var(--theme-ink);
    font-size: 12px;
    line-height: 1.6;
}

body.frontend-body .hitokoto-icon,
body.frontend-body .hitokoto-from {
    color: #94a3b8;
}

body.frontend-body .brutal-hero-side {
    display: grid;
    gap: 12px;
    align-content: start;
}

body.frontend-body .brutal-hero-btn,
body.frontend-body .brutal-button,
body.frontend-body .query-btn,
body.frontend-body .brutal-submit-btn,
body.frontend-body .payment-wait-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 44px;
    border: none;
    border-radius: 8px;
    background: linear-gradient(135deg, #2c5aa0, #3569b5);
    color: #fff;
    padding: 10px 14px;
    box-shadow: none;
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: 13px;
    font-weight: 600;
    text-transform: none;
    cursor: pointer;
}

body.frontend-body .brutal-ghost-button,
body.frontend-body .clear-btn,
body.frontend-body .brutal-coupon-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 42px;
    border: 1px solid var(--theme-line);
    border-radius: 8px;
    background: #fff;
    color: var(--theme-accent);
    padding: 10px 14px;
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: 13px;
    font-weight: 600;
    text-transform: none;
    cursor: pointer;
}

body.frontend-body .brutal-hero-btn:hover,
body.frontend-body .brutal-button:hover,
body.frontend-body .query-btn:hover,
body.frontend-body .brutal-submit-btn:hover,
body.frontend-body .payment-wait-button:hover,
body.frontend-body .brutal-ghost-button:hover,
body.frontend-body .clear-btn:hover,
body.frontend-body .brutal-coupon-btn:hover {
    opacity: 0.92;
}

body.frontend-body .brutal-announcement-strip {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 24px;
    padding: 12px 14px;
    border-left: 3px solid var(--theme-accent);
    background: var(--theme-accent-soft);
    border-radius: 6px;
}

body.frontend-body .brutal-announcement-btn {
    border: none;
    background: transparent;
    color: var(--theme-accent);
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
}

body.frontend-body .brutal-announcement-content {
    flex: 1;
}

body.frontend-body .brutal-announcement-item {
    display: none;
}

body.frontend-body .brutal-announcement-item.is-active {
    display: block;
}

body.frontend-body .brutal-announcement-title {
    margin: 0 0 2px;
    color: var(--theme-accent);
    font-size: 12px;
    font-weight: 600;
}

body.frontend-body .brutal-announcement-text {
    margin: 0;
    color: var(--theme-muted);
    font-size: 11px;
    line-height: 1.4;
}

body.frontend-body .brutal-announcement-tag {
    display: inline-flex;
    align-items: center;
    margin-right: 6px;
    padding: 1px 6px;
    border-radius: 999px;
    background: rgba(44, 90, 160, 0.12);
    color: var(--theme-accent);
    font-size: 10px;
    font-weight: 600;
}

body.frontend-body .brutal-announcement-dots {
    display: flex;
    gap: 5px;
    margin-top: 6px;
}

body.frontend-body .brutal-announcement-dot {
    width: 5px;
    height: 5px;
    border: 0;
    border-radius: 999px;
    background: #d1d5db;
    cursor: pointer;
}

body.frontend-body .brutal-announcement-dot.is-active {
    background: var(--theme-accent);
}

body.frontend-body .brutal-announcement-empty,
body.frontend-body .brutal-disclaimer {
    padding: 10px 12px;
    border-radius: 6px;
    font-size: 11px;
}

body.frontend-body .brutal-announcement-empty {
    background: var(--theme-accent-soft);
    color: var(--theme-accent);
}

body.frontend-body .brutal-disclaimer {
    background: #fef3c7;
    border-left: 3px solid var(--theme-warning);
}

body.frontend-body .brutal-disclaimer a {
    color: var(--theme-accent);
    font-weight: 600;
}

body.frontend-body .brutal-section-title {
    margin: 28px 0 16px;
    color: var(--theme-ink);
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: 14px;
    font-weight: 700;
    text-transform: none;
}

body.frontend-body .brutal-filter-row {
    display: flex;
    gap: 10px;
    margin-bottom: 16px;
    flex-wrap: wrap;
}

body.frontend-body .brutal-chip {
    border: 1px solid #d1d5db;
    border-radius: 6px;
    background: #fff;
    color: var(--theme-muted);
    padding: 6px 10px;
    box-shadow: none;
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: 12px;
    font-weight: 500;
    text-transform: none;
}

body.frontend-body .brutal-chip.is-active,
body.frontend-body .brutal-chip:hover {
    border-color: var(--theme-accent);
    background: var(--theme-accent);
    color: #fff;
}

body.frontend-body .brutal-search-hint {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    width: fit-content;
    border: 1px solid var(--theme-line);
    border-radius: 6px;
    background: #fff;
    padding: 8px 10px;
    font-size: 12px;
    font-weight: 500;
    box-shadow: none;
}
