<style>
@include('theme-pixel::styles.fragments.shell')
@include('theme-pixel::styles.fragments.catalog')
@include('theme-pixel::styles.fragments.detail')
@include('theme-pixel::styles.fragments.query')
@include('theme-pixel::styles.fragments.overrides')
</style>
