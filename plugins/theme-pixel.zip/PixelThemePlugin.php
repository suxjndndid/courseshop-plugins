<?php

use App\Core\Contracts\FrontendThemeInterface;
use App\Core\Hook\Hook;
use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Services\FrontendThemeService;

class PixelThemePlugin implements PluginInterface, FrontendThemeInterface
{
    public function id(): string
    {
        return 'theme-pixel';
    }

    public function name(): string
    {
        return '像素街机主题';
    }

    public function version(): string
    {
        return '1.0.0';
    }

    public function type(): PluginType
    {
        return PluginType::Theme;
    }

    public function register(): void
    {
        app('view')->addNamespace('theme-pixel', dirname(__FILE__) . '/views');
    }

    public function boot(): void
    {
        Hook::addFilter('frontend.head', function (string $html): string {
            if (!app(FrontendThemeService::class)->isActiveTheme($this->id())) {
                return $html;
            }

            return $html . "\n" . view('theme-pixel::styles.shared')->render() . "\n";
        }, 10);
    }

    public function uninstall(): void
    {
    }

    public function config(): array
    {
        return [];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }

    public function frontendThemeLabel(): string
    {
        return '像素街机';
    }

    public function frontendThemeDescription(): string
    {
        return '像掌机游戏界面一样明快俏皮，按钮和卡片都有很强的像素感。';
    }

    public function frontendThemeOrder(): int
    {
        return 45;
    }
}
