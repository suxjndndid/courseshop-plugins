body.frontend-body .brutal-query-shell {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 300px;
    gap: 14px;
    align-items: start;
    margin-bottom: 18px;
    padding: 16px;
}

body.frontend-body .query-tabs {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

body.frontend-body .query-tab {
    border: 1px solid #d1d5db;
    border-radius: 6px;
    background: #fff;
    color: var(--theme-muted);
    padding: 7px 11px;
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: 12px;
    font-weight: 500;
    text-transform: none;
    cursor: pointer;
}

body.frontend-body .query-tab.active,
body.frontend-body .query-tab:hover {
    border-color: var(--theme-accent);
    color: var(--theme-accent);
}

body.frontend-body .query-form {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 170px;
    gap: 10px;
}

body.frontend-body .query-help {
    display: grid;
    gap: 10px;
    padding: 12px;
    border: 1px solid var(--theme-line);
    border-radius: 10px;
    background: var(--theme-panel-alt);
}

body.frontend-body .query-help h3 {
    margin: 0;
    color: var(--theme-ink);
    font-size: 13px;
    font-weight: 600;
}

body.frontend-body .query-help-item {
    display: flex;
    gap: 8px;
    color: var(--theme-muted);
    font-size: 12px;
    font-weight: 500;
}

body.frontend-body .query-help-item strong {
    color: var(--theme-accent);
    white-space: nowrap;
}

body.frontend-body .results-shell {
    padding: 16px;
}

body.frontend-body .results-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 12px;
}

body.frontend-body .count-badge {
    min-width: 28px;
    height: 28px;
}

body.frontend-body .order-list {
    display: grid;
    gap: 12px;
}

body.frontend-body .order-card {
    overflow: hidden;
    border: 1px solid var(--theme-line);
    border-radius: 10px;
    background: #fff;
    box-shadow: var(--theme-shadow-sm);
}

body.frontend-body .order-card.loading {
    opacity: 0.65;
    pointer-events: none;
}

body.frontend-body .order-header {
    padding: 10px 12px;
    border-bottom: 1px solid var(--theme-line);
    background: var(--theme-panel-alt);
}

body.frontend-body .order-header code {
    border: 1px solid var(--theme-line);
    border-radius: 6px;
    background: #fff;
    padding: 3px 8px;
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: 12px;
    font-weight: 600;
}

body.frontend-body .badge-status {
    border: 1px solid transparent;
    border-radius: 999px;
    padding: 4px 10px;
    font-size: 12px;
    font-weight: 600;
}

body.frontend-body .badge-status.status-completed { background: #dcfce7; color: #166534; }
body.frontend-body .badge-status.status-processing { background: #dbeafe; color: #1d4ed8; }
body.frontend-body .badge-status.status-pending { background: #fef3c7; color: #92400e; }
body.frontend-body .badge-status.status-failed { background: #fee2e2; color: #b91c1c; }

body.frontend-body .order-body {
    display: grid;
    gap: 10px;
    padding: 12px;
}

body.frontend-body .info-row {
    display: grid;
    gap: 2px;
}

body.frontend-body .info-label {
    color: var(--theme-muted);
    font-size: 12px;
    font-weight: 500;
}

body.frontend-body .info-value {
    color: var(--theme-ink);
    font-size: 13px;
    font-weight: 600;
}

body.frontend-body .progress-row {
    display: grid;
    gap: 8px;
}

body.frontend-body .progress-label {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
}

body.frontend-body .progress-bar-wrapper {
    height: 10px;
    border-radius: 999px;
    background: #e5e7eb;
    overflow: hidden;
}

body.frontend-body .progress-bar-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--theme-accent), #5b8bd9);
}

body.frontend-body .order-remarks {
    display: grid;
    gap: 8px;
    padding: 10px;
    border: 1px solid var(--theme-line);
    border-radius: 8px;
    background: var(--theme-panel-alt);
}

body.frontend-body .remarks-title {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    color: var(--theme-ink);
    font-size: 12px;
    font-weight: 600;
}

body.frontend-body .remarks-parsed {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

body.frontend-body .remark-item {
    display: inline-flex;
    align-items: center;
    padding: 4px 8px;
    border-radius: 999px;
    background: #eef2ff;
    color: #4338ca;
    font-size: 12px;
    font-weight: 500;
}

body.frontend-body .remark-item.highlight {
    background: #dbeafe;
    color: #1d4ed8;
}

body.frontend-body .order-actions {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 10px;
    padding: 0 12px 12px;
}

body.frontend-body .action-half {
    display: grid;
}

body.frontend-body .order-actions .btn {
    width: 100%;
    min-height: 40px;
}

body.frontend-body .payment-redirect-overlay {
    position: fixed;
    inset: 0;
    z-index: 3000;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 24px;
    background: rgba(15, 23, 42, 0.45);
}

body.frontend-body .payment-redirect-overlay.show {
    display: flex;
}

body.frontend-body .payment-redirect-card {
    width: min(420px, 100%);
    padding: 18px 16px;
    border: 1px solid var(--theme-line);
    border-radius: 12px;
    background: #fff;
    color: var(--theme-ink);
    box-shadow: var(--theme-shadow);
    text-align: center;
}

body.frontend-body .payment-redirect-title {
    margin-top: 12px;
    font-size: 18px;
    font-weight: 700;
}

body.frontend-body .payment-redirect-message {
    margin-top: 8px;
    color: var(--theme-muted);
    font-size: 13px;
    font-weight: 500;
}

body.frontend-body .payment-wait-page {
    min-height: 72vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px 0;
}

body.frontend-body .payment-wait-card {
    width: min(460px, 100%);
    display: grid;
    gap: 16px;
    padding: 24px 22px;
    border: 1px solid var(--theme-line);
    border-radius: 12px;
    background: #fff;
    box-shadow: var(--theme-shadow);
}

body.frontend-body .payment-wait-badge {
    width: fit-content;
    padding: 4px 8px;
    border-radius: 999px;
    background: var(--theme-accent-soft);
    color: var(--theme-accent);
    font-size: 11px;
    font-weight: 600;
}

body.frontend-body .payment-wait-title {
    margin: 0;
    color: var(--theme-ink);
    font-size: clamp(24px, 4vw, 32px);
    line-height: 1.15;
    font-weight: 700;
}

body.frontend-body .payment-wait-subtitle {
    margin: 0;
    color: var(--theme-muted);
    font-size: 13px;
    font-weight: 500;
    line-height: 1.6;
}

body.frontend-body .payment-wait-meta {
    display: grid;
    gap: 10px;
    padding: 14px;
    border: 1px solid var(--theme-line);
    border-radius: 10px;
    background: var(--theme-panel-alt);
}

body.frontend-body .payment-wait-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    font-size: 13px;
    font-weight: 500;
}

body.frontend-body .payment-wait-row span {
    color: var(--theme-muted);
}

body.frontend-body .payment-wait-row strong {
    text-align: right;
    word-break: break-all;
}

body.frontend-body .payment-wait-countdown {
    display: grid;
    justify-items: center;
    gap: 10px;
}

body.frontend-body .payment-wait-countdown-label,
body.frontend-body .payment-wait-countdown-unit {
    margin: 0;
    color: #94a3b8;
    font-size: 12px;
    font-weight: 500;
}

body.frontend-body .payment-wait-countdown-number {
    width: 72px;
    height: 72px;
    display: inline-grid;
    place-items: center;
    border-radius: 999px;
    background: linear-gradient(135deg, #2c5aa0, #3569b5);
    color: #fff;
    font-size: 30px;
    font-weight: 700;
}

body.frontend-body .payment-wait-status {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    min-height: 46px;
    padding: 10px 12px;
    border: 1px solid var(--theme-line);
    border-radius: 10px;
    background: var(--theme-panel-alt);
    color: var(--theme-accent);
    font-size: 13px;
    font-weight: 600;
}

body.frontend-body #paymentFormContainer {
    display: none;
}

@media (max-width: 991px) {
    body.frontend-body .frontend-nav-collapse {
        flex-basis: 100%;
    }

    body.frontend-body .frontend-nav-links,
    body.frontend-body .frontend-nav-actions {
        padding-top: 12px;
    }

    body.frontend-body .brutal-home-hero,
    body.frontend-body .brutal-product-hero,
    body.frontend-body .brutal-query-shell,
    body.frontend-body .brutal-work-grid {
        grid-template-columns: 1fr;
    }

    body.frontend-body .brutal-work-grid {
        grid-template-areas:
            'buy'
            'biz';
    }

    body.frontend-body #brutal-buy-panel {
        position: static;
    }
}

@media (max-width: 720px) {
    body.frontend-body .brutal-detail-ticker,
    body.frontend-body .brutal-price-strip,
    body.frontend-body .query-form,
    body.frontend-body .brutal-coupon-row {
        grid-template-columns: 1fr;
    }

    body.frontend-body .order-actions {
        grid-template-columns: 1fr;
    }
}
