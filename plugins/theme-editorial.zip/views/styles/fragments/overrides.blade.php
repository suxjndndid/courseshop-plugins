@media (max-width: 575px) {
    body.frontend-body .brutal-home-hero {
        margin-top: 28px;
    }

    body.frontend-body .brutal-products-grid {
        grid-template-columns: 1fr;
    }

    body.frontend-body .frontend-footer-shell,
    body.frontend-body .frontend-footer-brand,
    body.frontend-body .frontend-footer-links {
        width: 100%;
    }
}

body.frontend-body {
    background:
        linear-gradient(180deg, rgba(250, 249, 246, 0.96), rgba(250, 249, 246, 0.96)),
        repeating-linear-gradient(0deg, transparent 0 35px, rgba(0, 0, 0, 0.018) 35px 36px);
    color: #2c2c2c;
    font-family: 'Noto Serif SC', 'Source Han Serif SC', 'Songti SC', 'STSong', serif;
}

body.frontend-body .frontend-brand,
body.frontend-body .frontend-nav-link,
body.frontend-body .frontend-footer-note,
body.frontend-body .brutal-panel-title,
body.frontend-body .results-head h2,
body.frontend-body .brutal-section-title,
body.frontend-body .frontend-theme-switcher-trigger-copy strong,
body.frontend-body .frontend-theme-switcher-trigger-action {
    font-family: 'Noto Serif SC', 'Source Han Serif SC', 'Songti SC', serif;
}

body.frontend-body .frontend-nav-shell {
    padding: 24px 0 16px;
    border-bottom: 3px solid #000;
}

body.frontend-body .frontend-brand {
    color: #000 !important;
    font-size: 22px;
    letter-spacing: 0.22em;
    text-transform: uppercase;
}

body.frontend-body .frontend-brand-mark,
body.frontend-body .frontend-footer-mark {
    width: 40px;
    height: 40px;
    border: 2px solid #000;
    border-radius: 0;
    background: #fff;
}

body.frontend-body .frontend-nav-link {
    color: #5f5a52 !important;
    font-size: 13px;
    letter-spacing: 0.08em;
}

body.frontend-body .frontend-nav-link.active,
body.frontend-body .frontend-nav-link:hover {
    color: #000 !important;
    text-decoration: underline;
    text-underline-offset: 5px;
}

body.frontend-body .frontend-theme-switcher-trigger,
body.frontend-body .frontend-theme-switcher-panel,
body.frontend-body .custom-toast,
body.frontend-body .confirm-dialog,
body.frontend-body .brutal-home-hero,
body.frontend-body .brutal-home-content,
body.frontend-body .brutal-product-hero,
body.frontend-body .brutal-query-shell,
body.frontend-body .results-shell,
body.frontend-body .brutal-query-title-bar,
body.frontend-body .brutal-panel,
body.frontend-body .brutal-detail-block {
    border-color: #1d1d1d !important;
    border-width: 1px !important;
    border-radius: 0 !important;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05) !important;
}

body.frontend-body .frontend-theme-switcher-trigger {
    background: #fffdf8;
}

body.frontend-body .frontend-theme-switcher-trigger-action,
body.frontend-body .frontend-theme-switcher-close,
body.frontend-body .frontend-theme-option,
body.frontend-body .query-tab,
body.frontend-body .clear-btn,
body.frontend-body .brutal-coupon-btn,
body.frontend-body .brutal-ghost-button {
    border-radius: 0 !important;
    border-width: 1px !important;
    box-shadow: none !important;
}

body.frontend-body .frontend-theme-switcher-trigger-copy span,
body.frontend-body .frontend-theme-switcher-note,
body.frontend-body .hitokoto-from,
body.frontend-body .brutal-search-hint,
body.frontend-body .brutal-biz-hint,
body.frontend-body .price-label,
body.frontend-body .brutal-helper-list,
body.frontend-body .query-input::placeholder {
    color: #6b6258 !important;
}

body.frontend-body .brutal-home-hero {
    grid-template-columns: 1.55fr 0.95fr;
    gap: 32px;
    margin: 38px 0 28px;
    padding: 28px;
    background: transparent;
}

body.frontend-body .brutal-hero-main {
    border: 0;
    background: transparent;
    padding: 0;
}

body.frontend-body .brutal-hero-title {
    font-size: clamp(34px, 5vw, 52px);
    line-height: 1.05;
    letter-spacing: 0.08em;
    text-transform: uppercase;
}

body.frontend-body .brutal-hitokoto-box,
body.frontend-body .brutal-disclaimer {
    background: #fffdfa;
    border-left: 4px solid #000;
    border-right: 0;
}

body.frontend-body .brutal-announcement-strip {
    background: #fff;
    border-top: 3px solid #000;
    border-bottom: 3px solid #000;
    border-left: 0;
    border-right: 0;
    box-shadow: none !important;
}

body.frontend-body .brutal-announcement-btn {
    width: 34px;
    height: 34px;
    border: 2px solid #000;
    background: #fff;
}

body.frontend-body .brutal-announcement-btn:hover,
body.frontend-body .brutal-button:hover,
body.frontend-body .query-btn:hover,
body.frontend-body .brutal-submit-btn:hover,
body.frontend-body .brutal-buy-btn:hover,
body.frontend-body .brutal-hero-btn:hover {
    background: #000;
    color: #fff;
    transform: none;
}

body.frontend-body .brutal-home-content {
    padding: 22px;
    background: rgba(255, 255, 255, 0.78);
}

body.frontend-body .brutal-section-title {
    font-size: 17px;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    border-bottom: 2px solid #000;
    padding-bottom: 8px;
}

body.frontend-body .brutal-products-grid {
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 14px;
}

body.frontend-body .brutal-product {
    padding: 12px;
    background: #fff;
    border: 1px solid #d7d1c8;
    box-shadow: none !important;
}

body.frontend-body .brutal-product:hover {
    border-color: #000;
    box-shadow: 0 8px 18px rgba(0, 0, 0, 0.08) !important;
    transform: translateY(-2px);
}

body.frontend-body .brutal-product-image {
    background: #f4efe6;
}

body.frontend-body .brutal-product-price,
body.frontend-body .price-value {
    color: #b40000;
}

body.frontend-body .brutal-buy-btn,
body.frontend-body .brutal-button,
body.frontend-body .query-btn,
body.frontend-body .brutal-submit-btn,
body.frontend-body .brutal-hero-btn {
    border: 1px solid #000;
    background: #fff;
    color: #000;
    box-shadow: none;
}

body.frontend-body .brutal-detail-ticker {
    background: #fff;
    border-top: 3px solid #000;
    border-bottom: 3px solid #000;
    border-left: 0;
    border-right: 0;
    box-shadow: none !important;
}

body.frontend-body .brutal-breadcrumb {
    color: #6b6258;
    letter-spacing: 0.06em;
}

body.frontend-body .brutal-product-hero {
    gap: 28px;
    padding: 22px;
    background: rgba(255, 255, 255, 0.82);
}

body.frontend-body .brutal-tag,
body.frontend-body .brutal-status-card,
body.frontend-body .brutal-price-card {
    border-width: 1px !important;
    border-radius: 0 !important;
    box-shadow: none !important;
}

body.frontend-body .brutal-work-grid {
    gap: 20px;
}

body.frontend-body .brutal-panel-head {
    border-bottom: 1px solid #000;
    padding-bottom: 10px;
}

body.frontend-body .brutal-panel-kicker,
body.frontend-body .ticker-label,
body.frontend-body .ticker-note {
    letter-spacing: 0.18em;
}

body.frontend-body .results-head,
body.frontend-body .order-header {
    border-bottom: 1px solid #000;
}

body.frontend-body .order-card {
    border: 1px solid #d4cec6;
    background: #fff;
    box-shadow: none;
}

body.frontend-body .order-card:hover {
    border-color: #000;
}

body.frontend-body .badge-status.status-success,
body.frontend-body .badge-status.status-completed {
    background: #f4efe6;
    color: #000;
}

body.frontend-body .badge-status.status-processing,
body.frontend-body .badge-status.status-pending {
    background: #fff3d7;
    color: #6e4f00;
}

@media (max-width: 991px) {
    body.frontend-body .brutal-home-hero,
    body.frontend-body .brutal-product-hero {
        grid-template-columns: 1fr;
    }
}
