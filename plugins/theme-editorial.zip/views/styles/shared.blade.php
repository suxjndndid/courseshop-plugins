<style>
@include('theme-editorial::styles.fragments.shell')
@include('theme-editorial::styles.fragments.catalog')
@include('theme-editorial::styles.fragments.detail')
@include('theme-editorial::styles.fragments.query')
@include('theme-editorial::styles.fragments.overrides')
</style>
