<?php

use App\Core\Contracts\FrontendThemeInterface;
use App\Core\Hook\Hook;
use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Services\FrontendThemeService;

class EditorialThemePlugin implements PluginInterface, FrontendThemeInterface
{
    public function id(): string
    {
        return 'theme-editorial';
    }

    public function name(): string
    {
        return '杂志编排主题';
    }

    public function version(): string
    {
        return '1.0.0';
    }

    public function type(): PluginType
    {
        return PluginType::Theme;
    }

    public function register(): void
    {
        app('view')->addNamespace('theme-editorial', dirname(__FILE__) . '/views');
    }

    public function boot(): void
    {
        Hook::addFilter('frontend.head', function (string $html): string {
            if (!app(FrontendThemeService::class)->isActiveTheme($this->id())) {
                return $html;
            }

            return $html . "\n" . view('theme-editorial::styles.shared')->render() . "\n";
        }, 10);
    }

    public function uninstall(): void
    {
    }

    public function config(): array
    {
        return [];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }

    public function frontendThemeLabel(): string
    {
        return '杂志编排';
    }

    public function frontendThemeDescription(): string
    {
        return '像翻一本排版讲究的杂志，阅读感更柔和，也更有层次。';
    }

    public function frontendThemeOrder(): int
    {
        return 40;
    }
}
