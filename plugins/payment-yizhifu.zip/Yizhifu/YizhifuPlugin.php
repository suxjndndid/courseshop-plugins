<?php

use App\Core\Contracts\PaymentPluginInterface;
use App\Core\Contracts\PaymentGatewayInterface;
use App\Core\Plugin\PluginType;
use App\Core\Hook\Hook;
use App\Core\Admin\AdminMenu;
use App\Models\PaymentOrder;

/**
 * 易支付插件
 *
 * 实现 PaymentPluginInterface（继承 PluginInterface + paymentMethods()）。
 * 通过 Hook 系统注入支付方式 UI、支付表单生成、回调验证。
 *
 * 插件生命周期：
 * - register()：绑定 PaymentGatewayInterface → YizhifuPaymentGateway，注册菜单
 * - boot()：注册 3 个核心 Hook（支付方式/支付表单/回调处理）
 * - uninstall()：清理菜单注册
 */
class YizhifuPlugin implements PaymentPluginInterface
{
    public function id(): string
    {
        return 'payment-yizhifu';
    }

    public function name(): string
    {
        return '易支付';
    }

    public function version(): string
    {
        return '1.0.0';
    }

    public function type(): PluginType
    {
        return PluginType::Payment;
    }

    /**
     * 注册该插件支持的支付方式
     *
     * 从 plugin_config 读取已启用的方式列表（默认 alipay,wxpay），
     * 返回每种方式的 id/label/icon 信息，供框架渲染 UI。
     *
     * @return array 支付方式列表
     */
    public function paymentMethods(): array
    {
        $methodsStr = plugin_context($this->id())->config('methods', 'alipay,wxpay');
        $enabledMethods = array_filter(array_map('trim', explode(',', $methodsStr)));

        // 所有支持的支付方式定义
        $allMethods = [
            'alipay' => [
                'id' => 'alipay',
                'label' => '支付宝',
                'icon' => 'bi-alipay',
                'view' => '',
                'sort' => 1,
            ],
            'wxpay' => [
                'id' => 'wxpay',
                'label' => '微信支付',
                'icon' => 'bi-wechat',
                'view' => '',
                'sort' => 2,
            ],
        ];

        $methods = [];
        foreach ($enabledMethods as $methodId) {
            if (isset($allMethods[$methodId])) {
                $methods[] = $allMethods[$methodId];
            }
        }

        return $methods;
    }

    /**
     * 注册阶段：绑定支付网关、注册后台菜单、加载路由
     */
    public function register(): void
    {
        $pluginPath = dirname(__FILE__);

        // 加载插件辅助类（无 namespace，不走 Composer autoload）
        require_once $pluginPath . '/YizhifuPaymentGateway.php';
        require_once $pluginPath . '/Controllers/SettingsController.php';

        // 将 PaymentGatewayInterface 绑定到 YizhifuPaymentGateway
        app()->singleton(PaymentGatewayInterface::class, function () {
            return new \YizhifuPaymentGateway();
        });

        // 注册视图命名空间
        app('view')->addNamespace('payment-yizhifu', $pluginPath . '/views');

        // 加载路由文件（Controller 类路由，无闭包）
        require $pluginPath . '/routes.php';

        // 注册后台菜单
        AdminMenu::add([
            'group' => \App\Core\Admin\AdminMenu::GROUP_PAYMENT,
            'items' => [
                [
                    'label' => '支付设置',
                    'icon' => 'credit-card',
                    'route' => 'admin.plugin.payment-yizhifu',
                    'order' => 50,
                ],
            ],
        ]);
    }

    /**
     * 启动阶段：注册 3 个核心 Hook
     *
     * Hook 说明（WordPress 风格）：
     * - Filter：接收一个值，处理后返回（可链式调用多个回调）
     * - Action：在特定时机执行副作用，无返回值
     */
    public function boot(): void
    {
        // Hook 1：在订单表单渲染支付方式选择 UI
        // 参数：$html（默认的安装提示 HTML），$product（当前商品）
        // 返回：替换后的支付方式选择 HTML
        Hook::addFilter('order_form.payment_methods', function (string $html, $product) {
            return $this->renderPaymentMethods();
        }, 10);

        // Hook 2：创建支付表单/跳转
        // 参数：$result（null），$order（PaymentOrder），$paymentMethod（用户选择的支付方式如'alipay'）
        // 返回：包含 payment_html 或 redirect_url 的数组
        Hook::addFilter('order.payment_form', function ($result, PaymentOrder $order, ?string $paymentMethod) {
            return $this->processPayment($order, $paymentMethod ?? 'alipay');
        }, 10);

        // Hook 3：处理支付平台异步回调
        // 参数：$defaultResponse（'fail'），$data（回调参数数组）
        // 返回：'success' 或 'fail'
        Hook::addFilter('payment.process_notify', function (string $response, array $data) {
            return $this->handleNotify($data);
        }, 10);
    }

    /**
     * 卸载时清理后台菜单
     */
    public function uninstall(): void
    {
        AdminMenu::remove('admin.plugin.payment-yizhifu');
    }

    /**
     * 插件默认配置（plugin_config 三层合并的最低优先级）
     */
    public function config(): array
    {
        return [
            'pay_id' => '',
            'pay_key' => '',
            'pay_base_url' => '',
            'methods' => 'alipay,wxpay',
        ];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }

    // ==================== 私有方法 ====================

    /**
     * 渲染支付方式选择 HTML
     *
     * 根据 paymentMethods() 返回的列表动态生成 Bootstrap 按钮组。
     */
    private function renderPaymentMethods(): string
    {
        $methods = $this->paymentMethods();

        if (empty($methods)) {
            return '<div class="alert alert-warning mb-0">
                <i class="bi bi-exclamation-triangle me-2"></i>
                支付方式未配置，请在后台设置。
            </div>';
        }

        // Bootstrap 样式映射
        $btnStyles = [
            'alipay' => 'btn-outline-primary',
            'wxpay' => 'btn-outline-success',
        ];

        $html = '<div class="mb-3">';
        $html .= '<label class="form-label"><i class="bi bi-credit-card me-1"></i>支付方式</label>';
        $html .= '<div class="btn-group w-100" role="group" aria-label="支付方式">';

        foreach ($methods as $index => $method) {
            $id = htmlspecialchars($method['id']);
            $label = htmlspecialchars($method['label']);
            $icon = htmlspecialchars($method['icon']);
            $btnClass = $btnStyles[$method['id']] ?? 'btn-outline-secondary';
            $checked = $index === 0 ? 'checked' : '';

            $html .= '<input type="radio" class="btn-check" name="payment_method" '
                . 'id="pay' . ucfirst($id) . '" value="' . $id . '" autocomplete="off" ' . $checked . '>';
            $html .= '<label class="btn ' . $btnClass . '" for="pay' . ucfirst($id) . '">';
            $html .= '<i class="bi ' . $icon . ' me-1"></i> ' . $label;
            $html .= '</label>';
        }

        $html .= '</div></div>';
        return $html;
    }

    /**
     * 处理支付：生成支付表单并返回跳转数据
     *
     * @param PaymentOrder $order 订单模型
     * @param string $paymentMethod 支付方式标识（alipay/wxpay）
     * @return array 包含 payment_html（HTML）和 order_no 的数组
     */
    private function processPayment(PaymentOrder $order, string $paymentMethod): array
    {
        plugin_context($this->id())->logger()->info('开始生成支付表单', [
            'order_no' => $order->order_no,
            'payment_method' => $paymentMethod,
            'final_amount' => $order->final_amount,
        ]);

        try {
            /** @var \YizhifuPaymentGateway $gateway */
            $gateway = app(PaymentGatewayInterface::class);

            // 记录使用的支付插件和方式
            $order->update([
                'payment_method' => $paymentMethod,
                'payment_plugin' => $this->id(),
            ]);

            $notifyUrl = route('payment.notify');
            $returnUrl = route('payment.return');

            plugin_context($this->id())->logger()->debug('支付表单参数', [
                'order_no' => $order->order_no,
                'notify_url' => $notifyUrl,
                'return_url' => $returnUrl,
            ]);

            // 生成跳转表单 HTML
            $formHtml = $gateway->buildPaymentForm(
                $order->order_no,
                (string) $order->final_amount,
                $order->product_name,
                $notifyUrl,
                $returnUrl,
                $paymentMethod
            );

            plugin_context($this->id())->logger()->info('支付表单生成成功', [
                'order_no' => $order->order_no,
                'form_length' => strlen($formHtml),
            ]);

            return [
                'payment_html' => $formHtml,
                'order_no' => $order->order_no,
            ];

        } catch (\Exception $e) {
            plugin_context($this->id())->logger()->error('支付表单生成失败', [
                'order_no' => $order->order_no,
                'error' => $e->getMessage(),
                'file' => $e->getFile() . ':' . $e->getLine(),
                'trace' => $e->getTraceAsString(),
            ]);

            return [
                'payment_html' => '<div class="alert alert-danger">支付服务暂时不可用，请稍后重试。</div>',
                'order_no' => $order->order_no,
            ];
        }
    }

    /**
     * 处理支付异步回调
     *
     * 验签 → 查找订单 → 金额校验 → 更新支付状态 → 触发 order.after_paid Hook
     *
     * @param array $data 支付平台回调参数
     * @return string 'success' 或 'fail'
     */
    private function handleNotify(array $data): string
    {
        plugin_context($this->id())->logger()->info('开始处理支付异步回调', [
            'out_trade_no' => $data['out_trade_no'] ?? '',
            'trade_no' => $data['trade_no'] ?? '',
            'trade_status' => $data['trade_status'] ?? '',
            'money' => $data['money'] ?? '',
            'type' => $data['type'] ?? '',
        ]);

        try {
            /** @var \YizhifuPaymentGateway $gateway */
            $gateway = app(PaymentGatewayInterface::class);

            return $gateway->handleNotify($data, function (string $outTradeNo, array $notifyData) {
                // 查找订单
                $order = PaymentOrder::where('order_no', $outTradeNo)->first();

                if (!$order) {
                    plugin_context($this->id())->logger()->error('支付回调：订单不存在', [
                        'out_trade_no' => $outTradeNo,
                    ]);
                    return;
                }

                // 幂等处理：已支付的订单跳过
                if ($order->is_paid) {
                    plugin_context($this->id())->logger()->info('支付回调：订单已支付，跳过', [
                        'order_no' => $outTradeNo,
                    ]);
                    $order->appendCallbackLog('重复回调，订单已支付');
                    return;
                }

                // 金额校验（0.01 容差）
                $notifyAmount = (float) ($notifyData['money'] ?? 0);
                $expectedAmount = (float) $order->final_amount;
                if (abs($notifyAmount - $expectedAmount) > 0.01) {
                    plugin_context($this->id())->logger()->error('支付回调：金额不匹配', [
                        'order_no' => $outTradeNo,
                        'expected' => $expectedAmount,
                        'received' => $notifyAmount,
                        'diff' => abs($notifyAmount - $expectedAmount),
                    ]);
                    $order->appendCallbackLog("金额不匹配：期望 {$expectedAmount}，收到 {$notifyAmount}");
                    return;
                }

                // 更新订单状态为已支付
                $thirdPartyNo = $notifyData['trade_no'] ?? '';
                $order->markAsPaid($thirdPartyNo);
                $order->appendCallbackLog("支付成功 | 三方单号:{$thirdPartyNo} | 金额:{$notifyAmount}");

                plugin_context($this->id())->logger()->info('订单支付成功，开始触发履约流程', [
                    'order_no' => $outTradeNo,
                    'trade_no' => $thirdPartyNo,
                    'amount' => $notifyAmount,
                ]);

                // 派发 OrderPaid 事件（通知插件等可监听）
                event(new \App\Core\Event\OrderPaid($order));

                // 触发 order.after_paid Hook，让其他插件执行履约
                Hook::action('order.after_paid', $order);

                plugin_context($this->id())->logger()->info('订单支付回调处理完毕', [
                    'order_no' => $outTradeNo,
                ]);
            });

        } catch (\Exception $e) {
            plugin_context($this->id())->logger()->error('支付回调处理异常', [
                'error' => $e->getMessage(),
                'exception_class' => get_class($e),
                'file' => $e->getFile() . ':' . $e->getLine(),
                'out_trade_no' => $data['out_trade_no'] ?? '',
                'trace' => $e->getTraceAsString(),
            ]);
            return 'fail';
        }
    }
}
