<?php

use App\Core\Contracts\PaymentGatewayInterface;
use Illuminate\Support\Facades\Http;

/**
 * 易支付网关适配器
 *
 * 实现 PaymentGatewayInterface 接口（定义在 app/Core/Contracts/）。
 * 对接易支付（Yizhifu）平台，负责订单创建、签名验证、异步通知处理。
 *
 * 从 WangKeLava 迁移而来，关键改动：
 * - 使用 plugin_config() 三层合并读取配置（DB > .env > 默认值）
 * - 移除对 ParamMasker 的依赖（日志脱敏内联处理）
 * - 命名空间移除（插件类通过 require_once 加载，无 PSR-4）
 */
class YizhifuPaymentGateway implements PaymentGatewayInterface
{
    protected string $pid;
    protected string $key;
    protected string $baseUrl;

    // 异步通知必需参数
    private const NOTIFY_REQUIRED_PARAMS = [
        'trade_no', 'out_trade_no', 'type', 'money', 'trade_status', 'sign', 'sign_type'
    ];

    public function __construct()
    {
        // 使用 plugin_config() 三层合并读取：DB > .env > 插件默认值
        $this->pid = plugin_context('payment-yizhifu')->config('pay_id', '');
        $this->key = plugin_context('payment-yizhifu')->config('pay_key', '');
        $this->baseUrl = rtrim(plugin_context('payment-yizhifu')->config('pay_base_url', ''), '/');

        // 配置不完整时记录警告但不抛异常（允许安装但不可用）
        if (empty($this->pid) || empty($this->key) || empty($this->baseUrl)) {
            plugin_context('payment-yizhifu')->logger()->warning('易支付配置不完整，请在后台设置', [
                'has_pid' => !empty($this->pid),
                'has_key' => !empty($this->key),
                'has_base_url' => !empty($this->baseUrl),
            ]);
        }
    }

    /**
     * 通过 API 创建支付订单
     *
     * @param string $outTradeNo 商户订单号
     * @param string $money 订单金额
     * @param string $name 商品名称
     * @param string $notifyUrl 异步通知地址
     * @param string $returnUrl 同步跳转地址
     * @param string $type 支付方式（alipay/wxpay）
     * @return array 支付平台返回的订单信息
     * @throws RuntimeException 配置缺失时抛出
     */
    public function createOrder(
        string $outTradeNo,
        string $money,
        string $name,
        string $notifyUrl,
        string $returnUrl,
        string $type = 'alipay'
    ): array {
        $this->ensureConfigured();

        plugin_context('payment-yizhifu')->logger()->info('创建支付订单', [
            'out_trade_no' => $outTradeNo,
            'money' => $money,
            'type' => $type,
        ]);

        $params = $this->buildOrderParams($outTradeNo, $money, $name, $notifyUrl, $returnUrl, $type);
        $result = $this->post('/mapi.php', $this->signParams($params));

        if (($result['code'] ?? 0) == 1) {
            plugin_context('payment-yizhifu')->logger()->info('支付订单创建成功', [
                'out_trade_no' => $outTradeNo,
                'trade_no' => $result['trade_no'] ?? '',
            ]);
        } else {
            plugin_context('payment-yizhifu')->logger()->error('支付订单创建失败', [
                'out_trade_no' => $outTradeNo,
                'error_msg' => $result['msg'] ?? '未知错误',
            ]);
        }

        return $result;
    }

    /**
     * 生成跳转支付表单 HTML
     *
     * 返回包含签名参数的自动提交表单，前端页面渲染后自动跳转到支付网关。
     */
    public function buildPaymentForm(
        string $outTradeNo,
        string $money,
        string $name,
        string $notifyUrl,
        string $returnUrl,
        string $type = 'alipay',
        ?string $sitename = null
    ): string {
        $this->ensureConfigured();

        plugin_context('payment-yizhifu')->logger()->debug('构建支付表单', [
            'out_trade_no' => $outTradeNo,
            'money' => $money,
            'type' => $type,
        ]);

        $params = $this->buildOrderParams($outTradeNo, $money, $name, $notifyUrl, $returnUrl, $type);

        if ($sitename) {
            $params['sitename'] = $sitename;
        }

        $params = $this->signParams($params);
        $formUrl = $this->baseUrl . '/submit.php';

        return $this->generateFormHtml($formUrl, $params);
    }

    /**
     * 查询订单状态
     */
    public function queryOrder(string $outTradeNo): array
    {
        $this->ensureConfigured();

        $result = $this->post('/qjt.php?act=query_order', [
            'apiid' => $this->pid,
            'apikey' => $this->key,
            'out_trade_no' => $outTradeNo,
        ]);

        plugin_context('payment-yizhifu')->logger()->debug('订单查询结果', [
            'out_trade_no' => $outTradeNo,
            'code' => $result['code'] ?? 0,
        ]);

        return $result;
    }

    /**
     * 判断订单是否已支付
     */
    public function isPaid(string $outTradeNo): bool
    {
        $result = $this->queryOrder($outTradeNo);
        return ($result['code'] ?? 0) == 1 && ($result['status'] ?? 0) == 1;
    }

    /**
     * 处理支付平台异步通知
     *
     * 流程：参数验证 → 签名验证 → 状态检查 → 执行业务回调
     *
     * @param array $data 通知数据
     * @param callable $callback 支付成功后的业务回调，签名：fn(string $outTradeNo, array $data)
     * @return string 'success' 或 'fail'
     */
    public function handleNotify(array $data, callable $callback): string
    {
        $outTradeNo = $data['out_trade_no'] ?? '';
        $tradeStatus = $data['trade_status'] ?? '';

        plugin_context('payment-yizhifu')->logger()->info('开始验证支付回调', [
            'out_trade_no' => $outTradeNo,
            'trade_status' => $tradeStatus,
            'money' => $data['money'] ?? '',
        ]);

        // 验证参数完整性
        if (!$this->validateParams($data, self::NOTIFY_REQUIRED_PARAMS)) {
            return 'fail';
        }

        // 验证签名
        if (!$this->verifySign($data)) {
            plugin_context('payment-yizhifu')->logger()->error('支付回调签名验证失败', [
                'out_trade_no' => $outTradeNo,
            ]);
            return 'fail';
        }

        plugin_context('payment-yizhifu')->logger()->info('支付回调验证通过', [
            'out_trade_no' => $outTradeNo,
        ]);

        // 处理支付成功
        if ($tradeStatus === 'TRADE_SUCCESS') {
            try {
                $callback($outTradeNo, $data);

                plugin_context('payment-yizhifu')->logger()->info('支付回调业务处理成功', [
                    'out_trade_no' => $outTradeNo,
                    'trade_no' => $data['trade_no'] ?? '',
                    'money' => $data['money'] ?? '',
                ]);
            } catch (\Exception $e) {
                plugin_context('payment-yizhifu')->logger()->error('支付回调业务处理失败', [
                    'out_trade_no' => $outTradeNo,
                    'error' => $e->getMessage(),
                ]);
                throw $e;
            }
        } else {
            plugin_context('payment-yizhifu')->logger()->info('支付状态非成功，跳过业务处理', [
                'out_trade_no' => $outTradeNo,
                'trade_status' => $tradeStatus,
            ]);
        }

        return 'success';
    }

    /**
     * 验证签名
     *
     * MD5 签名算法：
     * 1. 过滤空值和签名参数
     * 2. 按参数名字母排序
     * 3. 拼接 URL query 格式 + 密钥
     * 4. MD5 哈希
     * 使用 hash_equals() 防止时序攻击
     */
    public function verifySign(array $data): bool
    {
        if (!isset($data['sign'])) {
            plugin_context('payment-yizhifu')->logger()->warning('签名验证失败：缺少 sign 参数');
            return false;
        }

        $receivedSign = $data['sign'];
        unset($data['sign'], $data['sign_type']);

        $expectedSign = $this->generateSign($data);
        $isValid = hash_equals($expectedSign, $receivedSign);

        if (!$isValid) {
            plugin_context('payment-yizhifu')->logger()->error('签名不匹配', [
                'received' => $receivedSign,
                'expected' => $expectedSign,
            ]);
        }

        return $isValid;
    }

    /**
     * 获取订单二维码 URL
     */
    public function getQrcodeUrl(string $orderNo, bool $isPlatformOrder = false): string
    {
        if (empty($orderNo)) {
            throw new InvalidArgumentException('订单号不能为空');
        }

        $param = $isPlatformOrder ? 'trade_no' : 'out_trade_no';
        return $this->baseUrl . '/qrcode_order.php?' . $param . '=' . urlencode($orderNo);
    }

    // ==================== 私有方法 ====================

    /**
     * 确保配置已设置，未配置时抛出异常
     */
    private function ensureConfigured(): void
    {
        if (empty($this->pid) || empty($this->key) || empty($this->baseUrl)) {
            throw new RuntimeException('易支付配置不完整，请在后台【插件管理 → 支付设置】中配置');
        }
    }

    /**
     * 构建订单基础参数
     */
    private function buildOrderParams(
        string $outTradeNo,
        string $money,
        string $name,
        string $notifyUrl,
        string $returnUrl,
        string $type
    ): array {
        return [
            'pid' => $this->pid,
            'type' => $type,
            'out_trade_no' => $outTradeNo,
            'notify_url' => $notifyUrl,
            'return_url' => $returnUrl,
            'name' => $name,
            'money' => $money,
        ];
    }

    /**
     * 为参数添加 MD5 签名
     */
    private function signParams(array $params): array
    {
        $params['sign'] = $this->generateSign($params);
        $params['sign_type'] = 'MD5';
        return $params;
    }

    /**
     * 生成 MD5 签名字符串
     *
     * 算法：过滤空值/签名字段 → 按 key 排序 → urldecode(http_build_query) + 密钥 → md5
     */
    private function generateSign(array $params): string
    {
        // 过滤空值和签名参数
        $params = array_filter($params, function ($value, $key) {
            return $value !== '' && $value !== null && !in_array($key, ['sign', 'sign_type']);
        }, ARRAY_FILTER_USE_BOTH);

        ksort($params);

        $signStr = urldecode(http_build_query($params)) . $this->key;
        return md5($signStr);
    }

    /**
     * 生成支付跳转表单 HTML（自动提交）
     */
    private function generateFormHtml(string $action, array $params): string
    {
        $inputs = '';
        foreach ($params as $key => $value) {
            $inputs .= sprintf(
                '<input type="hidden" name="%s" value="%s">',
                htmlspecialchars($key),
                htmlspecialchars($value)
            );
        }

        return '<form id="payment_form" action="' . htmlspecialchars($action) . '" method="post">' . $inputs . '</form>';
    }

    /**
     * 验证必需参数是否齐全
     */
    private function validateParams(array $data, array $required): bool
    {
        $missing = [];
        foreach ($required as $param) {
            if (!isset($data[$param]) || $data[$param] === '') {
                $missing[] = $param;
            }
        }

        if (!empty($missing)) {
            plugin_context('payment-yizhifu')->logger()->error('支付回调缺少必要参数', [
                'missing_params' => $missing,
            ]);
            return false;
        }

        return true;
    }

    /**
     * 发送 POST 请求到支付平台
     */
    private function post(string $uri, array $params): array
    {
        $url = $this->baseUrl . $uri;
        $startTime = microtime(true);

        plugin_context('payment-yizhifu')->logger()->info('发起支付API请求', [
            'url' => $url,
            'param_keys' => array_keys($params),
        ]);

        try {
            $response = Http::timeout(30)->asForm()->post($url, $params);
            $duration = round(microtime(true) - $startTime, 3);

            if ($response->successful()) {
                $data = $response->json() ?? ['code' => 0, 'msg' => '响应格式错误'];
                plugin_context('payment-yizhifu')->logger()->info('支付API响应成功', [
                    'url' => $url,
                    'http_status' => $response->status(),
                    'response_code' => $data['code'] ?? null,
                    'duration' => $duration . '秒',
                ]);
                return $data;
            }

            plugin_context('payment-yizhifu')->logger()->error('支付API请求HTTP错误', [
                'url' => $url,
                'status' => $response->status(),
                'response_body' => mb_substr($response->body(), 0, 500),
                'duration' => $duration . '秒',
            ]);

            return ['code' => 0, 'msg' => 'HTTP Error: ' . $response->status()];

        } catch (\Exception $e) {
            $duration = round(microtime(true) - $startTime, 3);
            plugin_context('payment-yizhifu')->logger()->error('支付API请求异常', [
                'url' => $url,
                'error' => $e->getMessage(),
                'exception_class' => get_class($e),
                'duration' => $duration . '秒',
            ]);

            return ['code' => 0, 'msg' => '请求失败: ' . $e->getMessage()];
        }
    }
}
