<?php

/**
 * Yizhifu 插件路由定义
 *
 * 所有路由集中注册，指向 Controller 方法，无闭包。
 * 由 YizhifuPlugin::register() 中 require 加载。
 */

use Illuminate\Support\Facades\Route;

Route::prefix('admin')
    ->middleware('admin.auth')
    ->group(function () {
        Route::get('/plugin/payment-yizhifu', [\Yizhifu\Controllers\SettingsController::class, 'index'])
            ->name('admin.plugin.payment-yizhifu');

        Route::post('/plugin/payment-yizhifu', [\Yizhifu\Controllers\SettingsController::class, 'save'])
            ->name('admin.plugin.payment-yizhifu.save');
    });
