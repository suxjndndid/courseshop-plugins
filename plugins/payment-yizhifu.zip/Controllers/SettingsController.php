<?php

namespace Yizhifu\Controllers;

use App\Models\Setting;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;

/**
 * 易支付后台设置控制器
 */
class SettingsController
{
    public function index()
    {
        $settings = Setting::getGroup('payment-yizhifu');
        return view('payment-yizhifu::settings', ['settings' => $settings]);
    }

    public function save(Request $request)
    {
        $request->validate([
            'pay_id'      => 'required|string|max:50',
            'pay_base_url' => 'required|url|max:255',
            'methods'     => 'required|string|max:100',
        ]);

        Setting::setGroup('payment-yizhifu', [
            'pay_id'      => $request->input('pay_id'),
            'pay_base_url' => $request->input('pay_base_url'),
            'methods'     => $request->input('methods'),
        ]);

        // pay_key 敏感字段只在有输入时更新
        if ($request->filled('pay_key')) {
            Setting::setGroup('payment-yizhifu', [
                'pay_key' => $request->input('pay_key'),
            ]);
        }

        app(ActivityLogService::class)->log('setting', '更新易支付配置');

        return redirect()->route('admin.plugin.payment-yizhifu')
            ->with('success', '支付配置已保存');
    }
}
