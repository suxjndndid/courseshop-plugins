<?php

use App\Core\Contracts\PaymentGatewayInterface;
use Illuminate\Support\Facades\Http;

/**
 * 易支付网关适配器
 *
 * 实现 PaymentGatewayInterface（定义在 app/Core/Contracts/）。
 * 对接易支付平台，支持支付宝、微信两种方式，均以 HTML 自动提交表单跳转。
 *
 * createPayment() 返回 type='html_form'，插件在 Hook 中将 payload['html'] 注入页面。
 * verifyNotify() / parseNotify() 拆分了原 handleNotify() 的验签和业务两部分职责。
 */
class YizhifuPaymentGateway implements PaymentGatewayInterface
{
    protected string $pid;
    protected string $key;
    protected string $baseUrl;

    // 异步通知必需参数
    private const NOTIFY_REQUIRED_PARAMS = [
        'trade_no', 'out_trade_no', 'type', 'money', 'trade_status', 'sign', 'sign_type'
    ];

    public function __construct()
    {
        // 使用 plugin_config() 三层合并读取：DB > .env > 插件默认值
        $this->pid     = plugin_context('payment-yizhifu')->config('pay_id', '');
        $this->key     = plugin_context('payment-yizhifu')->config('pay_key', '');
        $this->baseUrl = rtrim(plugin_context('payment-yizhifu')->config('pay_base_url', ''), '/');

        if (empty($this->pid) || empty($this->key) || empty($this->baseUrl)) {
            plugin_context('payment-yizhifu')->logger()->warning('易支付配置不完整，请在后台设置', [
                'has_pid'      => !empty($this->pid),
                'has_key'      => !empty($this->key),
                'has_base_url' => !empty($this->baseUrl),
            ]);
        }
    }

    /**
     * 发起支付
     *
     * 易支付通过自动提交 HTML 表单跳转到支付页面，返回 type='html_form'。
     *
     * @param array $params 框架标准支付参数（out_trade_no/amount/subject/notify_url/return_url/method）
     * @return array ['type'=>'html_form', 'payload'=>['html'=>string], 'out_trade_no'=>string]
     * @throws RuntimeException 配置不完整时抛出
     */
    public function createPayment(array $params): array
    {
        $this->ensureConfigured();

        $outTradeNo = $params['out_trade_no'];
        $method     = $params['method'] ?? 'alipay';

        plugin_context('payment-yizhifu')->logger()->info('发起支付', [
            'out_trade_no' => $outTradeNo,
            'amount'       => $params['amount'],
            'method'       => $method,
        ]);

        $formParams = [
            'pid'          => $this->pid,
            'type'         => $method,
            'out_trade_no' => $outTradeNo,
            'notify_url'   => $params['notify_url'],
            'return_url'   => $params['return_url'],
            'name'         => $params['subject'],
            'money'        => $params['amount'],
        ];

        $formParams = $this->signParams($formParams);
        $formUrl    = $this->baseUrl . '/submit.php';
        $html       = $this->generateFormHtml($formUrl, $formParams);

        plugin_context('payment-yizhifu')->logger()->info('支付表单生成成功', [
            'out_trade_no' => $outTradeNo,
        ]);

        return [
            'type'         => 'html_form',
            'payload'      => ['html' => $html],
            'out_trade_no' => $outTradeNo,
        ];
    }

    /**
     * 验证异步通知真实性
     *
     * 易支付使用 MD5 签名，算法：过滤空值/签名字段 → 按 key 排序 → urldecode(http_build_query) + 密钥 → md5。
     * 使用 hash_equals() 防止时序攻击。
     *
     * @param array $data 原始通知数据（$_POST）
     * @return bool
     */
    public function verifyNotify(array $data): bool
    {
        // 参数完整性检查
        $missing = [];
        foreach (self::NOTIFY_REQUIRED_PARAMS as $param) {
            if (!isset($data[$param]) || $data[$param] === '') {
                $missing[] = $param;
            }
        }
        if (!empty($missing)) {
            plugin_context('payment-yizhifu')->logger()->error('支付回调缺少必要参数', [
                'missing_params' => $missing,
            ]);
            return false;
        }

        if (!isset($data['sign'])) {
            plugin_context('payment-yizhifu')->logger()->warning('签名验证失败：缺少 sign 参数');
            return false;
        }

        $receivedSign = $data['sign'];
        $signData     = $data;
        unset($signData['sign'], $signData['sign_type']);

        $expectedSign = $this->generateSign($signData);
        $isValid      = hash_equals($expectedSign, $receivedSign);

        if (!$isValid) {
            plugin_context('payment-yizhifu')->logger()->error('签名不匹配', [
                'out_trade_no' => $data['out_trade_no'] ?? '',
                'received'     => $receivedSign,
                'expected'     => $expectedSign,
            ]);
        }

        return $isValid;
    }

    /**
     * 解析通知为框架标准结构
     *
     * 仅在 verifyNotify() 返回 true 后调用。
     *
     * @param array $data 原始通知数据
     * @return array ['out_trade_no', 'platform_no', 'amount', 'paid', 'raw']
     */
    public function parseNotify(array $data): array
    {
        return [
            'out_trade_no' => $data['out_trade_no'] ?? '',
            'platform_no'  => $data['trade_no'] ?? '',
            'amount'       => $data['money'] ?? '0',
            'paid'         => ($data['trade_status'] ?? '') === 'TRADE_SUCCESS',
            'raw'          => $data,
        ];
    }

    /**
     * 主动查询订单状态
     *
     * @param string $outTradeNo 商户订单号
     * @return array ['out_trade_no', 'platform_no', 'amount', 'paid', 'raw']
     * @throws RuntimeException 配置不完整时抛出
     */
    public function queryOrder(string $outTradeNo): array
    {
        $this->ensureConfigured();

        $raw = $this->post('/qjt.php?act=query_order', [
            'apiid'        => $this->pid,
            'apikey'       => $this->key,
            'out_trade_no' => $outTradeNo,
        ]);

        plugin_context('payment-yizhifu')->logger()->debug('订单查询结果', [
            'out_trade_no' => $outTradeNo,
            'code'         => $raw['code'] ?? 0,
        ]);

        return [
            'out_trade_no' => $outTradeNo,
            'platform_no'  => $raw['trade_no'] ?? '',
            'amount'       => $raw['money'] ?? '0',
            'paid'         => ($raw['code'] ?? 0) == 1 && ($raw['status'] ?? 0) == 1,
            'raw'          => $raw,
        ];
    }

    // ==================== 公开辅助方法 ====================

    /**
     * 验证签名（测试及框架回调入口使用）
     */
    public function verifySign(array $data): bool
    {
        if (!isset($data['sign'])) {
            return false;
        }

        $receivedSign = $data['sign'];
        $signData = $data;
        unset($signData['sign'], $signData['sign_type']);

        $expectedSign = $this->generateSign($signData);
        return hash_equals($expectedSign, $receivedSign);
    }

    /**
     * 获取订单二维码 URL
     *
     * @param string $orderNo 订单号
     * @param bool $isPlatform true 时用 trade_no（平台单号），false 时用 out_trade_no（商户单号）
     */
    public function getQrcodeUrl(string $orderNo, bool $isPlatform = false): string
    {
        if (empty($orderNo)) {
            throw new \InvalidArgumentException('订单号不能为空');
        }

        $param = $isPlatform ? 'trade_no' : 'out_trade_no';
        return $this->baseUrl . '/qrcode_order.php?' . $param . '=' . urlencode($orderNo);
    }

    /**
     * 处理异步回调通知
     *
     * @param array $data 回调参数
     * @param callable $callback 验签通过且交易成功时调用，参数：($outTradeNo, $data)
     * @return string 'success' 或 'fail'
     */
    public function handleNotify(array $data, callable $callback): string
    {
        // 参数完整性检查
        if (!$this->validateParams($data, self::NOTIFY_REQUIRED_PARAMS)) {
            return 'fail';
        }

        // 签名验证
        if (!$this->verifySign($data)) {
            return 'fail';
        }

        // 仅 TRADE_SUCCESS 触发回调
        if (($data['trade_status'] ?? '') === 'TRADE_SUCCESS') {
            $callback($data['out_trade_no'], $data);
        }

        return 'success';
    }

    // ==================== 私有方法 ====================

    private function ensureConfigured(): void
    {
        if (empty($this->pid) || empty($this->key) || empty($this->baseUrl)) {
            throw new RuntimeException('易支付配置不完整，请在后台【插件管理 → 支付设置】中配置');
        }
    }

    /**
     * 校验参数是否完整且非空
     *
     * @param array $data 待校验的数组
     * @param array $required 必需的键名列表
     * @return bool
     */
    private function validateParams(array $data, array $required): bool
    {
        foreach ($required as $key) {
            if (!isset($data[$key]) || $data[$key] === '') {
                return false;
            }
        }
        return true;
    }

    private function signParams(array $params): array
    {
        $params['sign']      = $this->generateSign($params);
        $params['sign_type'] = 'MD5';
        return $params;
    }

    /**
     * 生成 MD5 签名
     *
     * 算法：过滤空值/签名字段 → 按 key 排序 → urldecode(http_build_query) + 密钥 → md5
     */
    private function generateSign(array $params): string
    {
        $params = array_filter($params, function ($value, $key) {
            return $value !== '' && $value !== null && !in_array($key, ['sign', 'sign_type']);
        }, ARRAY_FILTER_USE_BOTH);

        ksort($params);

        return md5(urldecode(http_build_query($params)) . $this->key);
    }

    /**
     * 生成自动提交的 HTML 表单
     */
    private function generateFormHtml(string $action, array $params): string
    {
        $inputs = '';
        foreach ($params as $key => $value) {
            $inputs .= sprintf(
                '<input type="hidden" name="%s" value="%s">',
                htmlspecialchars($key),
                htmlspecialchars($value)
            );
        }

        return '<form id="payment_form" action="' . htmlspecialchars($action) . '" method="post">' . $inputs . '</form>';
    }

    /**
     * 发送 POST 请求到易支付平台
     */
    private function post(string $uri, array $params): array
    {
        $url       = $this->baseUrl . $uri;
        $startTime = microtime(true);

        plugin_context('payment-yizhifu')->logger()->info('发起支付API请求', [
            'url'        => $url,
            'param_keys' => array_keys($params),
        ]);

        try {
            $response = Http::timeout(30)->asForm()->post($url, $params);
            $duration = round(microtime(true) - $startTime, 3);

            if ($response->successful()) {
                $data = $response->json() ?? ['code' => 0, 'msg' => '响应格式错误'];
                plugin_context('payment-yizhifu')->logger()->info('支付API响应成功', [
                    'url'           => $url,
                    'http_status'   => $response->status(),
                    'response_code' => $data['code'] ?? null,
                    'duration'      => $duration . '秒',
                ]);
                return $data;
            }

            plugin_context('payment-yizhifu')->logger()->error('支付API请求HTTP错误', [
                'url'           => $url,
                'status'        => $response->status(),
                'response_body' => mb_substr($response->body(), 0, 500),
                'duration'      => $duration . '秒',
            ]);

            return ['code' => 0, 'msg' => 'HTTP Error: ' . $response->status()];

        } catch (\Exception $e) {
            $duration = round(microtime(true) - $startTime, 3);
            plugin_context('payment-yizhifu')->logger()->error('支付API请求异常', [
                'url'             => $url,
                'error'           => $e->getMessage(),
                'exception_class' => get_class($e),
                'duration'        => $duration . '秒',
            ]);

            return ['code' => 0, 'msg' => '请求失败: ' . $e->getMessage()];
        }
    }
}
