<?php

/**
 * Yizhifu 插件路由定义
 *
 * 所有路由集中注册，指向 Controller 方法，无闭包。
 * 由 YizhifuPlugin::register() 中 require 加载。
 */

use Yizhifu\Controllers\SettingsController;
use Illuminate\Support\Facades\Route;

admin_route_group(function () {
    Route::get('/plugin/payment-yizhifu', [SettingsController::class, 'index'])
        ->name('admin.plugin.payment-yizhifu');

    Route::post('/plugin/payment-yizhifu', [SettingsController::class, 'save'])
        ->name('admin.plugin.payment-yizhifu.save');
});
