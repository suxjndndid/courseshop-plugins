{{-- 易支付插件后台设置页面 --}}
@extends('admin.layouts.app')

@section('title', '支付设置 - 易支付')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 class="text-xl font-semibold mb-4 flex items-center">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/>
            </svg>
            易支付配置
        </h2>

        {{-- <div class="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-3 rounded mb-4 text-sm">
            <p class="font-medium">Mock 联调快速配置（推荐）</p>
            <p class="mt-1"><code>pay_id = mock-pay-pid</code>，<code>pay_key = mock-pay-key</code>。</p>
            <p class="mt-1"><code>pay_base_url</code> 是给浏览器访问的地址，建议填 <code>http://127.0.0.1:18080</code>（不是容器名）。</p>
            <p class="mt-1">Mock 控制台：<code>http://127.0.0.1:18080/__mock/console</code>，可直接模拟错误签名/回调失败/随机失败。</p>
        </div> --}}

        @if(session('success'))
        <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded mb-4">
            {{ session('success') }}
        </div>
        @endif

        @if($errors->any())
        <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
            @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach
        </div>
        @endif

        <form action="{{ route('admin.plugin.payment-yizhifu.save') }}" method="POST">
            @csrf

            {{-- 商户 ID --}}
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">商户 ID (PID)</label>
                <input type="text"
                       name="pay_id"
                       value="{{ $settings['pay_id'] ?? '' }}"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                       placeholder="请输入易支付商户 ID"
                       required>
            </div>

            {{-- 商户密钥 --}}
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">商户密钥 (KEY)</label>
                <input type="password"
                       name="pay_key"
                       value=""
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                       placeholder="{{ !empty($settings['pay_key']) ? '已设置（留空不修改）' : '请输入易支付商户密钥' }}">
                <p class="text-sm text-gray-500 mt-1">敏感信息，留空表示不修改。建议通过 .env 设置：PAYMENT_YIZHIFU_PAY_KEY</p>
            </div>

            {{-- 支付网关地址 --}}
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">支付网关地址</label>
                <input type="url"
                       name="pay_base_url"
                       value="{{ $settings['pay_base_url'] ?? '' }}"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                       placeholder="https://pay.example.com"
                       required>
                <p class="text-sm text-gray-500 mt-1">这里必须是“浏览器可访问”的地址。若填容器名（如 <code>thirdparty-mock</code>），前台支付页会打不开。</p>
            </div>

            {{-- 支付方式 --}}
            <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-1">启用的支付方式</label>
                <input type="text"
                       name="methods"
                       value="{{ $settings['methods'] ?? 'alipay,wxpay' }}"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                       placeholder="alipay,wxpay"
                       required>
                <p class="text-sm text-gray-500 mt-1">多个方式用逗号分隔。支持：alipay（支付宝）、wxpay（微信支付）</p>
            </div>

            {{-- 回调地址信息（只读） --}}
            <div class="bg-gray-50 rounded-md p-4 mb-6">
                <h3 class="text-sm font-medium text-gray-700 mb-2">回调配置（在支付平台设置）</h3>
                <div class="text-sm text-gray-600 space-y-1">
                    <p><span class="font-medium">异步通知地址：</span>{{ route('payment.notify') }}</p>
                    <p><span class="font-medium">同步跳转地址：</span>{{ route('payment.return') }}</p>
                </div>
            </div>

            <button type="submit"
                    class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors">
                保存配置
            </button>
        </form>
    </div>
</div>
@endsection
