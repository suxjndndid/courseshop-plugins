<?php

/**
 * 默认主题插件路由定义
 *
 * 由 DefaultThemePlugin::register() 中 require 加载。
 */

use ThemeDefault\Controllers\SettingsController;
use Illuminate\Support\Facades\Route;

admin_route_group(function () {
    Route::get('/plugin/theme-default', [SettingsController::class, 'index'])
        ->name('admin.plugin.theme-default');

    Route::post('/plugin/theme-default', [SettingsController::class, 'save'])
        ->name('admin.plugin.theme-default.save');
});
