body.frontend-body {
    color: var(--theme-ink, var(--frontend-ink));
    background: var(--theme-body-background, var(--frontend-bg));
}

body.frontend-body .frontend-nav {
    padding: 16px 0 0;
}

body.frontend-body .frontend-nav-shell {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    padding: 0 0 14px;
    border-bottom: 4px solid var(--theme-line, var(--frontend-line));
    flex-wrap: wrap;
}

body.frontend-body .frontend-brand {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    color: var(--theme-ink, var(--frontend-ink)) !important;
    text-transform: uppercase;
    font-size: 22px;
    font-weight: 700;
}

body.frontend-body .frontend-brand-mark,
body.frontend-body .frontend-footer-mark {
    width: 40px;
    height: 40px;
    display: inline-grid;
    place-items: center;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-accent, var(--frontend-accent));
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .frontend-brand-text {
    line-height: 1;
}

body.frontend-body .frontend-nav-toggle {
    border: 3px solid var(--theme-line, var(--frontend-line));
    border-radius: 0;
    padding: 7px 10px;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .frontend-nav-toggle:focus {
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .frontend-nav-collapse {
    align-items: center;
    gap: 14px;
    flex-grow: 0;
}

body.frontend-body .frontend-nav-links {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 0;
}

body.frontend-body .frontend-nav-links .nav-item {
    list-style: none;
}

body.frontend-body .frontend-nav-link {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    color: var(--theme-ink, var(--frontend-ink)) !important;
    padding: 8px 12px !important;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .frontend-nav-link.active,
body.frontend-body .frontend-nav-link:hover {
    background: var(--theme-line, var(--frontend-line));
    color: var(--theme-accent, var(--frontend-accent)) !important;
}

body.frontend-body .frontend-nav-actions {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

body.frontend-body .frontend-footer {
    padding: 0 0 28px;
    margin-top: 18px;
}

body.frontend-body .frontend-footer-shell {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    padding: 18px 0 0;
    border-top: 4px solid var(--theme-line, var(--frontend-line));
    flex-wrap: wrap;
}

body.frontend-body .frontend-footer-brand {
    display: inline-flex;
    align-items: center;
    gap: 12px;
}

body.frontend-body .frontend-footer-copy {
    display: grid;
    gap: 2px;
}

body.frontend-body .frontend-footer-copy strong {
    font-size: 14px;
}

body.frontend-body .frontend-footer-copy p,
body.frontend-body .frontend-footer-note {
    margin: 0;
    color: var(--theme-muted, var(--frontend-muted));
    font-size: 12px;
}

body.frontend-body .frontend-footer-links {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

body.frontend-body .frontend-footer-links a {
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    padding: 7px 10px;
    font-family: var(--frontend-font-display);
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .frontend-footer-links a:hover {
    background: var(--theme-line, var(--frontend-line));
    color: var(--theme-accent, var(--frontend-accent));
}

body.frontend-body .custom-toast {
    background: var(--theme-paper, var(--frontend-paper));
    color: var(--theme-ink, var(--frontend-ink));
    border: 2px solid var(--theme-line, var(--frontend-line));
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .custom-toast.toast-success { border-left: 8px solid var(--theme-success, var(--frontend-success)); }
body.frontend-body .custom-toast.toast-error { border-left: 8px solid var(--theme-accent-2, var(--frontend-accent-2)); }
body.frontend-body .custom-toast.toast-warning { border-left: 8px solid var(--theme-accent, var(--frontend-accent)); }
body.frontend-body .custom-toast.toast-info { border-left: 8px solid var(--theme-info, var(--frontend-info)); }

body.frontend-body .custom-toast .toast-title {
    color: var(--theme-ink, var(--frontend-ink));
}

body.frontend-body .custom-toast .toast-message,
body.frontend-body .custom-toast .toast-close,
body.frontend-body .confirm-dialog-body .confirm-description {
    color: var(--theme-muted, var(--frontend-muted));
}

body.frontend-body .confirm-dialog {
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    color: var(--theme-ink, var(--frontend-ink));
    box-shadow: var(--theme-shadow, var(--frontend-shadow));
}

body.frontend-body .confirm-dialog-header {
    border-bottom: 2px solid var(--theme-line, var(--frontend-line));
}

body.frontend-body .confirm-dialog-footer {
    border-top: 2px solid var(--theme-line, var(--frontend-line));
}

body.frontend-body .confirm-btn {
    border: 2px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    color: var(--theme-ink, var(--frontend-ink));
}

body.frontend-body .confirm-btn.confirm-btn-accept {
    background: var(--theme-line, var(--frontend-line));
    color: var(--theme-accent, var(--frontend-accent));
}

body.frontend-body .confirm-btn:hover {
    transform: translate(-1px, -1px);
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .brutal-home-hero,
body.frontend-body .brutal-home-content,
body.frontend-body .brutal-query-shell,
body.frontend-body .results-shell,
body.frontend-body .brutal-query-title-bar,
body.frontend-body .brutal-detail-ticker,
body.frontend-body .brutal-product-hero,
body.frontend-body .brutal-panel,
body.frontend-body .brutal-announcement-strip {
    box-shadow: var(--theme-shadow, var(--frontend-shadow));
}

body.frontend-body .brutal-home-hero {
    display: grid;
    grid-template-columns: minmax(0, 1.4fr) minmax(280px, 0.8fr);
    gap: 20px;
    margin-bottom: 24px;
}

body.frontend-body .brutal-hero-main,
body.frontend-body .brutal-hero-side,
body.frontend-body .brutal-home-content,
body.frontend-body .brutal-query-main {
    display: grid;
    gap: 14px;
}

body.frontend-body .brutal-hero-main {
    border: 4px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    padding: 24px;
}

body.frontend-body .brutal-hero-title,
body.frontend-body .brutal-query-title-bar h1,
body.frontend-body .brutal-panel-title,
body.frontend-body .results-head h2 {
    margin: 0;
    font-family: var(--frontend-font-display);
    text-transform: uppercase;
    letter-spacing: 0.01em;
}

body.frontend-body .brutal-hero-title {
    font-size: clamp(30px, 5vw, 48px);
    line-height: 0.95;
}

body.frontend-body .brutal-hitokoto-box {
    border-left: 6px solid var(--theme-accent, var(--frontend-accent));
    border-right: 6px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-accent-soft, #fff8cd);
    padding: 14px 16px;
}

body.frontend-body .brutal-hitokoto-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 8px;
    font-family: var(--frontend-font-display);
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
}

body.frontend-body .hitokoto-copy {
    margin: 0;
    color: var(--theme-ink, var(--frontend-ink));
    font-size: 14px;
    font-weight: 700;
}

body.frontend-body .hitokoto-icon,
body.frontend-body .hitokoto-from {
    color: var(--theme-muted, var(--frontend-muted));
}

body.frontend-body .hitokoto-text {
    font-style: italic;
}

body.frontend-body .hitokoto-refresh {
    font-size: 13px;
}

body.frontend-body .brutal-hero-side {
    align-content: start;
}

body.frontend-body .brutal-hero-btn,
body.frontend-body .brutal-button,
body.frontend-body .brutal-ghost-button,
body.frontend-body .brutal-submit-btn,
body.frontend-body .query-btn,
body.frontend-body .clear-btn,
body.frontend-body .brutal-coupon-btn {
    min-height: 48px;
    border: 4px solid var(--theme-line, var(--frontend-line));
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
    font-family: var(--frontend-font-display);
    font-size: 13px;
    font-weight: 700;
    text-transform: uppercase;
    cursor: pointer;
    transition: transform 0.15s ease, background 0.15s ease, color 0.15s ease;
}

body.frontend-body .brutal-hero-btn,
body.frontend-body .brutal-button,
body.frontend-body .query-btn,
body.frontend-body .brutal-submit-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: var(--theme-line, var(--frontend-line));
    color: var(--theme-accent, var(--frontend-accent));
    padding: 12px 14px;
}

body.frontend-body .brutal-ghost-button,
body.frontend-body .clear-btn,
body.frontend-body .brutal-coupon-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: var(--theme-paper, var(--frontend-paper));
    color: var(--theme-ink, var(--frontend-ink));
    padding: 10px 14px;
}

body.frontend-body .brutal-hero-btn:hover,
body.frontend-body .brutal-button:hover,
body.frontend-body .brutal-ghost-button:hover,
body.frontend-body .brutal-submit-btn:hover,
body.frontend-body .query-btn:hover,
body.frontend-body .clear-btn:hover,
body.frontend-body .brutal-coupon-btn:hover {
    transform: translate(-2px, -2px);
}

body.frontend-body .brutal-hero-info,
body.frontend-body .query-help {
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    padding: 14px 16px;
    font-size: 13px;
    font-weight: 700;
}

body.frontend-body .frontend-theme-switcher {
    position: relative;
}

body.frontend-body .frontend-theme-switcher-trigger {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    padding: 14px 16px;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
    cursor: pointer;
}

body.frontend-body .frontend-theme-switcher-trigger-copy {
    display: grid;
    gap: 2px;
    text-align: left;
}

body.frontend-body .frontend-theme-switcher-trigger-copy strong,
body.frontend-body .frontend-theme-switcher-trigger-action {
    font-family: var(--frontend-font-display);
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
}

body.frontend-body .frontend-theme-switcher-trigger-copy span {
    color: var(--theme-muted, var(--frontend-muted));
    font-size: 11px;
}

body.frontend-body .frontend-theme-switcher-trigger-action {
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-line, var(--frontend-line));
    color: var(--theme-accent, var(--frontend-accent));
    padding: 6px 10px;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .frontend-theme-switcher-panel {
    position: absolute;
    top: calc(100% + 10px);
    left: 0;
    right: 0;
    z-index: 30;
    display: grid;
    gap: 10px;
    border: 4px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    padding: 14px;
    box-shadow: var(--theme-shadow, var(--frontend-shadow));
}

body.frontend-body .frontend-theme-switcher-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
}

body.frontend-body .frontend-theme-switcher-head strong {
    font-family: var(--frontend-font-display);
    font-size: 12px;
    text-transform: uppercase;
}

body.frontend-body .frontend-theme-switcher-note {
    color: var(--theme-muted, var(--frontend-muted));
    font-size: 11px;
    margin: 0;
}

body.frontend-body .frontend-theme-switcher-close {
    width: 34px;
    height: 34px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
    font-family: var(--frontend-font-display);
    font-size: 18px;
    font-weight: 700;
    line-height: 1;
    cursor: pointer;
}

body.frontend-body .frontend-theme-switcher-options {
    display: grid;
    gap: 8px;
}

body.frontend-body .frontend-theme-option-form {
    margin: 0;
}

body.frontend-body .frontend-theme-option {
    display: block;
    width: 100%;
    text-align: left;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    padding: 10px 12px;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
    cursor: pointer;
}

body.frontend-body .frontend-theme-option.is-active,
body.frontend-body .frontend-theme-option:hover {
    background: var(--theme-line, var(--frontend-line));
    color: var(--theme-accent, var(--frontend-accent));
}

body.frontend-body .frontend-theme-option strong,
body.frontend-body .frontend-theme-option span {
    display: block;
}

body.frontend-body .frontend-theme-option strong {
    font-family: var(--frontend-font-display);
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
}

body.frontend-body .frontend-theme-option span {
    margin-top: 4px;
    font-size: 11px;
    line-height: 1.5;
}

@media (max-width: 768px) {
    body.frontend-body .frontend-theme-switcher-trigger {
        align-items: flex-start;
        flex-direction: column;
    }

    body.frontend-body .frontend-theme-switcher-trigger-action {
        width: 100%;
        text-align: center;
    }
}

body.frontend-body .brutal-announcement-strip {
    display: flex;
    align-items: stretch;
    gap: 12px;
    border: 4px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-accent, var(--frontend-accent));
    padding: 12px 16px;
    margin-bottom: 24px;
}

body.frontend-body .brutal-announcement-btn {
    width: 34px;
    height: 34px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    font-size: 18px;
    font-weight: 900;
    cursor: pointer;
}

body.frontend-body .brutal-announcement-content {
    flex: 1;
    min-width: 0;
}

body.frontend-body .brutal-announcement-item {
    display: none;
}

body.frontend-body .brutal-announcement-item.is-active {
    display: block;
}

body.frontend-body .brutal-announcement-title {
    margin: 0 0 4px;
    font-size: 14px;
    font-weight: 900;
}

body.frontend-body .brutal-announcement-text {
    margin: 0;
    color: rgba(0, 0, 0, 0.78);
    font-size: 12px;
    font-weight: 700;
}

body.frontend-body .brutal-announcement-tag {
    display: inline-flex;
    align-items: center;
    margin-right: 6px;
    padding: 2px 6px;
    border: 2px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    font-family: var(--frontend-font-display);
    font-size: 10px;
    text-transform: uppercase;
}

body.frontend-body .brutal-announcement-dots {
    display: flex;
    gap: 6px;
    margin-top: 8px;
}

body.frontend-body .brutal-announcement-dot {
    width: 10px;
    height: 10px;
    border: 2px solid transparent;
    border-radius: 999px;
    background: rgba(0, 0, 0, 0.28);
    cursor: pointer;
}

body.frontend-body .brutal-announcement-dot.is-active {
    background: var(--theme-line, var(--frontend-line));
    border-color: var(--theme-paper, var(--frontend-paper));
}

body.frontend-body .brutal-announcement-empty,
body.frontend-body .brutal-disclaimer {
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-accent, var(--frontend-accent));
    padding: 14px 16px;
    font-size: 13px;
    font-weight: 700;
}

body.frontend-body .brutal-section-title {
    margin: 0;
    border-bottom: 3px solid var(--theme-line, var(--frontend-line));
    padding-bottom: 8px;
    font-family: var(--frontend-font-display);
    font-size: 18px;
    font-weight: 700;
    text-transform: uppercase;
}

body.frontend-body .brutal-filter-row {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
}

body.frontend-body .brutal-chip {
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    padding: 8px 14px;
    font-family: var(--frontend-font-display);
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .brutal-chip.is-active {
    background: var(--theme-line, var(--frontend-line));
    color: var(--theme-accent, var(--frontend-accent));
}

body.frontend-body .brutal-search-hint {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    width: fit-content;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    padding: 8px 12px;
    font-size: 12px;
    font-weight: 700;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

