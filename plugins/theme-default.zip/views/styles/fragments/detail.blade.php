body.frontend-body .brutal-product-hero {
    display: grid;
    grid-template-columns: minmax(0, 1.1fr) minmax(0, 0.9fr);
    gap: 22px;
    align-items: start;
    border: 4px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-panel-gradient, var(--theme-paper, var(--frontend-paper)));
    padding: 18px;
    margin-bottom: 22px;
}

body.frontend-body .brutal-hero-media {
    position: relative;
    overflow: hidden;
    border: 4px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-image-bg, #dcdcdc);
    padding: 14px;
}

body.frontend-body .brutal-hero-media img {
    width: 100%;
    aspect-ratio: 4 / 3;
    object-fit: cover;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
}

body.frontend-body .brutal-floating-tags {
    position: absolute;
    inset: 12px 12px auto auto;
    z-index: 1;
    display: grid;
    gap: 8px;
    justify-items: end;
}

body.frontend-body .brutal-tag {
    display: inline-flex;
    align-items: center;
    min-height: 34px;
    padding: 6px 10px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    font-family: var(--frontend-font-display);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .brutal-tag.is-yellow {
    background: var(--theme-accent, var(--frontend-accent));
}

body.frontend-body .brutal-tag.is-green {
    background: var(--theme-success-soft, #d5ffd8);
}

body.frontend-body .brutal-hero-summary {
    display: grid;
    gap: 14px;
    align-content: start;
}

body.frontend-body .brutal-eyebrow {
    background: var(--theme-accent, var(--frontend-accent));
}

body.frontend-body .brutal-price-strip {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 14px;
}

body.frontend-body .brutal-price-card,
body.frontend-body .brutal-status-card {
    border: 3px solid var(--theme-line, var(--frontend-line));
    padding: 14px 16px;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .brutal-price-card {
    background: var(--theme-line, var(--frontend-line));
    color: var(--theme-accent, var(--frontend-accent));
}

body.frontend-body .brutal-status-card {
    min-width: 130px;
    display: grid;
    place-items: center;
    text-align: center;
    background: var(--theme-success-soft, #d5ffd8);
    font-family: var(--frontend-font-display);
    font-weight: 700;
    text-transform: uppercase;
}

body.frontend-body .price-label {
    margin-bottom: 6px;
    font-family: var(--frontend-font-display);
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
}

body.frontend-body .price-value {
    font-size: clamp(34px, 6vw, 58px);
    line-height: 1;
    font-weight: 900;
}

body.frontend-body .brutal-detail-block,
body.frontend-body .brutal-query-shell,
body.frontend-body .results-shell,
body.frontend-body .brutal-panel {
    border: 4px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
}

body.frontend-body .brutal-detail-block {
    padding: 12px;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .brutal-detail-note,
body.frontend-body .query-tip,
body.frontend-body .brutal-biz-hint {
    margin: 0;
    color: var(--theme-muted, var(--frontend-muted));
    font-family: var(--frontend-font-display);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
}

body.frontend-body .product-detail-html {
    display: grid;
    gap: 10px;
    font-size: 14px;
}

body.frontend-body .product-detail-html > *:first-child {
    margin-top: 0;
}

body.frontend-body .product-detail-html > *:last-child {
    margin-bottom: 0;
}

body.frontend-body .product-detail-html table {
    width: 100%;
    border-collapse: collapse;
}

body.frontend-body .product-detail-html th,
body.frontend-body .product-detail-html td {
    border: 2px solid var(--theme-line, var(--frontend-line));
    padding: 8px 10px;
}

body.frontend-body .brutal-hero-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

body.frontend-body .brutal-work-grid {
    display: grid;
    grid-template-columns: minmax(0, 1.45fr) minmax(320px, 0.95fr);
    grid-template-areas: 'biz buy';
    gap: 22px;
}

body.frontend-body #brutal-buy-panel {
    grid-area: buy;
    align-self: start;
    position: sticky;
    top: 18px;
}

body.frontend-body #brutal-biz-panel {
    grid-area: biz;
}

body.frontend-body .brutal-panel {
    padding: 20px;
}

body.frontend-body .brutal-panel-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 16px;
}

body.frontend-body .brutal-panel-title {
    font-size: 22px;
}

body.frontend-body .brutal-panel-kicker {
    background: var(--theme-accent, var(--frontend-accent));
}

body.frontend-body .brutal-biz-result {
    min-height: 220px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-panel-alt, #f8f8f8);
    padding: 14px;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .brutal-biz-empty {
    color: var(--theme-muted, var(--frontend-muted));
    font-size: 13px;
    font-weight: 700;
}

body.frontend-body .brutal-field-group {
    display: grid;
    gap: 8px;
    margin-bottom: 16px;
}

body.frontend-body .brutal-field-label {
    font-family: var(--frontend-font-display);
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
}

body.frontend-body .brutal-input,
body.frontend-body .brutal-textarea,
body.frontend-body #product-adapter-ui .form-control {
    width: 100%;
    min-height: 52px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    border-radius: 0;
    background: var(--theme-paper, var(--frontend-paper));
    color: var(--theme-ink, var(--frontend-ink));
    padding: 10px 12px;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
    font-size: 15px;
}

body.frontend-body .brutal-textarea {
    min-height: 120px;
    resize: vertical;
}

body.frontend-body .brutal-input::placeholder,
body.frontend-body .brutal-textarea::placeholder,
body.frontend-body #product-adapter-ui .form-control::placeholder,
body.frontend-body .query-input::placeholder {
    color: var(--theme-muted, var(--frontend-muted));
}

body.frontend-body .brutal-input:focus,
body.frontend-body .brutal-textarea:focus,
body.frontend-body .query-input:focus,
body.frontend-body #product-adapter-ui .form-control:focus {
    outline: none;
    box-shadow: 0 0 0 3px rgba(0, 0, 0, 0.12), var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .brutal-coupon-row {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 10px;
}

body.frontend-body .coupon-result {
    padding: 10px 12px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    font-size: 13px;
    font-weight: 700;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .coupon-result.success {
    border-left: 8px solid var(--theme-success, var(--frontend-success));
}

body.frontend-body .coupon-result.error {
    border-left: 8px solid var(--theme-accent-2, var(--frontend-accent-2));
}

body.frontend-body .coupon-info {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
}

body.frontend-body .coupon-clear {
    cursor: pointer;
}

body.frontend-body #couponCode.verified {
    background: var(--theme-success-soft, #eafff2);
}

body.frontend-body .invalid-feedback {
    color: var(--theme-accent-2, var(--frontend-accent-2));
    font-size: 12px;
    font-weight: 700;
}

body.frontend-body #payment-methods-container,
body.frontend-body .brutal-payment-container {
    display: grid;
    gap: 10px;
    margin-bottom: 16px;
}

body.frontend-body .brutal-inline-warning {
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-accent-soft, #fff8cd);
    padding: 12px;
    font-size: 13px;
    font-weight: 700;
}

body.frontend-body .brutal-price-breakdown {
    display: grid;
    gap: 10px;
    margin-bottom: 16px;
    padding: 14px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-panel-alt, #f7f7f7);
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .price-line,
body.frontend-body .price-total {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    font-size: 14px;
    font-weight: 700;
}

body.frontend-body .price-total {
    padding-top: 10px;
    border-top: 3px solid var(--theme-line, var(--frontend-line));
    font-family: var(--frontend-font-display);
    font-size: 16px;
    text-transform: uppercase;
}

body.frontend-body .brutal-submit-btn {
    width: 100%;
}

body.frontend-body .brutal-submit-btn:disabled {
    opacity: 0.65;
    cursor: not-allowed;
}

body.frontend-body .brutal-helper-list {
    display: grid;
    gap: 10px;
    margin: 16px 0 0;
    padding: 0;
    list-style: none;
}

body.frontend-body .brutal-helper-list li {
    display: grid;
    gap: 2px;
    padding: 10px 12px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-panel-alt, #f8f8f8);
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .brutal-helper-list span {
    color: var(--theme-muted, var(--frontend-muted));
    font-size: 12px;
}

body.frontend-body #product-adapter-ui {
    display: grid;
    gap: 10px;
    margin-bottom: 16px;
}

body.frontend-body #product-adapter-ui .mb-3 {
    margin-bottom: 0 !important;
    display: grid;
    gap: 8px;
}

body.frontend-body #product-adapter-ui .form-label {
    margin-bottom: 0;
    font-family: var(--frontend-font-display);
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
}

body.frontend-body #product-adapter-ui .input-group.password-input-group {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 10px;
    align-items: stretch;
}

body.frontend-body .btn-toggle-password,
body.frontend-body #product-adapter-ui .btn,
body.frontend-body .order-actions .btn {
    border: 3px solid var(--theme-line, var(--frontend-line));
    border-radius: 0;
    background: var(--theme-paper, var(--frontend-paper));
    color: var(--theme-ink, var(--frontend-ink));
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
    font-size: 12px;
    font-weight: 700;
}

body.frontend-body #product-adapter-ui .btn-primary,
body.frontend-body .btn-refresh {
    background: var(--theme-accent, var(--frontend-accent));
}

body.frontend-body #product-adapter-ui .btn-outline-primary,
body.frontend-body #product-adapter-ui .btn-outline-secondary,
body.frontend-body .btn-rebrush {
    background: var(--theme-paper, var(--frontend-paper));
}

body.frontend-body .course-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
}

body.frontend-body .course-summary {
    font-size: 12px;
    font-weight: 700;
}

body.frontend-body .course-grid {
    display: grid;
    gap: 12px;
}

body.frontend-body .course-card {
    display: block;
    cursor: pointer;
}

body.frontend-body .course-checkbox {
    position: absolute;
    opacity: 0;
    pointer-events: none;
}

body.frontend-body .course-card-body {
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 12px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    padding: 12px;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .course-card-check {
    width: 26px;
    height: 26px;
    display: inline-grid;
    place-items: center;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
}

body.frontend-body .course-card.selected .course-card-body {
    background: var(--theme-accent-soft, #fff8cd);
}

body.frontend-body .course-card.selected .course-card-check {
    background: var(--theme-accent, var(--frontend-accent));
}

body.frontend-body .course-card-name {
    font-size: 14px;
    font-weight: 900;
}

body.frontend-body .course-card-meta {
    color: var(--theme-muted, var(--frontend-muted));
    font-size: 12px;
    font-weight: 700;
}

body.frontend-body .shake {
    animation: brutalShake 0.35s linear;
}

@keyframes brutalShake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-4px); }
    75% { transform: translateX(4px); }
}

body.frontend-body #selfCourseResult {
    border: 3px solid var(--theme-line, var(--frontend-line)) !important;
    border-radius: 0 !important;
    background: var(--theme-panel-alt, #f8f8f8) !important;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body #selfCourseResult table {
    width: 100%;
    border-collapse: collapse;
}

body.frontend-body #selfCourseResult th,
body.frontend-body #selfCourseResult td {
    border: 2px solid var(--theme-line, var(--frontend-line));
    padding: 8px 10px;
}

body.frontend-body .brutal-query-title-bar h1 {
    font-size: clamp(28px, 4.5vw, 42px);
    line-height: 1;
}

body.frontend-body .brutal-query-title-bar p {
    margin: 0;
    font-size: 14px;
    font-weight: 700;
}
