body.frontend-body .brutal-products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(220px, 220px));
    gap: 16px;
    justify-content: start;
}

body.frontend-body .brutal-product {
    border: 4px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    overflow: hidden;
    transition: transform 0.15s ease, border-color 0.15s ease;
}

body.frontend-body .brutal-product:hover {
    transform: rotate(1deg) scale(1.02);
    border-color: var(--theme-accent, var(--frontend-accent));
}

body.frontend-body .brutal-product.is-offline {
    opacity: 0.62;
}

body.frontend-body .brutal-product-image {
    border-bottom: 4px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-image-bg, #dcdcdc);
    aspect-ratio: 4 / 3;
    overflow: hidden;
}

body.frontend-body .brutal-product-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center center;
}

body.frontend-body .brutal-product-body {
    display: grid;
    gap: 8px;
    padding: 12px 14px 14px;
}

body.frontend-body .brutal-product-name {
    margin: 0;
    font-size: 14px;
    font-weight: 900;
}

body.frontend-body .brutal-product-meta {
    margin: 0;
    color: var(--theme-muted, var(--frontend-muted));
    font-size: 12px;
    font-weight: 700;
}

body.frontend-body .brutal-product-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
}

body.frontend-body .brutal-product-price {
    color: var(--theme-accent-2, var(--frontend-accent-2));
    font-size: 20px;
    font-weight: 900;
}

body.frontend-body .brutal-buy-btn {
    border: 2px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-line, var(--frontend-line));
    color: var(--theme-accent, var(--frontend-accent));
    padding: 7px 10px;
    font-family: var(--frontend-font-display);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
}

body.frontend-body .brutal-buy-btn.is-disabled {
    opacity: 0.65;
}

body.frontend-body .brutal-pagination-wrap {
    margin-top: 8px;
}

body.frontend-body .frontend-pagination {
    gap: 8px;
}

body.frontend-body .frontend-pagination .page-link {
    min-width: 38px;
    height: 38px;
    display: inline-grid;
    place-items: center;
    border: 3px solid var(--theme-line, var(--frontend-line));
    border-radius: 0;
    background: var(--theme-paper, var(--frontend-paper));
    color: var(--theme-ink, var(--frontend-ink));
    font-family: var(--frontend-font-display);
    font-size: 12px;
    font-weight: 700;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .frontend-pagination .page-item.active .page-link,
body.frontend-body .frontend-pagination .page-link:hover {
    background: var(--theme-line, var(--frontend-line));
    color: var(--theme-accent, var(--frontend-accent));
}

body.frontend-body .frontend-pagination .page-item.disabled .page-link {
    opacity: 0.45;
}

body.frontend-body .brutal-empty-state,
body.frontend-body .empty-state {
    border: 4px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    padding: 28px 18px;
    text-align: center;
    font-size: 14px;
    font-weight: 700;
}

body.frontend-body .payment-redirect-overlay {
    position: fixed;
    inset: 0;
    z-index: 3000;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 24px;
    background: rgba(0, 0, 0, 0.72);
}

body.frontend-body .payment-redirect-overlay.show {
    display: flex;
}

body.frontend-body .payment-redirect-card {
    width: min(420px, 100%);
    border: 4px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    color: var(--theme-ink, var(--frontend-ink));
    box-shadow: var(--theme-shadow, var(--frontend-shadow));
    padding: 18px 16px;
    text-align: center;
}

body.frontend-body .payment-redirect-title {
    margin-top: 12px;
    font-family: var(--frontend-font-display);
    font-size: 20px;
    font-weight: 700;
    text-transform: uppercase;
}

body.frontend-body .payment-redirect-message {
    margin-top: 8px;
    font-size: 13px;
    font-weight: 700;
}

body.frontend-body .payment-wait-page {
    min-height: 72vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px 0;
}

body.frontend-body .payment-wait-card {
    width: min(460px, 100%);
    display: grid;
    gap: 16px;
    border: 4px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-panel-gradient, var(--theme-paper, var(--frontend-paper)));
    box-shadow: var(--theme-shadow, var(--frontend-shadow));
    padding: 22px 20px;
}

body.frontend-body .payment-wait-badge {
    width: fit-content;
    padding: 6px 10px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-accent, var(--frontend-accent));
    font-family: var(--frontend-font-display);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .payment-wait-title {
    margin: 0;
    font-family: var(--frontend-font-display);
    font-size: clamp(28px, 5vw, 38px);
    line-height: 0.95;
    text-transform: uppercase;
}

body.frontend-body .payment-wait-subtitle {
    margin: 0;
    font-size: 14px;
    font-weight: 700;
}

body.frontend-body .payment-wait-meta {
    display: grid;
    gap: 10px;
    padding: 14px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-panel-alt, #f8f8f8);
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .payment-wait-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    font-size: 13px;
    font-weight: 700;
}

body.frontend-body .payment-wait-row span {
    color: var(--theme-muted, var(--frontend-muted));
}

body.frontend-body .payment-wait-row strong {
    text-align: right;
    word-break: break-all;
}

body.frontend-body .payment-wait-countdown {
    display: grid;
    justify-items: center;
    gap: 10px;
}

body.frontend-body .payment-wait-countdown-label,
body.frontend-body .payment-wait-countdown-unit {
    margin: 0;
    color: var(--theme-muted, var(--frontend-muted));
    font-size: 12px;
    font-weight: 700;
}

body.frontend-body .payment-wait-countdown-number {
    width: 78px;
    height: 78px;
    display: inline-grid;
    place-items: center;
    border: 4px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-line, var(--frontend-line));
    color: var(--theme-accent, var(--frontend-accent));
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
    font-family: var(--frontend-font-display);
    font-size: 34px;
    font-weight: 700;
}

body.frontend-body .payment-wait-status {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    min-height: 48px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    padding: 10px 12px;
    font-size: 13px;
    font-weight: 700;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .payment-wait-button {
    min-height: 50px;
    border: 4px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-line, var(--frontend-line));
    color: var(--theme-accent, var(--frontend-accent));
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
    font-family: var(--frontend-font-display);
    font-size: 13px;
    font-weight: 700;
    text-transform: uppercase;
    cursor: pointer;
}

body.frontend-body .payment-wait-button:hover {
    transform: translate(-2px, -2px);
}

body.frontend-body #paymentFormContainer {
    display: none;
}

body.frontend-body .brutal-detail-ticker,
body.frontend-body .brutal-query-title-bar {
    display: grid;
    gap: 4px;
    border: 4px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-accent, var(--frontend-accent));
    padding: 12px 14px;
    margin-bottom: 16px;
}

body.frontend-body .brutal-detail-ticker {
    grid-template-columns: auto 1fr auto;
    gap: 14px;
    align-items: center;
}

body.frontend-body .ticker-label,
body.frontend-body .ticker-note,
body.frontend-body .brutal-panel-kicker,
body.frontend-body .brutal-eyebrow,
body.frontend-body .count-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: fit-content;
    padding: 6px 10px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    font-family: var(--frontend-font-display);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
}

body.frontend-body .ticker-copy {
    font-size: 14px;
    font-weight: 700;
}

body.frontend-body .brutal-breadcrumb {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
    margin-bottom: 18px;
    padding: 8px 12px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
    font-family: var(--frontend-font-display);
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
}
