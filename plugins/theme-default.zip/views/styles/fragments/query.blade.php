body.frontend-body .brutal-query-shell {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 300px;
    gap: 14px;
    align-items: start;
    padding: 16px;
    margin-bottom: 18px;
    background: var(--theme-panel-gradient, var(--theme-paper, var(--frontend-paper)));
}

body.frontend-body .query-tabs {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

body.frontend-body .query-tab {
    border: 3px solid var(--theme-line, var(--frontend-line));
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
    background: var(--theme-paper, var(--frontend-paper));
    color: var(--theme-ink, var(--frontend-ink));
    padding: 8px 12px;
    font-family: var(--frontend-font-display);
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    cursor: pointer;
}

body.frontend-body .query-tab.active {
    background: var(--theme-line, var(--frontend-line));
    color: var(--theme-accent, var(--frontend-accent));
}

body.frontend-body .query-form {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 170px;
    gap: 10px;
}

body.frontend-body .query-input {
    min-height: 52px;
    border: 3px solid var(--theme-line, var(--frontend-line));
    border-radius: 0;
    background: var(--theme-paper, var(--frontend-paper));
    padding: 10px 12px;
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
    font-size: 15px;
}

body.frontend-body .query-help {
    display: grid;
    gap: 10px;
    background: var(--theme-accent-soft, #fff8cd);
}

body.frontend-body .query-help h3 {
    margin: 0;
    font-family: var(--frontend-font-display);
    font-size: 14px;
    text-transform: uppercase;
}

body.frontend-body .query-help-item {
    display: flex;
    gap: 8px;
    color: var(--theme-muted, var(--frontend-muted));
    font-size: 13px;
    font-weight: 700;
}

body.frontend-body .query-help-item strong {
    color: var(--theme-info, var(--frontend-info));
    white-space: nowrap;
}

body.frontend-body .results-shell {
    padding: 16px;
}

body.frontend-body .results-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 12px;
}

body.frontend-body .results-head h2 {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-size: 24px;
    line-height: 1;
}

body.frontend-body .count-badge {
    min-width: 28px;
    height: 28px;
    background: var(--theme-accent, var(--frontend-accent));
}

body.frontend-body .order-list {
    display: grid;
    gap: 12px;
}

body.frontend-body .order-card {
    border: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    box-shadow: var(--theme-shadow-sm, var(--frontend-shadow-sm));
    overflow: hidden;
    animation: brutalCardIn 0.35s ease-out;
}

@keyframes brutalCardIn {
    from {
        opacity: 0;
        transform: translateY(12px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

body.frontend-body .order-card.loading {
    opacity: 0.65;
    pointer-events: none;
}

body.frontend-body .order-header {
    border-bottom: 3px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-panel-alt, #f8f8f8);
    padding: 10px 12px;
}

body.frontend-body .order-header code {
    border: 2px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    padding: 3px 8px;
    font-family: var(--frontend-font-display);
    font-size: 12px;
    font-weight: 700;
}

body.frontend-body .badge-status {
    border: 2px solid var(--theme-line, var(--frontend-line));
    padding: 4px 10px;
    font-size: 12px;
    font-weight: 700;
}

body.frontend-body .badge-status.status-completed { background: #b6f3c8; }
body.frontend-body .badge-status.status-processing { background: #a4d5ff; }
body.frontend-body .badge-status.status-pending { background: #fff3b5; }
body.frontend-body .badge-status.status-failed { background: #ffb7b7; }

body.frontend-body .order-body {
    display: grid;
    gap: 10px;
    padding: 12px;
}

body.frontend-body .info-row {
    display: grid;
    gap: 2px;
}

body.frontend-body .info-label {
    color: var(--theme-muted, var(--frontend-muted));
    font-size: 12px;
    font-weight: 700;
}

body.frontend-body .info-value {
    font-size: 14px;
    font-weight: 700;
}

body.frontend-body .progress-row {
    display: grid;
    gap: 8px;
}

body.frontend-body .progress-label {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
}

body.frontend-body .progress-bar-wrapper {
    height: 12px;
    border: 2px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-panel-alt, #ececec);
}

body.frontend-body .progress-bar-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--theme-success, var(--frontend-success)), #b6f3c8);
}

body.frontend-body .order-remarks {
    display: grid;
    gap: 8px;
    padding: 10px;
    border: 2px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-panel-alt, #f8f8f8);
}

body.frontend-body .remarks-title {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-family: var(--frontend-font-display);
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
}

body.frontend-body .remarks-parsed {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

body.frontend-body .remark-item {
    display: inline-flex;
    align-items: center;
    padding: 4px 8px;
    border: 2px solid var(--theme-line, var(--frontend-line));
    background: var(--theme-paper, var(--frontend-paper));
    font-size: 12px;
    font-weight: 700;
}

body.frontend-body .remark-item.highlight {
    background: var(--theme-accent-soft, #fff8cd);
}

body.frontend-body .order-actions {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
}

body.frontend-body .action-half {
    display: grid;
}

body.frontend-body .action-half:first-child {
    border-right: 2px solid var(--theme-line, var(--frontend-line));
}

body.frontend-body .order-actions .btn {
    width: 100%;
    min-height: 46px;
    border: 0;
    box-shadow: none;
}

@media (max-width: 991px) {
    body.frontend-body .frontend-nav-collapse {
        flex-basis: 100%;
    }

    body.frontend-body .frontend-nav-links,
    body.frontend-body .frontend-nav-actions {
        padding-top: 12px;
    }

    body.frontend-body .brutal-home-hero,
    body.frontend-body .brutal-query-shell,
    body.frontend-body .brutal-product-hero,
    body.frontend-body .brutal-work-grid {
        grid-template-columns: 1fr;
    }

    body.frontend-body .brutal-work-grid {
        grid-template-areas:
            'buy'
            'biz';
    }

    body.frontend-body #brutal-buy-panel {
        position: static;
    }
}

@media (max-width: 720px) {
    body.frontend-body .brutal-detail-ticker {
        grid-template-columns: 1fr;
    }

    body.frontend-body .brutal-price-strip,
    body.frontend-body .query-form,
    body.frontend-body .brutal-coupon-row {
        grid-template-columns: 1fr;
    }

    body.frontend-body .order-actions {
        grid-template-columns: 1fr;
    }

    body.frontend-body .action-half:first-child {
        border-right: 0;
        border-bottom: 2px solid var(--theme-line, var(--frontend-line));
    }
}

@media (max-width: 575px) {
    body.frontend-body .brutal-hero-main,
    body.frontend-body .brutal-panel,
    body.frontend-body .results-shell,
    body.frontend-body .brutal-query-shell,
    body.frontend-body .brutal-product-hero {
        padding: 14px;
    }

    body.frontend-body .frontend-footer-shell,
    body.frontend-body .frontend-footer-brand,
    body.frontend-body .frontend-footer-links {
        width: 100%;
    }
}
