<style>
:root {
    --theme-paper: #ffffff;
    --theme-ink: #111111;
    --theme-muted: #5a5a5a;
    --theme-line: #000000;
    --theme-accent: #ffeb3b;
    --theme-accent-2: #ff5a36;
    --theme-success: #2ecc71;
    --theme-info: #2563eb;
    --theme-accent-soft: #fff8cd;
    --theme-success-soft: #d5ffd8;
    --theme-image-bg: #dcdcdc;
    --theme-panel-alt: #f8f8f8;
    --theme-shadow: 8px 8px 0 #000000;
    --theme-shadow-sm: 4px 4px 0 #000000;
    --theme-panel-gradient: linear-gradient(135deg, rgba(255, 235, 59, 0.24), rgba(255, 90, 54, 0.12)), #ffffff;
    --theme-body-background: radial-gradient(circle at 8% 0%, rgba(255, 235, 59, 0.35), transparent 28%), linear-gradient(180deg, #f3f3f3 0%, #e8e8e8 100%);
}
</style>
