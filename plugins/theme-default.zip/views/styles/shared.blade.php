<style>
@include('theme-default::styles.fragments.shell')
@include('theme-default::styles.fragments.catalog')
@include('theme-default::styles.fragments.detail')
@include('theme-default::styles.fragments.query')
</style>
