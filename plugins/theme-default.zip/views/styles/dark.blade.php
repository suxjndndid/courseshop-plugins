<style>
:root {
    --theme-paper: #161616;
    --theme-ink: #f5f5f5;
    --theme-muted: #c8c8c8;
    --theme-line: #f3f3f3;
    --theme-accent: #ffd84d;
    --theme-accent-2: #ff7a59;
    --theme-success: #39d98a;
    --theme-info: #79a8ff;
    --theme-accent-soft: #302905;
    --theme-success-soft: #103524;
    --theme-image-bg: #2a2a2a;
    --theme-panel-alt: #202020;
    --theme-shadow: 8px 8px 0 rgba(0, 0, 0, 0.72);
    --theme-shadow-sm: 4px 4px 0 rgba(0, 0, 0, 0.72);
    --theme-panel-gradient: linear-gradient(135deg, rgba(255, 216, 77, 0.12), rgba(255, 122, 89, 0.08)), #161616;
    --theme-body-background: radial-gradient(circle at 8% 0%, rgba(255, 216, 77, 0.12), transparent 26%), linear-gradient(180deg, #121212 0%, #090909 100%);
}

body.frontend-body .frontend-nav-toggle .navbar-toggler-icon {
    filter: invert(1);
}

body.frontend-body .badge-status.status-completed { color: #04180e; }
body.frontend-body .badge-status.status-processing { color: #06172f; }
body.frontend-body .badge-status.status-pending { color: #2a2300; }
body.frontend-body .badge-status.status-failed { color: #2f0505; }
</style>
