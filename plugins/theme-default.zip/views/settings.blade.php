{{-- 主题插件后台设置页面 --}}
{{-- @extends 继承后台管理布局，提供侧边栏、顶栏等公共 UI --}}
@extends('admin.layouts.app')

@section('title', '主题设置 - Brutal Theme')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 class="text-xl font-semibold mb-4 flex items-center">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"/>
            </svg>
            Brutal 主题设置
        </h2>

        {{-- 成功提示 --}}
        @if(session('success'))
        <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded mb-4">
            {{ session('success') }}
        </div>
        @endif

        {{-- 错误提示 --}}
        @if($errors->any())
        <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
            @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach
        </div>
        @endif

        <form action="{{ route('admin.plugin.theme-default.save') }}" method="POST">
            @csrf

            <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-3">选择 brutal 主题变体</label>

                <label class="flex items-center p-4 border rounded-lg mb-3 cursor-pointer transition-colors
                    {{ $activeTheme === 'default' ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200 hover:border-gray-300' }}">
                    <input type="radio"
                           name="active_theme"
                           value="default"
                           class="w-4 h-4 text-indigo-600 border-gray-300 focus:ring-indigo-500"
                           {{ $activeTheme === 'default' ? 'checked' : '' }}>
                    <div class="ml-3 flex-1">
                        <span class="block text-sm font-medium text-gray-900">Brutal Classic</span>
                        <span class="block text-sm text-gray-500">浅底工业感布局，黄色强调色，适合当前首页 / 详情 / 查询页。</span>
                    </div>
                    <div class="flex gap-1.5 ml-4">
                        <span class="w-6 h-6 rounded-full border border-gray-300" style="background-color: #ffeb3b;" title="强调色"></span>
                        <span class="w-6 h-6 rounded-full border border-gray-300" style="background-color: #ff5a36;" title="辅助色"></span>
                        <span class="w-6 h-6 rounded-full border border-gray-300" style="background-color: #2ecc71;" title="成功色"></span>
                        <span class="w-6 h-6 rounded-full border border-gray-300" style="background-color: #ffffff;" title="面板色"></span>
                        <span class="w-6 h-6 rounded-full border border-gray-300" style="background-color: #000000;" title="边线色"></span>
                    </div>
                </label>

                <label class="flex items-center p-4 border rounded-lg cursor-pointer transition-colors
                    {{ $activeTheme === 'dark' ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200 hover:border-gray-300' }}">
                    <input type="radio"
                           name="active_theme"
                           value="dark"
                           class="w-4 h-4 text-indigo-600 border-gray-300 focus:ring-indigo-500"
                           {{ $activeTheme === 'dark' ? 'checked' : '' }}>
                    <div class="ml-3 flex-1">
                        <span class="block text-sm font-medium text-gray-900">Brutal Night</span>
                        <span class="block text-sm text-gray-500">保留同一套固定布局，切换为深色工业面板，适合夜间浏览。</span>
                    </div>
                    <div class="flex gap-1.5 ml-4">
                        <span class="w-6 h-6 rounded-full border border-gray-300" style="background-color: #ffd84d;" title="强调色"></span>
                        <span class="w-6 h-6 rounded-full border border-gray-300" style="background-color: #ff7a59;" title="辅助色"></span>
                        <span class="w-6 h-6 rounded-full border border-gray-300" style="background-color: #39d98a;" title="成功色"></span>
                        <span class="w-6 h-6 rounded-full border border-gray-300" style="background-color: #161616;" title="面板色"></span>
                        <span class="w-6 h-6 rounded-full border border-gray-300" style="background-color: #f3f3f3;" title="边线色"></span>
                    </div>
                </label>
            </div>

            <div class="bg-gray-50 rounded-md p-4 mb-6">
                <h3 class="text-sm font-medium text-gray-700 mb-2">主题说明</h3>
                <div class="text-sm text-gray-600 space-y-1">
                    <p>当前前台布局固定在 Blade 页面和共享 partial 中，主题插件只负责注入视觉层样式。</p>
                    <p>样式通过 Blade 视图注入到 <code>&lt;head&gt;</code>，不再依赖 public 静态 CSS 文件。</p>
                    <p>切换后只影响前端用户页面，不影响后台管理界面。</p>
                </div>
            </div>

            <button type="submit"
                    class="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors">
                保存设置
            </button>
        </form>
    </div>
</div>
@endsection
