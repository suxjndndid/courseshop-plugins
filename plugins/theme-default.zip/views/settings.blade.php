{{-- 主题插件后台设置页面 --}}
{{-- @extends 继承后台管理布局，提供侧边栏、顶栏等公共 UI --}}
@extends('admin.layouts.app')

@section('title', '主题设置 - 默认主题')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 class="text-xl font-semibold mb-4 flex items-center">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"/>
            </svg>
            主题设置
        </h2>

        {{-- 成功提示 --}}
        @if(session('success'))
        <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded mb-4">
            {{ session('success') }}
        </div>
        @endif

        {{-- 错误提示 --}}
        @if($errors->any())
        <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
            @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach
        </div>
        @endif

        <form action="{{ route('admin.plugin.theme-default.save') }}" method="POST">
            @csrf

            {{-- 主题选择 --}}
            <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-3">选择主题</label>

                {{-- 默认主题单选按钮 --}}
                <label class="flex items-center p-4 border rounded-lg mb-3 cursor-pointer transition-colors
                    {{ $activeTheme === 'default' ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200 hover:border-gray-300' }}">
                    <input type="radio"
                           name="active_theme"
                           value="default"
                           class="w-4 h-4 text-indigo-600 border-gray-300 focus:ring-indigo-500"
                           {{ $activeTheme === 'default' ? 'checked' : '' }}>
                    <div class="ml-3 flex-1">
                        <span class="block text-sm font-medium text-gray-900">默认主题</span>
                        <span class="block text-sm text-gray-500">柔和蓝紫色调，浅色背景，适合日常使用</span>
                    </div>
                    {{-- 默认主题色彩预览 --}}
                    <div class="flex gap-1.5 ml-4">
                        <span class="w-6 h-6 rounded-full" style="background-color: #667eea;" title="主色调"></span>
                        <span class="w-6 h-6 rounded-full" style="background-color: #f093fb;" title="辅助色"></span>
                        <span class="w-6 h-6 rounded-full" style="background-color: #4ecdc4;" title="成功色"></span>
                        <span class="w-6 h-6 rounded-full" style="background-color: #ff6b6b;" title="危险色"></span>
                        <span class="w-6 h-6 rounded-full border border-gray-200" style="background-color: #f8f9fa;" title="背景色"></span>
                    </div>
                </label>

                {{-- 暗色主题单选按钮 --}}
                <label class="flex items-center p-4 border rounded-lg cursor-pointer transition-colors
                    {{ $activeTheme === 'dark' ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200 hover:border-gray-300' }}">
                    <input type="radio"
                           name="active_theme"
                           value="dark"
                           class="w-4 h-4 text-indigo-600 border-gray-300 focus:ring-indigo-500"
                           {{ $activeTheme === 'dark' ? 'checked' : '' }}>
                    <div class="ml-3 flex-1">
                        <span class="block text-sm font-medium text-gray-900">暗色主题</span>
                        <span class="block text-sm text-gray-500">深色背景，柔和高亮色调，减轻视觉疲劳</span>
                    </div>
                    {{-- 暗色主题色彩预览 --}}
                    <div class="flex gap-1.5 ml-4">
                        <span class="w-6 h-6 rounded-full" style="background-color: #7c8cf5;" title="主色调"></span>
                        <span class="w-6 h-6 rounded-full" style="background-color: #c77dff;" title="辅助色"></span>
                        <span class="w-6 h-6 rounded-full" style="background-color: #38d9a9;" title="成功色"></span>
                        <span class="w-6 h-6 rounded-full" style="background-color: #ff6b6b;" title="危险色"></span>
                        <span class="w-6 h-6 rounded-full" style="background-color: #0f0f23;" title="背景色"></span>
                    </div>
                </label>
            </div>

            {{-- 主题说明 --}}
            <div class="bg-gray-50 rounded-md p-4 mb-6">
                <h3 class="text-sm font-medium text-gray-700 mb-2">主题说明</h3>
                <div class="text-sm text-gray-600 space-y-1">
                    <p>主题通过覆盖 CSS 变量实现，仅影响前端页面样式，不影响后台管理界面。</p>
                    <p>切换主题后立即生效，无需清除缓存。</p>
                </div>
            </div>

            <button type="submit"
                    class="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors">
                保存设置
            </button>
        </form>
    </div>
</div>
@endsection
