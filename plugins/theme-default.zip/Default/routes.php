<?php

/**
 * 默认主题插件路由定义
 *
 * 由 DefaultThemePlugin::register() 中 require 加载。
 */

use Illuminate\Support\Facades\Route;

Route::prefix('admin')
    ->middleware('admin.auth')
    ->group(function () {
        Route::get('/plugin/theme-default', [\ThemeDefault\Controllers\SettingsController::class, 'index'])
            ->name('admin.plugin.theme-default');

        Route::post('/plugin/theme-default', [\ThemeDefault\Controllers\SettingsController::class, 'save'])
            ->name('admin.plugin.theme-default.save');
    });
