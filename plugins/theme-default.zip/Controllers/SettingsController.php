<?php

namespace ThemeDefault\Controllers;

use App\Models\Setting;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;

/**
 * 主题设置控制器
 */
class SettingsController
{
    public function index()
    {
        $activeTheme = plugin_context('theme-default')->config('active_theme', 'default');
        return view('theme-default::settings', ['activeTheme' => $activeTheme]);
    }

    public function save(Request $request)
    {
        $request->validate([
            'active_theme' => 'required|in:default,dark',
        ]);

        Setting::setGroup('theme-default', [
            'active_theme' => $request->input('active_theme'),
        ]);

        app(ActivityLogService::class)->log('setting', '更新主题设置');

        return redirect()->route('admin.plugin.theme-default')
            ->with('success', '主题设置已保存');
    }
}
