<?php

use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Core\Admin\AdminMenu;
use App\Core\Hook\Hook;

/**
 * 默认主题插件
 *
 * 实现 PluginInterface 接口（插件契约），提供前端主题切换功能。
 *
 * 接口实现说明：
 * - PluginInterface 是框架定义的插件契约（contract），所有插件必须实现它
 * - 框架通过接口方法与插件交互，不依赖具体实现类
 * - 此插件不使用命名空间（namespace），因为框架通过 plugin.json 的 entry 字段
 *   直接 require 插件文件并实例化类
 *
 * 主题机制说明：
 * - 框架在 resources/views/css/theme.blade.php 中定义了 CSS 变量（:root）
 * - 前端布局 frontend.blade.php 通过 Hook::filter('frontend.head', '') 留出注入点
 * - 主题插件在 boot() 中注册 frontend.head 过滤器（Filter Hook）
 * - 过滤器根据当前主题设置，将对应的 CSS 变量覆盖以 <style> 标签注入 <head>
 * - 由于 CSS 变量的层叠特性，后注入的样式会覆盖框架默认值
 */
class DefaultThemePlugin implements PluginInterface
{
    public function id(): string
    {
        return 'theme-default';
    }

    public function name(): string
    {
        return '默认主题';
    }

    public function version(): string
    {
        return '1.0.0';
    }

    /**
     * 返回插件类型
     *
     * PluginType 是 PHP 8.1 的 Backed Enum（带值枚举），
     * PluginType::Theme 对应字符串值 'theme'，表示这是一个主题插件。
     */
    public function type(): PluginType
    {
        return PluginType::Theme;
    }

    /**
     * 注册阶段：注册视图命名空间、后台菜单、管理路由
     *
     * 在框架加载所有插件后依次调用 register()。此方法中：
     * 1. 注册 Blade 视图命名空间，让 view('theme-default::settings') 能找到插件视图
     * 2. 注册后台管理路由（GET 显示设置页，POST 保存设置）
     * 3. 注册后台侧边栏菜单项
     */
    public function register(): void
    {
        $pluginPath = dirname(__FILE__);

        // 加载 Controller
        require_once $pluginPath . '/Controllers/SettingsController.php';

        // 注册视图命名空间
        app('view')->addNamespace('theme-default', $pluginPath . '/views');

        // 加载路由文件（Controller 类路由，无闭包）
        require $pluginPath . '/routes.php';

        // 注册后台菜单
        AdminMenu::add([
            'group' => \App\Core\Admin\AdminMenu::GROUP_THEME,
            'items' => [
                [
                    'label' => '主题设置',
                    'icon' => 'palette',
                    'route' => 'admin.plugin.theme-default',
                    'order' => 90,
                ],
            ],
        ]);
    }

    /**
     * 启动阶段：注册 frontend.head 过滤器 Hook
     *
     * Hook 机制说明（类似 WordPress Filter）：
     * - Hook::addFilter() 注册一个过滤器回调
     * - 前端布局在 <head> 中调用 Hook::filter('frontend.head', '')
     * - 框架将空字符串 '' 依次传入所有注册的回调
     * - 每个回调接收 $html 参数，追加内容后返回
     * - 最终结果通过 {!! !!} 输出到 HTML 中
     *
     * 此插件的 Filter 回调根据当前主题设置，读取对应的 CSS 文件内容，
     * 包裹在 <style> 标签中追加到 $html。使用内联 <style> 而非 <link> 引用，
     * 因为 CSS 文件较小，内联避免了额外的 HTTP 请求。
     */
    public function boot(): void
    {
        // 注册 frontend.head 过滤器，优先级 10（默认值）
        // 回调函数签名：function(string $html): string
        // $html 是前面其他过滤器累积的内容，必须追加而非替换
        Hook::addFilter('frontend.head', function (string $html): string {
            // 读取当前激活的主题
            $activeTheme = plugin_context('theme-default')->config('active_theme', 'default');
            $pluginPath = dirname(__FILE__);

            // 根据主题选择对应的 CSS 文件
            if ($activeTheme === 'dark') {
                $cssFile = $pluginPath . '/assets/theme-dark.css';
            } else {
                $cssFile = $pluginPath . '/assets/theme-default.css';
            }

            // 读取 CSS 文件内容，包裹在 <style> 标签中注入
            if (file_exists($cssFile)) {
                $css = file_get_contents($cssFile);
                $html .= "\n<!-- 主题插件：{$activeTheme} -->\n<style>\n{$css}\n</style>\n";
            }

            return $html;
        }, 10);
    }

    /**
     * 卸载阶段：清理后台菜单注册
     *
     * AdminMenu::remove() 按路由名称移除对应的菜单项。
     * 数据库中的 settings 记录由框架的 PluginManager 统一清理。
     */
    public function uninstall(): void
    {
        AdminMenu::remove('admin.plugin.theme-default');
    }

    /**
     * 插件默认配置
     *
     * plugin_config() 三层合并的最低优先级。
     * active_theme 可选值：'default'（默认主题）或 'dark'（暗色主题）。
     */
    public function config(): array
    {
        return [
            'active_theme' => 'default',
        ];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }
}
