<?php

use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Core\Admin\AdminMenu;
use App\Core\Contracts\FrontendThemeInterface;
use App\Core\Hook\Hook;
use App\Services\FrontendThemeService;

/**
 * 默认主题插件
 *
 * 实现 PluginInterface 接口（插件契约），提供前端主题切换功能。
 *
 * 接口实现说明：
 * - PluginInterface 是框架定义的插件契约（contract），所有插件必须实现它
 * - 框架通过接口方法与插件交互，不依赖具体实现类
 * - 此插件不使用命名空间（namespace），因为框架通过 plugin.json 的 entry 字段
 *   直接 require 插件文件并实例化类
 *
 * 主题机制说明：
 * - 框架在 resources/views/css/theme.blade.php 中只保留最小 token 与结构基线
 * - 真正的前台视觉层由主题插件通过 frontend.head Hook 注入
 * - 主题样式使用 Blade 视图渲染，而不是仅仅读取 public 静态 CSS
 * - 这样主题可以覆盖共享布局、页面组件以及未来的主题变量，不再局限于 public 文件
 */
class DefaultThemePlugin implements PluginInterface, FrontendThemeInterface
{
    public function id(): string
    {
        return 'theme-default';
    }

    public function name(): string
    {
        return '粗野主题';
    }

    public function version(): string
    {
        return '1.0.0';
    }

    /**
     * 返回插件类型
     *
     * PluginType 是 PHP 8.1 的 Backed Enum（带值枚举），
     * PluginType::Theme 对应字符串值 'theme'，表示这是一个主题插件。
     */
    public function type(): PluginType
    {
        return PluginType::Theme;
    }

    /**
     * 注册阶段：注册视图命名空间、后台菜单、管理路由
     *
     * 在框架加载所有插件后依次调用 register()。此方法中：
     * 1. 注册 Blade 视图命名空间，让 view('theme-default::settings') 能找到插件视图
     * 2. 注册后台管理路由（GET 显示设置页，POST 保存设置）
     * 3. 注册后台侧边栏菜单项
     */
    public function register(): void
    {
        $pluginPath = dirname(__FILE__);

        // 加载 Controller
        require_once $pluginPath . '/Controllers/SettingsController.php';

        // 注册视图命名空间
        app('view')->addNamespace('theme-default', $pluginPath . '/views');

        // 加载路由文件（Controller 类路由，无闭包）
        require $pluginPath . '/routes.php';

        // 注册后台菜单
        AdminMenu::add([
            'group' => \App\Core\Admin\AdminMenu::GROUP_THEME,
            'items' => [
                [
                    'label' => '主题设置',
                    'icon' => 'palette',
                    'route' => 'admin.plugin.theme-default',
                    'order' => 90,
                ],
            ],
        ]);
    }

    /**
     * 启动阶段：注册 frontend.head 过滤器 Hook
     *
     * Hook 机制说明（类似 WordPress Filter）：
     * - Hook::addFilter() 注册一个过滤器回调
     * - 前端布局在 <head> 中调用 Hook::filter('frontend.head', '')
     * - 框架将空字符串 '' 依次传入所有注册的回调
     * - 每个回调接收 $html 参数，追加内容后返回
     * - 最终结果通过 {!! !!} 输出到 HTML 中
     *
     * 此插件的 Filter 回调根据当前主题设置渲染 Blade 样式视图。
     * Blade 方案的优势：
     * 1. 可以按主题拆分共享样式与变体样式
     * 2. 能直接承载较复杂的前台布局样式，而不是只能引用 public 静态文件
     * 3. 未来若增加主题元数据、用户侧切换或局部组件覆盖，扩展空间更大
     */
    public function boot(): void
    {
        Hook::addFilter('frontend.head', function (string $html): string {
            if (!app(FrontendThemeService::class)->isActiveTheme($this->id())) {
                return $html;
            }

            $activeTheme = plugin_context($this->id())->config('active_theme', 'default');
            $styleViews = [
                'theme-default::styles.shared',
                'theme-default::styles.' . $activeTheme,
            ];

            foreach ($styleViews as $viewName) {
                if (!app('view')->exists($viewName)) {
                    continue;
                }

                $html .= "\n" . view($viewName, [
                    'activeTheme' => $activeTheme,
                ])->render() . "\n";
            }

            return $html;
        }, 10);
    }

    /**
     * 卸载阶段：清理后台菜单注册
     *
     * AdminMenu::remove() 按路由名称移除对应的菜单项。
     * 数据库中的 settings 记录由框架的 PluginManager 统一清理。
     */
    public function uninstall(): void
    {
        AdminMenu::remove('admin.plugin.theme-default');
    }

    /**
     * 插件默认配置
     *
     * plugin_config() 三层合并的最低优先级。
     * active_theme 当前提供两个 brutal 变体：
     * - default：Brutal Classic（浅底黄强调）
     * - dark：Brutal Night（深色工业面板）
     */
    public function config(): array
    {
        return [
            'active_theme' => 'default',
        ];
    }

    public function frontendThemeLabel(): string
    {
        return '粗野';
    }

    public function frontendThemeDescription(): string
    {
        return '高对比和粗边框会让页面更醒目，第一眼就很有态度。';
    }

    public function frontendThemeOrder(): int
    {
        return 10;
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }
}
