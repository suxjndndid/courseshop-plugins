@extends('admin.layouts.app')

@section('title', '飞书机器人设置')

@section('content')
<div class="container mx-auto px-4 py-6">
    <div class="bg-white shadow-md rounded-lg p-6">
        <h2 class="text-2xl font-bold mb-6">飞书机器人设置</h2>

        <form action="{{ route('admin.plugin.notification-feishu.save') }}" method="POST">
            @csrf
            
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="FSKEY">
                    Webhook Key
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="FSKEY" name="FSKEY" type="text" value="{{ $settings['FSKEY'] ?? '' }}" required>
                <p class="text-xs text-gray-500 mt-1">飞书机器人 Webhook 地址最后的 ID 部分</p>
            </div>

            <div class="mb-6 rounded-md border border-blue-100 bg-blue-50 p-4 text-sm text-blue-800">
                分发规则已统一迁移到后台“系统 → 通知分发”，这里仅维护飞书机器人的发送参数。
            </div>

            <div class="flex items-center justify-between">
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="submit">
                    保存设置
                </button>
            </div>
        </form>
    </div>
</div>
@endsection
