<?php

namespace NotificationFeishu\Controllers;

use App\Models\Setting;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;

class SettingsController
{
    public function index()
    {
        $settings = Setting::getGroup('notification-feishu');
        return view('notification-feishu::settings', ['settings' => $settings]);
    }

    public function save(Request $request)
    {
        $request->validate([
            'FSKEY' => 'required|string',
        ]);
        
        Setting::setGroup('notification-feishu', [
            'FSKEY' => $request->input('FSKEY'),
        ]);
        Setting::where('setting_group', 'notification-feishu')
            ->whereIn('key', ['enabled_events', 'route_use_legacy_supports'])
            ->delete();

        app(ActivityLogService::class)->log('setting', '更新飞书机器人配置');

        return redirect()->route('admin.plugin.notification-feishu')->with('success', '飞书机器人配置已保存');
    }
}
