<?php

use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Core\Contracts\NotificationChannelInterface;
use App\Core\Notification\Notification;
use App\Core\Admin\AdminMenu;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Http;

class FeishuPlugin implements PluginInterface, NotificationChannelInterface
{
    public function id(): string { return 'notification-feishu'; }
    public function name(): string { return '飞书机器人'; }
    public function version(): string { return '1.0.0'; }
    public function type(): PluginType { return PluginType::Notification; }

    public function register(): void
    {
        $pluginPath = dirname(__FILE__);
        require_once $pluginPath . '/Controllers/SettingsController.php';
        app('view')->addNamespace('notification-feishu', $pluginPath . '/views');
        AdminMenu::add([
            'group' => AdminMenu::GROUP_NOTIFICATION,
            'items' => [
                ['label' => '飞书机器人', 'icon' => 'send', 'route' => 'admin.plugin.notification-feishu', 'order' => 55],
            ],
        ]);
        require $pluginPath . '/routes.php';
    }

    public function boot(): void
    {
        // 由 NotificationDispatcher 统一分发，不再自行监听事件
    }

    public function uninstall(): void
    {
        AdminMenu::remove('admin.plugin.notification-feishu');
    }

    public function config(): array
    {
        return [
            'webhook_key' => '',
        ];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }

    // ==================== NotificationChannelInterface ====================

    public function send(Notification $notification): bool
    {
        try {
            $ctx = plugin_context($this->id());
            $key = $ctx->config('webhook_key');

            if (empty($key)) {
                return false;
            }

            $url = "https://open.feishu.cn/open-apis/bot/v2/hook/{$key}";

            $response = Http::post($url, [
                'msg_type' => 'text',
                'content' => [
                    'text' => $notification->subject . "\n\n" . $notification->body
                ]
            ]);

            return $response->successful() && ($response->json('code') === 0 || $response->json('StatusCode') === 0);
        } catch (\Throwable $e) {
            plugin_context($this->id())->logger()->error('飞书推送异常', ['error' => $e->getMessage()]);
            return false;
        }
    }

    public function supports(string $eventType): bool
    {
        return true;
    }

}
er, string $type, string $summary): void
    {
        $this->send(new Notification(
            type: $type,
            subject: "[{$order->order_no}] {$summary}",
            body: "商品: {$order->product_name}\n金额: {$order->final_amount}\n时间: " . now()->format('Y-m-d H:i:s'),
            data: ['order_no' => $order->order_no, 'product_name' => $order->product_name, 'amount' => $order->final_amount]
        ));
    }
}
