<?php

use NotificationFeishu\Controllers\SettingsController;
use Illuminate\Support\Facades\Route;

admin_route_group(function () {
    Route::get('/plugin/notification-feishu', [SettingsController::class, 'index'])
        ->name('admin.plugin.notification-feishu');
    Route::post('/plugin/notification-feishu', [SettingsController::class, 'save'])
        ->name('admin.plugin.notification-feishu.save');
});
