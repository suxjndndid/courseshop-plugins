<?php

use Illuminate\Support\Facades\Route;

Route::prefix('admin')->middleware('admin.auth')->group(function () {
    Route::get('/plugin/notification-feishu', [\NotificationFeishu\Controllers\SettingsController::class, 'index'])
        ->name('admin.plugin.notification-feishu');
    Route::post('/plugin/notification-feishu', [\NotificationFeishu\Controllers\SettingsController::class, 'save'])
        ->name('admin.plugin.notification-feishu.save');
});
