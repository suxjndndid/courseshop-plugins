<?php

use Illuminate\Support\Facades\Mail;

/**
 * 邮件插件配置解析器
 *
 * 只在插件内部统一“数据库优先 + Laravel mail 配置兜底”的解析逻辑，
 * 不修改框架 mail 驱动，也不改变现有 MAIL_* 的兼容语义。
 */
class EmailPluginMailConfig
{
    public const SETTING_GROUP = 'notification-email';

    /**
     * 插件默认配置（plugin_config() 的最低优先级）。
     *
     * 对 mail_* 保持空字符串，避免覆盖现有 MAIL_* 环境变量语义。
     *
     * @return array<string, string>
     */
    public static function defaultConfig(): array
    {
        return [
            'admin_email' => '',
            'mail_mailer' => '',
            'mail_host' => '',
            'mail_port' => '',
            'mail_username' => '',
            'mail_password' => '',
            'mail_encryption' => '',
            'mail_from_address' => '',
            'mail_from_name' => '',
        ];
    }

    /**
     * 后台保存时使用的校验规则。
     *
     * @return array<string, string>
     */
    public static function validationRules(): array
    {
        return [
            'admin_email' => 'required|email|max:255',
            'mail_mailer' => 'nullable|string|in:smtp,sendmail,log,array,ses,postmark,resend,failover,roundrobin',
            'mail_host' => 'nullable|string|max:255',
            'mail_port' => 'nullable|integer|min:1|max:65535',
            'mail_username' => 'nullable|string|max:255',
            'mail_password' => 'nullable|string|max:255',
            'clear_mail_password' => 'nullable|boolean',
            'mail_encryption' => 'nullable|string|in:ssl,tls,none',
            'mail_from_address' => 'nullable|email|max:255',
            'mail_from_name' => 'nullable|string|max:255',
        ];
    }

    /**
     * @param array<string, mixed> $validated
     * @param array<string, mixed> $existing
     * @return array<string, string>
     */
    public static function buildSavePayload(
        array $validated,
        array $existing,
        ?string $submittedPassword,
        bool $clearPassword
    ): array {
        $payload = [
            'admin_email' => trim((string) ($validated['admin_email'] ?? '')),
            'mail_mailer' => trim((string) ($validated['mail_mailer'] ?? '')),
            'mail_host' => trim((string) ($validated['mail_host'] ?? '')),
            'mail_port' => isset($validated['mail_port']) ? (string) $validated['mail_port'] : '',
            'mail_username' => trim((string) ($validated['mail_username'] ?? '')),
            'mail_encryption' => trim((string) ($validated['mail_encryption'] ?? '')),
            'mail_from_address' => trim((string) ($validated['mail_from_address'] ?? '')),
            'mail_from_name' => trim((string) ($validated['mail_from_name'] ?? '')),
        ];

        if ($submittedPassword !== null && $submittedPassword !== '') {
            $payload['mail_password'] = $submittedPassword;
        } elseif (!$clearPassword && array_key_exists('mail_password', $existing)) {
            $payload['mail_password'] = (string) $existing['mail_password'];
        }

        return $payload;
    }

    /**
     * @param array<string, mixed> $settings
     * @return array<string, string>
     */
    public static function buildDisplaySettings(array $settings): array
    {
        $stored = self::normalizeStoredSettings($settings);

        return array_merge($stored, [
            'admin_email' => self::firstNonEmptyString(
                $stored['admin_email'],
                plugin_config(self::SETTING_GROUP, 'admin_email', '')
            ) ?? '',
            'mail_mailer' => self::firstNonEmptyString($stored['mail_mailer'], config('mail.default', 'smtp')) ?? 'smtp',
            'mail_host' => self::firstNonEmptyString($stored['mail_host'], config('mail.mailers.smtp.host', '')) ?? '',
            'mail_port' => self::firstNonEmptyString($stored['mail_port'], config('mail.mailers.smtp.port', '')) ?? '',
            'mail_username' => self::firstNonEmptyString($stored['mail_username'], config('mail.mailers.smtp.username', '')) ?? '',
            'mail_from_address' => self::firstNonEmptyString($stored['mail_from_address'], config('mail.from.address', '')) ?? '',
            'mail_from_name' => self::firstNonEmptyString($stored['mail_from_name'], config('mail.from.name', '')) ?? '',
            'mail_encryption' => self::firstNonEmptyString($stored['mail_encryption'])
                ?? self::resolveEncryptionFromScheme((string) config('mail.mailers.smtp.scheme', '')),
        ]);
    }

    /**
     * @param array<string, mixed> $settings
     */
    public static function hasDatabaseMailConfig(array $settings): bool
    {
        $stored = self::normalizeStoredSettings($settings);

        foreach (self::mailSettingKeys() as $key) {
            if (self::hasStoredValue($key, $stored[$key] ?? null)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<string, mixed> $settings
     */
    public static function applyRuntimeConfig(array $settings): void
    {
        config(self::resolveRuntimeConfig($settings));

        // MailManager 会缓存 mailer 实例，配置变化后需要清理缓存。
        Mail::forgetMailers();
    }

    /**
     * @param array<string, mixed> $settings
     * @return array<string, mixed>
     */
    private static function resolveRuntimeConfig(array $settings): array
    {
        $stored = self::normalizeStoredSettings($settings);
        $smtpDefaults = config('mail.mailers.smtp', []);
        if (!is_array($smtpDefaults)) {
            $smtpDefaults = [];
        }

        $mailer = self::firstNonEmptyString(
            $stored['mail_mailer'],
            config('mail.default', 'log')
        ) ?? 'log';

        $host = self::firstNonEmptyString(
            $stored['mail_host'],
            $smtpDefaults['host'] ?? null
        );

        $portRaw = self::firstNonEmptyString(
            $stored['mail_port'],
            $smtpDefaults['port'] ?? null
        );
        $port = is_numeric((string) $portRaw) ? (int) $portRaw : null;

        $username = self::firstNonEmptyString(
            $stored['mail_username'],
            $smtpDefaults['username'] ?? null
        );

        $password = self::hasStoredValue('mail_password', $stored['mail_password'])
            ? (string) $stored['mail_password']
            : (string) ($smtpDefaults['password'] ?? '');

        $scheme = self::resolveMailScheme(
            $stored['mail_encryption'],
            $smtpDefaults['scheme'] ?? null
        );

        $fromAddress = self::firstNonEmptyString(
            $stored['mail_from_address'],
            config('mail.from.address')
        );

        $fromName = self::firstNonEmptyString(
            $stored['mail_from_name'],
            config('mail.from.name')
        );

        $smtpConfig = $smtpDefaults;
        $smtpConfig['transport'] = $smtpConfig['transport'] ?? 'smtp';

        if ($host !== null) {
            $smtpConfig['host'] = $host;
        }
        if ($port !== null) {
            $smtpConfig['port'] = $port;
        }
        if ($username !== null) {
            $smtpConfig['username'] = $username;
        }
        if ($password !== '') {
            $smtpConfig['password'] = $password;
        }
        $smtpConfig['scheme'] = $scheme;

        $runtimeConfig = [
            'mail.default' => $mailer,
            'mail.mailers.smtp' => $smtpConfig,
        ];

        if ($fromAddress !== null) {
            $runtimeConfig['mail.from.address'] = $fromAddress;
        }
        if ($fromName !== null) {
            $runtimeConfig['mail.from.name'] = $fromName;
        }

        return $runtimeConfig;
    }

    /**
     * @param array<string, mixed> $settings
     * @return array<string, string>
     */
    private static function normalizeStoredSettings(array $settings): array
    {
        $normalized = self::defaultConfig();

        foreach ($normalized as $key => $default) {
            if (!array_key_exists($key, $settings)) {
                continue;
            }

            $value = $settings[$key];
            $normalized[$key] = $key === 'mail_password'
                ? (string) $value
                : trim((string) $value);
        }

        return $normalized;
    }

    /**
     * @return array<int, string>
     */
    private static function mailSettingKeys(): array
    {
        return [
            'mail_mailer',
            'mail_host',
            'mail_port',
            'mail_username',
            'mail_password',
            'mail_encryption',
            'mail_from_address',
            'mail_from_name',
        ];
    }

    private static function hasStoredValue(string $key, mixed $value): bool
    {
        if ($value === null) {
            return false;
        }

        if ($key === 'mail_password') {
            return (string) $value !== '';
        }

        return trim((string) $value) !== '';
    }

    private static function resolveMailScheme(mixed $encryption, mixed $defaultScheme = null): ?string
    {
        $value = strtolower(trim((string) $encryption));

        return match ($value) {
            'ssl', 'smtps' => 'smtps',
            'tls', 'smtp' => 'smtp',
            'none', 'null' => null,
            default => self::firstNonEmptyString($defaultScheme),
        };
    }

    private static function resolveEncryptionFromScheme(string $scheme): string
    {
        return match (strtolower(trim($scheme))) {
            'smtps', 'ssl' => 'ssl',
            'tls' => 'tls',
            default => '',
        };
    }

    private static function firstNonEmptyString(mixed ...$candidates): ?string
    {
        foreach ($candidates as $candidate) {
            if ($candidate === null) {
                continue;
            }

            $value = trim((string) $candidate);
            if ($value !== '') {
                return $value;
            }
        }

        return null;
    }
}
