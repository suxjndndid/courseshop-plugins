<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>订单异常通知</title>
</head>
<body style="font-family: 'Microsoft YaHei', Arial, sans-serif; line-height: 1.6; color: #333; background-color: #f4f4f4; margin: 0; padding: 20px;">
    <div style="max-width: 600px; margin: 0 auto; background: #fff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); overflow: hidden;">

        {{-- 红色警告头部 --}}
        <div style="background: linear-gradient(135deg, #ff6b6b, #ee5a24); color: white; padding: 30px; text-align: center;">
            <h1 style="margin: 0; font-size: 24px;">&#9888;&#65039; 订单异常通知</h1>
        </div>

        <div style="padding: 30px;">
            {{-- 警告提示条 --}}
            <div style="background: #fff5f5; border-left: 4px solid #ff6b6b; padding: 15px; margin: 0 0 20px 0; border-radius: 4px;">
                <strong>注意：</strong>系统检测到订单异常，请及时处理！
            </div>

            {{-- 订单信息表格 --}}
            <h3 style="margin: 0 0 10px 0; font-size: 16px; color: #333;">订单信息</h3>
            <table style="width: 100%; border-collapse: collapse; margin: 0 0 20px 0;">
                <tr>
                    <th style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold; width: 30%;">订单号</th>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">{{ $orderNo }}</td>
                </tr>
                <tr>
                    <th style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold; width: 30%;">商品名称</th>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">{{ $productName }}</td>
                </tr>
                <tr>
                    <th style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold; width: 30%;">订单金额</th>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">&yen;{{ $amount }}</td>
                </tr>
                <tr>
                    <th style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold; width: 30%;">异常时间</th>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">{{ $failedAt }}</td>
                </tr>
            </table>

            {{-- 错误原因（有内容时才显示） --}}
            @if(!empty($reason))
            <h3 style="margin: 0 0 10px 0; font-size: 16px; color: #333;">错误详情</h3>
            <div style="background: #f8f9fa; padding: 15px; border-radius: 4px; margin: 0 0 20px 0; font-family: monospace; font-size: 14px; white-space: pre-wrap; word-break: break-all;">{{ $reason }}</div>
            @endif
        </div>

        {{-- 页脚 --}}
        <div style="background: #f8f9fa; padding: 20px; text-align: center; color: #666; font-size: 14px;">
            <p style="margin: 0 0 5px 0;">此邮件由系统自动发送，请勿回复</p>
            <p style="margin: 0;">发送时间：{{ date('Y-m-d H:i:s') }}</p>
        </div>
    </div>
</body>
</html>
