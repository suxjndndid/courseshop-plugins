<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>{{ $mailSubject }}</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.7; color: #111827;">
    <h2 style="margin-bottom: 12px;">{{ $mailSubject }}</h2>

    <p style="white-space: pre-line; margin-bottom: 16px;">{{ $bodyText }}</p>

    <table style="border-collapse: collapse; margin-top: 12px;">
        <tr>
            <td style="padding: 6px 12px 6px 0; color: #6b7280;">通知等级</td>
            <td style="padding: 6px 0;">{{ $level }}</td>
        </tr>
        @if($type !== '')
            <tr>
                <td style="padding: 6px 12px 6px 0; color: #6b7280;">通知类型</td>
                <td style="padding: 6px 0;">{{ $type }}</td>
            </tr>
        @endif
        @if($source !== '')
            <tr>
                <td style="padding: 6px 12px 6px 0; color: #6b7280;">来源</td>
                <td style="padding: 6px 0;">{{ $source }}</td>
            </tr>
        @endif
        @if(!empty($notificationTags))
            <tr>
                <td style="padding: 6px 12px 6px 0; color: #6b7280;">标签</td>
                <td style="padding: 6px 0;">{{ implode(', ', $notificationTags) }}</td>
            </tr>
        @endif
    </table>
</body>
</html>
