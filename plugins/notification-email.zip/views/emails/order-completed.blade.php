<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>课程学习完成通知</title>
</head>
<body style="font-family: 'Microsoft YaHei', Arial, sans-serif; line-height: 1.6; color: #333; background-color: #f4f4f4; margin: 0; padding: 20px;">
    <div style="max-width: 600px; margin: 0 auto; background: #fff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); overflow: hidden;">

        {{-- 绿色成功头部 --}}
        <div style="background: linear-gradient(135deg, #51cf66, #2b8a3e); color: white; padding: 30px; text-align: center;">
            <h1 style="margin: 0; font-size: 24px;">&#10004;&#65039; 课程学习完成</h1>
        </div>

        <div style="padding: 30px;">
            {{-- 成功提示条 --}}
            <div style="background: #f0fff4; border-left: 4px solid #51cf66; padding: 15px; margin: 0 0 20px 0; border-radius: 4px;">
                <strong>好消息！</strong>您的课程学习订单已全部完成。
            </div>

            {{-- 订单信息表格 --}}
            <h3 style="margin: 0 0 10px 0; font-size: 16px; color: #333;">订单信息</h3>
            <table style="width: 100%; border-collapse: collapse; margin: 0 0 20px 0;">
                <tr>
                    <th style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold; width: 30%;">订单号</th>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">{{ $orderNo }}</td>
                </tr>
                <tr>
                    <th style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold; width: 30%;">商品名称</th>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">{{ $productName }}</td>
                </tr>
                <tr>
                    <th style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold; width: 30%;">订单金额</th>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">&yen;{{ $amount }}</td>
                </tr>
                <tr>
                    <th style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold; width: 30%;">完成时间</th>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">{{ $completedAt }}</td>
                </tr>
            </table>

            {{-- 课程列表 --}}
            @if(!empty($courseList))
            <h3 style="margin: 0 0 10px 0; font-size: 16px; color: #333;">已完成课程</h3>
            <ul style="background: #f8f9fa; padding: 15px 15px 15px 35px; border-radius: 4px; margin: 0 0 20px 0;">
                @foreach($courseList as $course)
                <li style="padding: 4px 0;">{{ $course }}</li>
                @endforeach
            </ul>
            @endif

            <p style="color: #666; font-size: 14px;">您可以登录学习平台确认学习记录是否已正确同步。</p>
        </div>

        {{-- 页脚 --}}
        <div style="background: #f8f9fa; padding: 20px; text-align: center; color: #666; font-size: 14px;">
            <p style="margin: 0 0 5px 0;">此邮件由系统自动发送，请勿回复</p>
            <p style="margin: 0;">发送时间：{{ date('Y-m-d H:i:s') }}</p>
        </div>
    </div>
</body>
</html>
