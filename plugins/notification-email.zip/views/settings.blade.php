{{-- 邮件通知插件后台设置页面 --}}
@extends('admin.layouts.app')

@section('title', '邮件通知设置')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 class="text-xl font-semibold mb-4 flex items-center">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
            </svg>
            邮件通知配置
        </h2>

        @if(session('success'))
        <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded mb-4">
            {{ session('success') }}
        </div>
        @endif

        @if($errors->any())
        <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
            @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach
        </div>
        @endif

        <form action="{{ route('admin.plugin.notification-email.save') }}" method="POST">
            @csrf

            {{-- 管理员邮箱 --}}
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">管理员邮箱</label>
                <input type="email"
                       name="admin_email"
                       value="{{ $settings['admin_email'] ?? '' }}"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                       placeholder="admin@example.com"
                       required>
                <p class="text-sm text-gray-500 mt-1">接收系统通知的邮箱地址。也可通过 .env 设置：NOTIFICATION_EMAIL_ADMIN_EMAIL</p>
            </div>

            <div class="mb-4 rounded-md border border-blue-200 bg-blue-50 p-4 text-sm text-blue-900">
                @if($dbMailConfigEnabled)
                    当前已启用数据库邮件配置，发送时优先使用数据库值，未填写项自动回退到 `.env` / `config/mail.php`。
                @else
                    当前未填写数据库邮件配置，发送时使用 `.env` / `config/mail.php`。
                @endif
            </div>

            {{-- 邮件驱动配置（数据库优先） --}}
            <div class="mb-6 rounded-md border border-gray-200 p-4">
                <h3 class="text-sm font-semibold text-gray-800 mb-3">邮件发送配置（数据库优先）</h3>

                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-1">MAIL_MAILER</label>
                    <select name="mail_mailer"
                            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500">
                        <option value="" {{ old('mail_mailer', $settings['mail_mailer'] ?? '') === '' ? 'selected' : '' }}>留空（跟随环境变量）</option>
                        <option value="smtp" {{ old('mail_mailer', $settings['mail_mailer'] ?? '') === 'smtp' ? 'selected' : '' }}>smtp</option>
                        <option value="sendmail" {{ old('mail_mailer', $settings['mail_mailer'] ?? '') === 'sendmail' ? 'selected' : '' }}>sendmail</option>
                        <option value="log" {{ old('mail_mailer', $settings['mail_mailer'] ?? '') === 'log' ? 'selected' : '' }}>log</option>
                        <option value="array" {{ old('mail_mailer', $settings['mail_mailer'] ?? '') === 'array' ? 'selected' : '' }}>array</option>
                        <option value="ses" {{ old('mail_mailer', $settings['mail_mailer'] ?? '') === 'ses' ? 'selected' : '' }}>ses</option>
                        <option value="postmark" {{ old('mail_mailer', $settings['mail_mailer'] ?? '') === 'postmark' ? 'selected' : '' }}>postmark</option>
                        <option value="resend" {{ old('mail_mailer', $settings['mail_mailer'] ?? '') === 'resend' ? 'selected' : '' }}>resend</option>
                        <option value="failover" {{ old('mail_mailer', $settings['mail_mailer'] ?? '') === 'failover' ? 'selected' : '' }}>failover</option>
                        <option value="roundrobin" {{ old('mail_mailer', $settings['mail_mailer'] ?? '') === 'roundrobin' ? 'selected' : '' }}>roundrobin</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-1">MAIL_HOST</label>
                    <input type="text"
                           name="mail_host"
                           value="{{ old('mail_host', $settings['mail_host'] ?? '') }}"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                           placeholder="smtp.example.com">
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-1">MAIL_PORT</label>
                    <input type="number"
                           name="mail_port"
                           value="{{ old('mail_port', $settings['mail_port'] ?? '') }}"
                           min="1"
                           max="65535"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                           placeholder="465">
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-1">MAIL_USERNAME</label>
                    <input type="text"
                           name="mail_username"
                           value="{{ old('mail_username', $settings['mail_username'] ?? '') }}"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                           placeholder="your@email.com">
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-1">MAIL_PASSWORD</label>
                    <input type="password"
                           name="mail_password"
                           value=""
                           autocomplete="new-password"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                           placeholder="{{ $hasSavedMailPassword ? '已保存，留空表示不修改' : '输入邮箱授权码或密码' }}">
                    @if($hasSavedMailPassword)
                    <label class="mt-2 inline-flex items-center text-sm text-gray-600">
                        <input type="checkbox" name="clear_mail_password" value="1" class="mr-2 rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                        清空数据库中的 MAIL_PASSWORD（改为回退 .env）
                    </label>
                    @endif
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-1">MAIL_ENCRYPTION</label>
                    <select name="mail_encryption"
                            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500">
                        <option value="" {{ old('mail_encryption', $settings['mail_encryption'] ?? '') === '' ? 'selected' : '' }}>留空（自动）</option>
                        <option value="ssl" {{ old('mail_encryption', $settings['mail_encryption'] ?? '') === 'ssl' ? 'selected' : '' }}>ssl</option>
                        <option value="tls" {{ old('mail_encryption', $settings['mail_encryption'] ?? '') === 'tls' ? 'selected' : '' }}>tls</option>
                        <option value="none" {{ old('mail_encryption', $settings['mail_encryption'] ?? '') === 'none' ? 'selected' : '' }}>none</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-1">MAIL_FROM_ADDRESS</label>
                    <input type="email"
                           name="mail_from_address"
                           value="{{ old('mail_from_address', $settings['mail_from_address'] ?? '') }}"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                           placeholder="noreply@example.com">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">MAIL_FROM_NAME</label>
                    <input type="text"
                           name="mail_from_name"
                           value="{{ old('mail_from_name', $settings['mail_from_name'] ?? '') }}"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                           placeholder="{{ config('app.name') }}">
                </div>
            </div>

            <div class="mb-6 rounded-md border border-amber-200 bg-amber-50 p-4">
                <h3 class="text-sm font-semibold text-amber-900">分发规则统一在“通知分发”页面配置</h3>
                <p class="mt-2 text-sm leading-6 text-amber-800">
                    邮件插件页面只保留发送参数。
                    是否启用渠道、受众、类型规则、标签规则，请到后台左侧“系统 → 通知分发”统一维护。
                </p>
                @if (Route::has('admin.notification-routing'))
                    <a href="{{ route('admin.notification-routing') }}"
                       class="mt-3 inline-flex items-center rounded-md border border-amber-300 px-3 py-2 text-sm text-amber-900 transition hover:bg-amber-100">
                        打开统一通知分发
                    </a>
                @endif
            </div>

            <button type="submit"
                    class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors">
                保存配置
            </button>
        </form>
    </div>
</div>
@endsection
