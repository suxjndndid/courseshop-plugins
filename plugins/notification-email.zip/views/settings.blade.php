{{-- 邮件通知插件后台设置页面 --}}
@extends('admin.layouts.app')

@section('title', '邮件通知设置')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 class="text-xl font-semibold mb-4 flex items-center">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
            </svg>
            邮件通知配置
        </h2>

        @if(session('success'))
        <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded mb-4">
            {{ session('success') }}
        </div>
        @endif

        @if($errors->any())
        <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
            @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach
        </div>
        @endif

        <form action="{{ route('admin.plugin.notification-email.save') }}" method="POST">
            @csrf

            {{-- 管理员邮箱 --}}
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">管理员邮箱</label>
                <input type="email"
                       name="admin_email"
                       value="{{ $settings['admin_email'] ?? '' }}"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                       placeholder="admin@example.com"
                       required>
                <p class="text-sm text-gray-500 mt-1">接收系统通知的邮箱地址。也可通过 .env 设置：NOTIFICATION_EMAIL_ADMIN_EMAIL</p>
            </div>

            <div class="mb-6 rounded-md border border-amber-200 bg-amber-50 p-4">
                <h3 class="text-sm font-semibold text-amber-900">分发规则统一在“通知分发”页面配置</h3>
                <p class="mt-2 text-sm leading-6 text-amber-800">
                    邮件插件页面只保留发送参数。
                    是否启用渠道、受众、类型规则、标签规则，请到后台左侧“系统 → 通知分发”统一维护。
                </p>
                @if (Route::has('admin.notification-routing'))
                    <a href="{{ route('admin.notification-routing') }}"
                       class="mt-3 inline-flex items-center rounded-md border border-amber-300 px-3 py-2 text-sm text-amber-900 transition hover:bg-amber-100">
                        打开统一通知分发
                    </a>
                @endif
            </div>

            {{-- SMTP 配置提示 --}}
            <div class="bg-gray-50 rounded-md p-4 mb-6">
                <h3 class="text-sm font-medium text-gray-700 mb-2">SMTP 邮件配置</h3>
                <p class="text-sm text-gray-600 mb-2">邮件发送依赖 Laravel 邮件驱动，请在 .env 中配置：</p>
                <div class="text-xs text-gray-500 font-mono bg-white rounded p-3 border">
                    MAIL_MAILER=smtp<br>
                    MAIL_HOST=smtp.example.com<br>
                    MAIL_PORT=465<br>
                    MAIL_USERNAME=your@email.com<br>
                    MAIL_PASSWORD=your_password<br>
                    MAIL_ENCRYPTION=ssl<br>
                    MAIL_FROM_ADDRESS=noreply@example.com<br>
                    MAIL_FROM_NAME="${APP_NAME}"
                </div>
            </div>

            <button type="submit"
                    class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors">
                保存配置
            </button>
        </form>
    </div>
</div>
@endsection
