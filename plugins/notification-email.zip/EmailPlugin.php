<?php

use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Core\Contracts\NotificationChannelInterface;
use App\Core\Notification\Notification;
use App\Core\Admin\AdminMenu;
use App\Models\Setting;
use Illuminate\Support\Facades\Mail;

/**
 * 邮件通知插件
 *
 * 同时实现两个接口：
 * - PluginInterface：插件生命周期管理
 * - NotificationChannelInterface：通知渠道（send/supports）
 *
 * 设计约束：
 * - 渠道插件只负责“怎么发”，不负责框架级路由策略
 * - 通知受众（internal/customer/broadcast）由 Notification.audience 决定
 * - 事件类型、标签分流由 NotificationDispatcher 的核心路由规则控制
 */
class EmailPlugin implements PluginInterface, NotificationChannelInterface
{
    public function id(): string { return 'notification-email'; }
    public function name(): string { return '邮件通知'; }
    public function version(): string { return '1.0.0'; }
    public function type(): PluginType { return PluginType::Notification; }

    /**
     * 注册阶段：加载依赖、注册视图/菜单/路由
     */
    public function register(): void
    {
        $pluginPath = dirname(__FILE__);

        // 加载插件依赖类
        require_once $pluginPath . '/Mail/OrderFailedMail.php';
        require_once $pluginPath . '/Mail/OrderCompletedMail.php';
        require_once $pluginPath . '/Mail/GenericNotificationMail.php';
        require_once $pluginPath . '/Controllers/SettingsController.php';

        // 注册视图命名空间
        app('view')->addNamespace('notification-email', $pluginPath . '/views');

        // 注册后台菜单
        AdminMenu::add([
            'group' => AdminMenu::GROUP_NOTIFICATION,
            'items' => [
                [
                    'label' => '邮件通知',
                    'icon'  => 'envelope',
                    'route' => 'admin.plugin.notification-email',
                    'order' => 52,
                ],
            ],
        ]);

        // 加载路由文件
        require $pluginPath . '/routes.php';
    }

    /**
     * 启动阶段
     *
     * 事件监听由 NotificationDispatcher 统一处理，插件无需自行注册。
     */
    public function boot(): void
    {
        // 由 NotificationDispatcher 统一分发，不再自行监听事件
    }

    public function uninstall(): void
    {
        AdminMenu::remove('admin.plugin.notification-email');
    }

    /**
     * 插件默认配置
     */
    public function config(): array
    {
        return [
            'admin_email'    => '',
        ];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }

    // ==================== NotificationChannelInterface ====================

    /**
     * 发送通知
     *
     * 按受众计算收件人，再按通知类型选择邮件模板。
     */
    public function send(Notification $notification): bool
    {
        try {
            $ctx = plugin_context($this->id());
            $adminEmail = trim((string) (
                $ctx->config('admin_email')
                ?: Setting::getValue('core', 'contact_email')
            ));
            $recipients = $this->resolveRecipients($notification, $adminEmail);

            if ($recipients === []) {
                $ctx->logger()->warning('无有效收件人，跳过邮件发送', [
                    'type' => $notification->type,
                    'audience' => $notification->audience,
                    'source' => $notification->source,
                ]);
                return false;
            }

            return match ($notification->type) {
                'order.failed'    => $this->sendOrderFailed($notification, $recipients),
                'order.fulfilled' => $this->sendOrderFulfilled($notification, $recipients),
                default => $this->sendGeneric($notification, $recipients),
            };
        } catch (\Throwable $e) {
            plugin_context($this->id())->logger()->error('通知发送异常', [
                'type'  => $notification->type,
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }

    public function supports(string $eventType): bool
    {
        return true;
    }

    // ==================== 私有方法：各类型邮件发送 ====================

    /**
     * 发送订单失败通知
     */
    private function sendOrderFailed(Notification $notification, array $recipients): bool
    {
        $mailable = new \OrderFailedMail(
            orderNo: $notification->data['order_no'] ?? '',
            productName: $notification->data['product_name'] ?? '',
            amount: $notification->data['amount'] ?? '0.00',
            failedAt: $notification->data['failed_at'] ?? now()->format('Y-m-d H:i:s'),
            reason: $notification->data['reason'] ?? ''
        );
        $sentCount = $this->sendMailableToRecipients($mailable, $recipients, $notification);

        plugin_context($this->id())->logger()->info('订单失败通知已发送', [
            'order_no'   => $notification->data['order_no'] ?? '',
            'recipients' => $recipients,
            'sent_count' => $sentCount,
        ]);
        return $sentCount > 0;
    }

    /**
     * 发送履约完成通知
     */
    private function sendOrderFulfilled(Notification $notification, array $recipients): bool
    {
        $orderNo = $notification->data['order_no'] ?? '';

        $mailable = new \OrderCompletedMail(
            orderNo: $orderNo,
            productName: $notification->data['product_name'] ?? '',
            amount: (string) ($notification->data['amount'] ?? '0.00'),
            completedAt: $notification->data['completed_at'] ?? now()->format('Y-m-d H:i:s'),
            courseList: $this->resolveCourseList($notification)
        );
        $sentCount = $this->sendMailableToRecipients($mailable, $recipients, $notification);

        plugin_context($this->id())->logger()->info('履约完成通知已发送', [
            'order_no'   => $orderNo,
            'recipients' => $recipients,
            'sent_count' => $sentCount,
        ]);
        return $sentCount > 0;
    }

    /**
     * 通用通知（未来扩展的事件类型走这里）
     */
    private function sendGeneric(Notification $notification, array $recipients): bool
    {
        $mailable = new \GenericNotificationMail(
            subject: $notification->subject,
            body: $notification->body,
            level: $notification->level,
            type: $notification->type,
            source: $notification->source,
            tags: Notification::normalizeStringList($notification->tags),
        );

        $sentCount = 0;
        foreach ($recipients as $email) {
            try {
                Mail::to($email)->send($mailable);
                $sentCount++;
            } catch (\Throwable $e) {
                plugin_context($this->id())->logger()->error('通用通知发送失败', [
                    'type'  => $notification->type,
                    'to'    => $email,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        plugin_context($this->id())->logger()->info('通用通知已发送', [
            'type'    => $notification->type,
            'subject' => $notification->subject,
            'recipients' => $recipients,
            'sent_count' => $sentCount,
        ]);
        return $sentCount > 0;
    }

    /**
     * @param array<int, string> $recipients
     */
    private function sendMailableToRecipients(object $mailable, array $recipients, Notification $notification): int
    {
        $sentCount = 0;
        foreach ($recipients as $email) {
            try {
                Mail::to($email)->send($mailable);
                $sentCount++;
            } catch (\Throwable $e) {
                plugin_context($this->id())->logger()->error('邮件发送失败', [
                    'type'  => $notification->type,
                    'to'    => $email,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        return $sentCount;
    }

    /**
     * 根据通知受众推导本次邮件收件人
     *
     * - internal  -> 仅管理员
     * - customer  -> 仅用户 notification_email
     * - broadcast -> 管理员 + 用户
     *
     * @return array<int, string>
     */
    private function resolveRecipients(Notification $notification, string $adminEmail): array
    {
        $customerEmail = $this->extractCustomerEmail($notification);
        $audience = strtolower(trim($notification->audience));

        $pool = match ($audience) {
            'internal' => [$adminEmail],
            'customer' => [$customerEmail],
            'broadcast' => [$adminEmail, $customerEmail],
            default => [$adminEmail, $customerEmail],
        };

        return array_values(array_filter(
            array_unique(array_map(static fn ($email) => trim((string) $email), $pool)),
            static fn (string $email) => $email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) !== false
        ));
    }

    private function extractCustomerEmail(Notification $notification): string
    {
        return trim((string) (
            $notification->data['notification_email']
                ?? $notification->data['customer_email']
                ?? $notification->data['email']
                ?? ''
        ));
    }

    /**
     * 课程列表由框架在 Notification.data 中提供，渠道插件不再跨插件查表。
     *
     * @return array<int, string>
     */
    private function resolveCourseList(Notification $notification): array
    {
        $courseList = $notification->data['course_list'] ?? [];
        if (!is_array($courseList)) {
            return [];
        }

        return Notification::normalizeStringList($courseList);
    }
}
