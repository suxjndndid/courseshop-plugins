<?php

namespace NotificationEmail\Controllers;

require_once dirname(__DIR__) . '/Support/EmailPluginMailConfig.php';

use EmailPluginMailConfig;
use App\Models\Setting;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;

/**
 * 邮件通知后台设置控制器
 */
class SettingsController
{
    public function index()
    {
        $settings = Setting::getGroup(EmailPluginMailConfig::SETTING_GROUP);
        $displaySettings = EmailPluginMailConfig::buildDisplaySettings($settings);

        return view('notification-email::settings', [
            'settings' => $displaySettings,
            'hasSavedMailPassword' => (($settings['mail_password'] ?? '') !== ''),
            'dbMailConfigEnabled' => EmailPluginMailConfig::hasDatabaseMailConfig($settings),
        ]);
    }

    public function save(Request $request)
    {
        $validated = $request->validate(EmailPluginMailConfig::validationRules());

        $existing = Setting::getGroup(EmailPluginMailConfig::SETTING_GROUP);

        $payload = EmailPluginMailConfig::buildSavePayload(
            $validated,
            $existing,
            $request->filled('mail_password') ? (string) $request->input('mail_password') : null,
            $request->boolean('clear_mail_password')
        );

        Setting::setGroup(EmailPluginMailConfig::SETTING_GROUP, $payload);

        if ($request->boolean('clear_mail_password')) {
            Setting::where('setting_group', EmailPluginMailConfig::SETTING_GROUP)
                ->where('key', 'mail_password')
                ->delete();
        }

        Setting::where('setting_group', EmailPluginMailConfig::SETTING_GROUP)
            ->whereIn('key', ['enabled_events', 'route_use_legacy_supports'])
            ->delete();

        app(ActivityLogService::class)->log('setting', '更新邮件通知配置');

        return redirect()->route('admin.plugin.notification-email')
            ->with('success', '邮件通知配置已保存');
    }
}
