<?php

namespace NotificationEmail\Controllers;

use App\Models\Setting;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;

/**
 * 邮件通知后台设置控制器
 */
class SettingsController
{
    public function index()
    {
        $settings = Setting::getGroup('notification-email');
        return view('notification-email::settings', ['settings' => $settings]);
    }

    public function save(Request $request)
    {
        $validated = $request->validate([
            'admin_email' => 'required|email|max:255',
        ]);

        Setting::setGroup('notification-email', [
            'admin_email'    => $validated['admin_email'],
        ]);

        Setting::where('setting_group', 'notification-email')
            ->whereIn('key', ['enabled_events', 'route_use_legacy_supports'])
            ->delete();

        app(ActivityLogService::class)->log('setting', '更新邮件通知配置');

        return redirect()->route('admin.plugin.notification-email')
            ->with('success', '邮件通知配置已保存');
    }
}
