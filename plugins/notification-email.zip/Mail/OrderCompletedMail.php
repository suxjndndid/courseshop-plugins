<?php

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

/**
 * 订单完成通知邮件
 *
 * 全部课程学习完成后发送给用户 notification_email。
 * 对应旧项目：WangKeLava/app/Mail/OrderCompletedNotification.php
 *
 * 无命名空间，通过 require_once 加载。
 */
class OrderCompletedMail extends Mailable
{
    use Queueable, SerializesModels;

    /** 公共属性自动传递给 Blade 视图 */
    public string $orderNo;
    public string $productName;
    public string $amount;
    public string $completedAt;
    public array $courseList;

    public function __construct(
        string $orderNo,
        string $productName,
        string $amount,
        string $completedAt,
        array $courseList = []
    ) {
        $this->orderNo = $orderNo;
        $this->productName = $productName;
        $this->amount = $amount;
        $this->completedAt = $completedAt;
        $this->courseList = $courseList;
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: '✅ 课程学习完成通知 - 订单号: ' . $this->orderNo,
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'notification-email::emails.order-completed',
        );
    }

    public function attachments(): array
    {
        return [];
    }
}
