<?php

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

/**
 * 通用通知邮件
 *
 * 当通知类型没有专门模板时，邮件渠道统一回退到这个 Mailable。
 * 这样邮件发送仍走 Laravel 标准 Mailable 流程，测试和扩展都更稳定。
 */
class GenericNotificationMail extends Mailable
{
    use Queueable, SerializesModels;

    public string $mailSubject;
    public string $bodyText;
    public string $level;
    public string $type;
    public string $source;
    public array $notificationTags;

    public function __construct(
        string $subject,
        string $body,
        string $level = 'info',
        string $type = '',
        string $source = '',
        array $tags = [],
    ) {
        $this->mailSubject = $subject;
        $this->bodyText = $body;
        $this->level = $level;
        $this->type = $type;
        $this->source = $source;
        $this->notificationTags = $tags;
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: $this->mailSubject,
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'notification-email::emails.generic-notification',
        );
    }

    public function attachments(): array
    {
        return [];
    }
}
