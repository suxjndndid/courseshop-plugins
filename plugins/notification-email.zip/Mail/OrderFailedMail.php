<?php

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

/**
 * 订单失败通知邮件
 *
 * 继承 Laravel Mailable（可邮寄类）：
 * - Mailable 是 Laravel 邮件系统的 OOP 封装
 * - envelope() 定义邮件信封（主题、发件人等）
 * - content() 定义邮件内容（视图模板、数据）
 * - 使用 Queueable trait 可将邮件推入队列异步发送
 * - 使用 SerializesModels trait 可安全序列化 Eloquent 模型
 *
 * 从旧项目 ApiOrderFailedNotification 迁移简化：
 * - 去除课程相关字段（platformName, studyUsername, courseCount, courseData）
 * - 保留通用订单字段（orderNo, productName, amount, failedAt, reason）
 *
 * 无命名空间，通过 require_once 加载。
 */
class OrderFailedMail extends Mailable
{
    /**
     * Queueable：使此 Mailable 可被推入 Laravel 队列异步处理
     * SerializesModels：自动序列化/反序列化 Eloquent 模型（队列场景需要）
     */
    use Queueable, SerializesModels;

    /**
     * 公共属性自动传递给视图模板
     *
     * Mailable 的 public 属性会自动作为变量注入 Blade 视图，
     * 无需在 content() 的 with 中手动传递。
     */
    public string $orderNo;
    public string $productName;
    public string $amount;
    public string $failedAt;
    public string $reason;

    public function __construct(
        string $orderNo,
        string $productName,
        string $amount,
        string $failedAt,
        string $reason = ''
    ) {
        $this->orderNo = $orderNo;
        $this->productName = $productName;
        $this->amount = $amount;
        $this->failedAt = $failedAt;
        $this->reason = $reason;
    }

    /**
     * 定义邮件信封（主题等元信息）
     *
     * Envelope 是 Laravel 11+ 推荐的方式（替代旧的 subject() 链式调用）。
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: '⚠️ 订单异常通知 - 订单号: ' . $this->orderNo,
        );
    }

    /**
     * 定义邮件内容（视图模板）
     *
     * Content 指定 Blade 视图路径。
     * 视图命名空间 'notification-email' 在 EmailPlugin::register() 中注册，
     * 'notification-email::emails.order-failed' 对应插件 views/emails/order-failed.blade.php。
     */
    public function content(): Content
    {
        return new Content(
            view: 'notification-email::emails.order-failed',
        );
    }

    /**
     * 获取邮件附件
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
