<?php

/**
 * 邮件通知插件路由定义
 *
 * 由 EmailPlugin::register() 中 require 加载。
 */

use Illuminate\Support\Facades\Route;

Route::prefix('admin')
    ->middleware('admin.auth')
    ->group(function () {
        Route::get('/plugin/notification-email', [\NotificationEmail\Controllers\SettingsController::class, 'index'])
            ->name('admin.plugin.notification-email');

        Route::post('/plugin/notification-email', [\NotificationEmail\Controllers\SettingsController::class, 'save'])
            ->name('admin.plugin.notification-email.save');
    });
