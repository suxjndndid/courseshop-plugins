<?php

/**
 * 邮件通知插件路由定义
 *
 * 由 EmailPlugin::register() 中 require 加载。
 */

use NotificationEmail\Controllers\SettingsController;
use Illuminate\Support\Facades\Route;

admin_route_group(function () {
    Route::get('/plugin/notification-email', [SettingsController::class, 'index'])
        ->name('admin.plugin.notification-email');

    Route::post('/plugin/notification-email', [SettingsController::class, 'save'])
        ->name('admin.plugin.notification-email.save');
});
