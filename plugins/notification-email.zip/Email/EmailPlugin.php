<?php

use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Core\Contracts\NotificationChannelInterface;
use App\Core\Notification\Notification;
use App\Core\Admin\AdminMenu;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Mail;

/**
 * 邮件通知插件
 *
 * 同时实现两个接口：
 * - PluginInterface：插件生命周期管理
 * - NotificationChannelInterface：通知渠道（send/supports）
 *
 * 监听事件：
 * - OrderFailed → 发送失败告警给管理员+用户
 * - OrderFulfilled → 发送完成通知给用户（课程全部完成时）
 */
class EmailPlugin implements PluginInterface, NotificationChannelInterface
{
    public function id(): string { return 'notification-email'; }
    public function name(): string { return '邮件通知'; }
    public function version(): string { return '1.0.0'; }
    public function type(): PluginType { return PluginType::Notification; }

    /**
     * 注册阶段：加载依赖、注册视图/菜单/路由
     */
    public function register(): void
    {
        $pluginPath = dirname(__FILE__);

        // 加载插件依赖类
        require_once $pluginPath . '/Listeners/OrderFailedListener.php';
        require_once $pluginPath . '/Listeners/OrderFulfilledListener.php';
        require_once $pluginPath . '/Mail/OrderFailedMail.php';
        require_once $pluginPath . '/Mail/OrderCompletedMail.php';
        require_once $pluginPath . '/Controllers/SettingsController.php';

        // 注册视图命名空间
        app('view')->addNamespace('notification-email', $pluginPath . '/views');

        // 注册后台菜单
        AdminMenu::add([
            'group' => AdminMenu::GROUP_NOTIFICATION,
            'items' => [
                [
                    'label' => '邮件通知',
                    'icon'  => 'envelope',
                    'route' => 'admin.plugin.notification-email',
                    'order' => 52,
                ],
            ],
        ]);

        // 加载路由文件（Controller 类路由，无闭包）
        require $pluginPath . '/routes.php';
    }

    /**
     * 启动阶段：注册事件监听器
     *
     * 监听两个核心事件：
     * - OrderFailed: 履约失败时发送告警邮件
     * - OrderFulfilled: 课程全部完成时发送通知邮件
     */
    public function boot(): void
    {
        // 订单失败 → 告警邮件（管理员 + 用户）
        Event::listen(\App\Core\Event\OrderFailed::class, function (\App\Core\Event\OrderFailed $event) {
            (new \OrderFailedListener())->handle($event);
        });

        // 履约完成 → 完成通知邮件（用户 + 管理员）
        Event::listen(\App\Core\Event\OrderFulfilled::class, function (\App\Core\Event\OrderFulfilled $event) {
            (new \OrderFulfilledListener())->handle($event);
        });
    }

    public function uninstall(): void
    {
        AdminMenu::remove('admin.plugin.notification-email');
    }

    /**
     * 插件默认配置
     *
     * enabled_events 默认启用 order.failed 和 order.fulfilled。
     */
    public function config(): array
    {
        return [
            'admin_email'    => '',
            'enabled_events' => 'order.failed,order.fulfilled',
        ];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }

    // ==================== NotificationChannelInterface ====================

    /**
     * 发送通知（通用入口）
     *
     * 根据 $notification->type 分发不同 Mailable。
     * 支持：order.failed、order.fulfilled
     */
    public function send(Notification $notification): bool
    {
        try {
            $adminEmail = plugin_context($this->id())->config('admin_email')
                ?: \App\Models\Setting::getValue('core', 'contact_email');

            if (empty($adminEmail)) {
                plugin_context($this->id())->logger()->warning('未配置管理员邮箱，跳过发送', [
                    'type' => $notification->type,
                ]);
                return false;
            }

            switch ($notification->type) {
                case 'order.failed':
                    return $this->sendOrderFailed($notification, $adminEmail);

                case 'order.fulfilled':
                    return $this->sendOrderFulfilled($notification, $adminEmail);

                default:
                    plugin_context($this->id())->logger()->info('未实现的通知类型，跳过', [
                        'type' => $notification->type,
                    ]);
                    return false;
            }
        } catch (\Throwable $e) {
            plugin_context($this->id())->logger()->error('通知发送异常', [
                'type'  => $notification->type,
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * 检查此渠道是否支持指定事件类型
     */
    public function supports(string $eventType): bool
    {
        $enabledStr = plugin_context($this->id())->config('enabled_events', 'order.failed,order.fulfilled');
        $enabled = array_filter(array_map('trim', explode(',', $enabledStr)));

        return in_array($eventType, $enabled, true);
    }

    // ==================== 私有方法：各类型邮件发送 ====================

    /**
     * 发送订单失败通知
     */
    private function sendOrderFailed(Notification $notification, string $adminEmail): bool
    {
        $mailable = new \OrderFailedMail(
            orderNo: $notification->data['order_no'] ?? '',
            productName: $notification->data['product_name'] ?? '',
            amount: $notification->data['amount'] ?? '0.00',
            failedAt: $notification->data['failed_at'] ?? now()->format('Y-m-d H:i:s'),
            reason: $notification->data['reason'] ?? ''
        );

        // 发送给管理员
        Mail::to($adminEmail)->send($mailable);

        // 发送给客户（如有不同邮箱）
        $customerEmail = $notification->data['notification_email'] ?? '';
        if (!empty($customerEmail) && $customerEmail !== $adminEmail) {
            Mail::to($customerEmail)->send($mailable);
        }

        plugin_context($this->id())->logger()->info('订单失败通知已发送', [
            'order_no'       => $notification->data['order_no'] ?? '',
            'admin_email'    => $adminEmail,
            'customer_email' => $customerEmail ?: '无',
        ]);
        return true;
    }

    /**
     * 发送履约完成通知
     */
    private function sendOrderFulfilled(Notification $notification, string $adminEmail): bool
    {
        $mailable = new \OrderCompletedMail(
            orderNo: $notification->data['order_no'] ?? '',
            productName: $notification->data['product_name'] ?? '',
            amount: $notification->data['amount'] ?? '0.00',
            completedAt: $notification->data['completed_at'] ?? now()->format('Y-m-d H:i:s'),
            courseList: $notification->data['course_list'] ?? []
        );

        // 优先发给用户
        $customerEmail = $notification->data['notification_email'] ?? '';
        $recipients = array_filter(array_unique([$customerEmail, $adminEmail]));

        foreach ($recipients as $email) {
            Mail::to($email)->send($mailable);
        }

        plugin_context($this->id())->logger()->info('履约完成通知已发送', [
            'order_no'   => $notification->data['order_no'] ?? '',
            'recipients' => $recipients,
        ]);
        return true;
    }
}
