<?php

namespace NotificationEmail\Controllers;

use App\Models\Setting;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;

/**
 * 邮件通知后台设置控制器
 */
class SettingsController
{
    public function index()
    {
        $settings = Setting::getGroup('notification-email');
        return view('notification-email::settings', ['settings' => $settings]);
    }

    public function save(Request $request)
    {
        $request->validate([
            'admin_email' => 'required|email|max:255',
        ]);

        $enabledEvents = $request->input('enabled_events', []);

        Setting::setGroup('notification-email', [
            'admin_email'    => $request->input('admin_email'),
            'enabled_events' => implode(',', $enabledEvents),
        ]);

        app(ActivityLogService::class)->log('setting', '更新邮件通知配置');

        return redirect()->route('admin.plugin.notification-email')
            ->with('success', '邮件通知配置已保存');
    }
}
