<?php

use App\Core\Event\OrderFailed;
use App\Models\Setting;
use Illuminate\Support\Facades\Mail;

/**
 * 订单失败事件监听器
 *
 * 监听 OrderFailed 事件，发送邮件通知给管理员和订单客户。
 * 在 EmailPlugin::boot() 中通过 Event::listen() 注册。
 *
 * 无命名空间，通过 require_once 加载。
 */
class OrderFailedListener
{
    /**
     * 处理订单失败事件
     *
     * 处理流程：
     * 1. 获取收件人（管理员邮箱 + 订单客户邮箱）
     * 2. 从 OrderFailed 事件中提取订单信息
     * 3. 构造 OrderFailedMail 并发送
     * 4. 记录发送结果日志
     *
     * @param OrderFailed $event 事件实例，包含 order（PaymentOrder）和 reason（失败原因）
     */
    public function handle(OrderFailed $event): void
    {
        try {
            $order = $event->order;
            $reason = $event->reason;

            // 获取管理员邮箱：优先插件配置，回退到系统核心联系邮箱
            $adminEmail = plugin_context('notification-email')->config('admin_email')
                ?: Setting::getValue('core', 'contact_email');

            // 获取订单客户的通知邮箱
            $customerEmail = $order->notification_email ?? '';

            // 收集所有不重复的收件人
            $recipients = array_filter(array_unique([
                $adminEmail,
                $customerEmail,
            ]));

            if (empty($recipients)) {
                plugin_context('notification-email')->logger()->warning('无有效收件人，跳过邮件发送', [
                    'order_no' => $order->order_no,
                ]);
                return;
            }

            // 构造邮件
            $mailable = new \OrderFailedMail(
                orderNo: $order->order_no,
                productName: $order->product_name,
                amount: $order->final_amount ?? $order->total_amount,
                failedAt: now()->format('Y-m-d H:i:s'),
                reason: $reason
            );

            // 逐个发送（避免一个失败影响其他收件人）
            foreach ($recipients as $email) {
                try {
                    Mail::to($email)->send($mailable);
                    plugin_context('notification-email')->logger()->info('邮件已发送', [
                        'order_no' => $order->order_no,
                        'to' => $email,
                    ]);
                } catch (\Throwable $e) {
                    plugin_context('notification-email')->logger()->error('邮件发送失败', [
                        'order_no' => $order->order_no,
                        'to' => $email,
                        'error' => $e->getMessage(),
                    ]);
                }
            }
        } catch (\Throwable $e) {
            plugin_context('notification-email')->logger()->error('监听器处理异常', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
        }
    }
}
