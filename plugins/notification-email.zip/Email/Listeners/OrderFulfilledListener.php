<?php

use App\Core\Event\OrderFulfilled;
use App\Models\Setting;
use Illuminate\Support\Facades\Mail;

/**
 * 履约完成事件监听器
 *
 * 监听 OrderFulfilled 事件，发送"课程学习完成"邮件通知给用户。
 * 在 EmailPlugin::boot() 中通过 Event::listen() 注册。
 *
 * 无命名空间，通过 require_once 加载。
 */
class OrderFulfilledListener
{
    /**
     * 处理履约完成事件
     *
     * 仅在插件配置启用了 order.fulfilled 事件时发送。
     * 优先发给用户 notification_email，同时抄送管理员。
     */
    public function handle(OrderFulfilled $event): void
    {
        try {
            // 检查插件是否启用了此事件类型
            $enabledStr = plugin_context('notification-email')->config('enabled_events', 'order.failed');
            $enabled = array_filter(array_map('trim', explode(',', $enabledStr)));
            if (!in_array('order.fulfilled', $enabled, true)) {
                return;
            }

            $order = $event->order;
            $result = $event->result;

            // 已通知过的订单跳过（幂等）
            if ($order->is_notified) {
                plugin_context('notification-email')->logger()->info('订单已通知过，跳过', [
                    'order_no' => $order->order_no,
                ]);
                return;
            }

            // 获取邮箱
            $adminEmail = plugin_context('notification-email')->config('admin_email')
                ?: Setting::getValue('core', 'contact_email');
            $customerEmail = $order->notification_email ?? '';

            $recipients = array_filter(array_unique([$customerEmail, $adminEmail]));

            if (empty($recipients)) {
                plugin_context('notification-email')->logger()->warning('无有效收件人，跳过完成通知', [
                    'order_no' => $order->order_no,
                ]);
                return;
            }

            // 收集课程列表
            $courseList = [];
            $studyOrders = \StudyOrder::byPaymentOrderId($order->id)->get();
            foreach ($studyOrders as $so) {
                $courseList[] = $so->course_name;
            }

            // 构造邮件
            $mailable = new \OrderCompletedMail(
                orderNo: $order->order_no,
                productName: $order->product_name,
                amount: (string) $order->final_amount,
                completedAt: now()->format('Y-m-d H:i:s'),
                courseList: $courseList
            );

            // 逐个发送
            foreach ($recipients as $email) {
                try {
                    Mail::to($email)->send($mailable);
                    plugin_context('notification-email')->logger()->info('完成通知已发送', [
                        'order_no' => $order->order_no,
                        'to'       => $email,
                    ]);
                } catch (\Throwable $e) {
                    plugin_context('notification-email')->logger()->error('完成通知发送失败', [
                        'order_no' => $order->order_no,
                        'to'       => $email,
                        'error'    => $e->getMessage(),
                    ]);
                }
            }

            // 更新通知状态（如果 StatusSyncService 还没更新的话）
            if (!$order->is_notified) {
                $order->update([
                    'is_notified'        => 1,
                    'notified_at'        => now(),
                    'notification_count' => ($order->notification_count ?? 0) + 1,
                ]);
            }

        } catch (\Throwable $e) {
            plugin_context('notification-email')->logger()->error('完成通知监听器异常', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
        }
    }
}
