<?php

use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Core\Contracts\NotificationChannelInterface;
use App\Core\Notification\Notification;
use App\Core\Admin\AdminMenu;
use Illuminate\Support\Facades\Http;

class WebhookPlugin implements PluginInterface, NotificationChannelInterface
{
    public function id(): string { return 'notification-webhook'; }
    public function name(): string { return 'Webhook 自定义通知'; }
    public function version(): string { return '1.0.0'; }
    public function type(): PluginType { return PluginType::Notification; }

    public function register(): void
    {
        $pluginPath = dirname(__FILE__);
        require_once $pluginPath . '/Controllers/SettingsController.php';
        app('view')->addNamespace('notification-webhook', $pluginPath . '/views');
        AdminMenu::add([
            'group' => AdminMenu::GROUP_NOTIFICATION,
            'items' => [
                ['label' => 'Webhook 自定义通知', 'icon' => 'link', 'route' => 'admin.plugin.notification-webhook', 'order' => 61],
            ],
        ]);
        require $pluginPath . '/routes.php';
    }

    public function boot(): void
    {
        // 由 NotificationDispatcher 统一分发，不再自行监听事件
    }

    public function uninstall(): void { AdminMenu::remove('admin.plugin.notification-webhook'); }

    public function config(): array
    {
        return [
            'url' => '',
            'body' => '{"title":"$title", "content":"$content"}',
            'headers' => 'Content-Type: application/json',
            'method' => 'POST',
            'content_type' => 'application/json',
        ];
    }

    public function requires(): array { return ['core' => '>=1.0']; }

    public function send(Notification $notification): bool
    {
        try {
            $ctx = plugin_context($this->id());
            $urlConfig = $ctx->config('url');
            if (!$urlConfig) {
                $ctx->logger()->error('Webhook URL 未配置');
                return false;
            }

            $url = str_replace(['$title', '$content'], [urlencode($notification->subject), urlencode($notification->body)], $urlConfig);
            $bodyStr = str_replace(['$title', '$content'], [$notification->subject, $notification->body], $ctx->config('body', ''));
            $method = strtoupper($ctx->config('method', 'POST'));
            
            $headersRaw = $ctx->config('headers', '');
            $headers = [];
            foreach (explode("\n", str_replace("\r", "", $headersRaw)) as $line) {
                if (str_contains($line, ':')) {
                    [$k, $v] = explode(':', $line, 2);
                    $headers[trim($k)] = trim($v);
                }
            }

            $contentType = $ctx->config('content_type', 'application/json');
            $request = Http::withHeaders($headers)->contentType($contentType);
            
            if ($method === 'GET') {
                $response = $request->get($url);
            } else {
                $response = $request->withBody($bodyStr, $contentType)->send($method, $url);
            }

            if (!$response->successful()) {
                $ctx->logger()->error('Webhook 推送失败', ['status' => $response->status(), 'body' => $response->body()]);
                return false;
            }

            return true;
        } catch (\Throwable $e) {
            plugin_context($this->id())->logger()->error('Webhook 推送异常', ['error' => $e->getMessage()]);
            return false;
        }
    }

    public function supports(string $eventType): bool
    {
        return true;
    }
}
