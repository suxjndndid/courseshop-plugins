<?php
namespace NotificationWebhook\Controllers;
use App\Models\Setting;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;

class SettingsController {
    public function index() {
        $settings = Setting::getGroup('notification-webhook');
        return view('notification-webhook::settings', ['settings' => $settings]);
    }

    public function save(Request $request) {
        $request->validate([
            'url' => 'required|string',
            'method' => 'required|in:GET,POST,PUT',
            'content_type' => 'required|string',
            'headers' => 'nullable|string',
            'body' => 'nullable|string',
        ]);

        // Logic check: $title must appear in URL or body
        if (!str_contains($request->input('url'), '$title') && !str_contains($request->input('body', ''), '$title')) {
            return back()->withErrors(['body' => '配置错误：$title 占位符必须出现在 URL 或 Body 中'])->withInput();
        }

        Setting::setGroup('notification-webhook', [
            'url' => $request->input('url'),
            'method' => $request->input('method'),
            'content_type' => $request->input('content_type'),
            'headers' => $request->input('headers'),
            'body' => $request->input('body'),
        ]);
        Setting::where('setting_group', 'notification-webhook')
            ->whereIn('key', ['enabled_events', 'route_use_legacy_supports'])
            ->delete();

        app(ActivityLogService::class)->log('setting', '更新 Webhook 配置');

        return redirect()->route('admin.plugin.notification-webhook')->with('success', 'Webhook 配置已保存');
    }
}
