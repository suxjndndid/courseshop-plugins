@extends('admin.layouts.app')

@section('title', 'Webhook 自定义通知配置')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 class="text-lg font-medium text-gray-900 mb-6">Webhook 自定义通知配置</h2>

        @if(session('success'))
            <div class="mb-4 p-4 bg-green-50 border border-green-200 text-green-600 rounded-md">
                {{ session('success') }}
            </div>
        @endif

        @if($errors->any())
            <div class="mb-4 p-4 bg-red-50 border border-red-200 text-red-600 rounded-md">
                <ul class="list-disc list-inside text-sm">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('admin.plugin.notification-webhook.save') }}" method="POST">
            @csrf
            
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Webhook URL</label>
                    <input type="text" name="url" value="{{ $settings['url'] ?? '' }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" placeholder="https://api.example.com/notify?title=$title">
                    <p class="mt-1 text-xs text-gray-500">支持占位符: $title, $content</p>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">请求方法 (Method)</label>
                        <select name="method" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            <option value="POST" {{ ($settings['method'] ?? 'POST') == 'POST' ? 'selected' : '' }}>POST</option>
                            <option value="GET" {{ ($settings['method'] ?? 'POST') == 'GET' ? 'selected' : '' }}>GET</option>
                            <option value="PUT" {{ ($settings['method'] ?? 'POST') == 'PUT' ? 'selected' : '' }}>PUT</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">内容类型 (Content-Type)</label>
                        <select name="content_type" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            <option value="application/json" {{ ($settings['content_type'] ?? 'application/json') == 'application/json' ? 'selected' : '' }}>application/json</option>
                            <option value="application/x-www-form-urlencoded" {{ ($settings['content_type'] ?? 'application/json') == 'application/x-www-form-urlencoded' ? 'selected' : '' }}>application/x-www-form-urlencoded</option>
                            <option value="text/plain" {{ ($settings['content_type'] ?? 'application/json') == 'text/plain' ? 'selected' : '' }}>text/plain</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">自定义 Headers (每行一个)</label>
                    <textarea name="headers" rows="3" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" placeholder="Authorization: Bearer token&#10;X-Custom-Header: value">{{ $settings['headers'] ?? '' }}</textarea>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">请求 Body</label>
                    <textarea name="body" rows="4" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" placeholder='{"text": "$title\n$content"}'>{{ $settings['body'] ?? '' }}</textarea>
                    <p class="mt-1 text-xs text-gray-500">支持占位符: $title, $content。如果是 JSON 或表单，且 Body 格式为 key=value，将自动解析并转换。</p>
                </div>

                <div class="rounded-md border border-blue-100 bg-blue-50 p-3 text-sm text-blue-800">
                    分发规则已统一迁移到后台“系统 → 通知分发”，这里仅维护 Webhook 的发送参数。
                </div>
            </div>

            <div class="mt-6">
                <button type="submit" class="w-full inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    保存配置
                </button>
            </div>
        </form>
    </div>
</div>
@endsection
