<?php

use NotificationWebhook\Controllers\SettingsController;
use Illuminate\Support\Facades\Route;

admin_route_group(function () {
    Route::get('/plugin/notification-webhook', [SettingsController::class, 'index'])
        ->name('admin.plugin.notification-webhook');
    Route::post('/plugin/notification-webhook', [SettingsController::class, 'save'])
        ->name('admin.plugin.notification-webhook.save');
});
