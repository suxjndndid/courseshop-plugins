<?php
use Illuminate\Support\Facades\Route;

Route::prefix('admin')->middleware('admin.auth')->group(function () {
    Route::get('/plugin/notification-webhook', [\NotificationWebhook\Controllers\SettingsController::class, 'index'])
        ->name('admin.plugin.notification-webhook');
    Route::post('/plugin/notification-webhook', [\NotificationWebhook\Controllers\SettingsController::class, 'save'])
        ->name('admin.plugin.notification-webhook.save');
});
