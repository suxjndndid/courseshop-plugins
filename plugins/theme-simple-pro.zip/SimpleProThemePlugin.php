<?php

use App\Core\Contracts\FrontendThemeInterface;
use App\Core\Hook\Hook;
use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Services\FrontendThemeService;

/**
 * Simple Professional 前台主题插件
 *
 * 设计目标：
 * - 与 brutal 主题并存
 * - 保持同一套固定 Blade 布局
 * - 只替换视觉风格，不改业务结构
 */
class SimpleProThemePlugin implements PluginInterface, FrontendThemeInterface
{
    public function id(): string
    {
        return 'theme-simple-pro';
    }

    public function name(): string
    {
        return '简约专业主题';
    }

    public function version(): string
    {
        return '1.0.0';
    }

    public function type(): PluginType
    {
        return PluginType::Theme;
    }

    public function register(): void
    {
        app('view')->addNamespace('theme-simple-pro', dirname(__FILE__) . '/views');
    }

    public function boot(): void
    {
        Hook::addFilter('frontend.head', function (string $html): string {
            if (!app(FrontendThemeService::class)->isActiveTheme($this->id())) {
                return $html;
            }

            return $html . "\n" . view('theme-simple-pro::styles.shared')->render() . "\n";
        }, 10);
    }

    public function uninstall(): void
    {
    }

    public function config(): array
    {
        return [];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }

    public function frontendThemeLabel(): string
    {
        return '简约专业';
    }

    public function frontendThemeDescription(): string
    {
        return '更稳重清爽，信息层次清晰，整体像一套成熟的品牌官网。';
    }

    public function frontendThemeOrder(): int
    {
        return 20;
    }
}
