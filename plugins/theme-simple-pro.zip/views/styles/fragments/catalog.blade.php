body.frontend-body .brutal-products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(170px, 170px));
    gap: 14px;
    justify-content: start;
}

body.frontend-body .brutal-product {
    overflow: hidden;
    border: 1px solid var(--theme-line);
    border-radius: 8px;
    background: #fff;
    transition: border-color 0.15s ease, box-shadow 0.15s ease;
}

body.frontend-body .brutal-product:hover {
    border-color: rgba(44, 90, 160, 0.38);
    box-shadow: var(--theme-shadow-sm);
}

body.frontend-body .brutal-product.is-offline {
    opacity: 0.62;
}

body.frontend-body .brutal-product-image {
    aspect-ratio: 4 / 3;
    background: var(--theme-image-bg);
    overflow: hidden;
}

body.frontend-body .brutal-product-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

body.frontend-body .brutal-product-body {
    display: grid;
    gap: 6px;
    padding: 11px;
}

body.frontend-body .brutal-product-name {
    margin: 0;
    color: var(--theme-ink);
    font-size: 12px;
    font-weight: 600;
    line-height: 1.3;
}

body.frontend-body .brutal-product-meta {
    margin: 0;
    color: #9ca3af;
    font-size: 10px;
}

body.frontend-body .brutal-product-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 6px;
}

body.frontend-body .brutal-product-price {
    color: var(--theme-accent);
    font-size: 13px;
    font-weight: 700;
}

body.frontend-body .brutal-buy-btn {
    border: 0;
    border-radius: 4px;
    background: var(--theme-accent);
    color: #fff;
    padding: 4px 8px;
    font-size: 10px;
    font-weight: 600;
}

body.frontend-body .brutal-pagination-wrap {
    margin-top: 16px;
}

body.frontend-body .frontend-pagination {
    gap: 5px;
}

body.frontend-body .frontend-pagination .page-link {
    min-width: 28px;
    height: 28px;
    display: inline-grid;
    place-items: center;
    border: 1px solid #d1d5db;
    border-radius: 4px;
    background: #fff;
    color: var(--theme-muted);
    box-shadow: none;
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: 11px;
    font-weight: 600;
}

body.frontend-body .frontend-pagination .page-item.active .page-link,
body.frontend-body .frontend-pagination .page-link:hover {
    border-color: var(--theme-accent);
    background: var(--theme-accent);
    color: #fff;
}

body.frontend-body .frontend-pagination .page-item.disabled .page-link {
    opacity: 0.5;
}

body.frontend-body .brutal-empty-state,
body.frontend-body .empty-state {
    padding: 28px 18px;
    border: 1px solid var(--theme-line);
    border-radius: 10px;
    background: #fff;
    text-align: center;
    color: var(--theme-muted);
    font-size: 14px;
    font-weight: 600;
}

body.frontend-body .brutal-detail-ticker,
body.frontend-body .brutal-query-title-bar {
    display: grid;
    gap: 4px;
    margin-bottom: 16px;
    padding: 12px 14px;
    border-radius: 8px;
    background: var(--theme-accent-soft);
}

body.frontend-body .brutal-detail-ticker {
    grid-template-columns: auto 1fr auto;
    align-items: center;
    gap: 12px;
}

body.frontend-body .ticker-label,
body.frontend-body .ticker-note,
body.frontend-body .brutal-panel-kicker,
body.frontend-body .brutal-eyebrow,
body.frontend-body .count-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: fit-content;
    padding: 4px 8px;
    border-radius: 999px;
    background: rgba(44, 90, 160, 0.12);
    color: var(--theme-accent);
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: 11px;
    font-weight: 600;
    text-transform: none;
    box-shadow: none;
}

body.frontend-body .ticker-copy,
body.frontend-body .brutal-query-title-bar p {
    margin: 0;
    color: var(--theme-muted);
    font-size: 13px;
    font-weight: 500;
}

body.frontend-body .brutal-query-title-bar h1 {
    margin: 0;
    color: var(--theme-ink);
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: clamp(24px, 4vw, 32px);
    font-weight: 700;
    text-transform: none;
}

body.frontend-body .brutal-breadcrumb {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
    margin-bottom: 16px;
    padding: 8px 10px;
    border: 1px solid var(--theme-line);
    border-radius: 8px;
    background: #fff;
    color: var(--theme-muted);
    box-shadow: var(--theme-shadow-sm);
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: 12px;
    font-weight: 500;
    text-transform: none;
}

