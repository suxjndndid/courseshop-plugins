body.frontend-body .brutal-product-hero {
    display: grid;
    grid-template-columns: minmax(0, 1.1fr) minmax(0, 0.9fr);
    gap: 22px;
    align-items: start;
    margin-bottom: 22px;
    padding: 18px;
    border: 1px solid var(--theme-line);
    border-radius: 12px;
    background: #fff;
    box-shadow: var(--theme-shadow);
}

body.frontend-body .brutal-hero-media {
    position: relative;
    overflow: hidden;
    border: 1px solid var(--theme-line);
    border-radius: 10px;
    background: var(--theme-image-bg);
    padding: 14px;
}

body.frontend-body .brutal-hero-media img {
    width: 100%;
    aspect-ratio: 4 / 3;
    object-fit: cover;
    border-radius: 8px;
    background: #fff;
}

body.frontend-body .brutal-floating-tags {
    position: absolute;
    inset: 12px 12px auto auto;
    z-index: 1;
    display: grid;
    gap: 8px;
    justify-items: end;
}

body.frontend-body .brutal-tag {
    display: inline-flex;
    align-items: center;
    min-height: 28px;
    padding: 4px 8px;
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.94);
    color: var(--theme-ink);
    font-size: 11px;
    font-weight: 600;
    box-shadow: var(--theme-shadow-sm);
}

body.frontend-body .brutal-tag.is-yellow,
body.frontend-body .brutal-tag.is-green,
body.frontend-body .brutal-tag.is-white {
    background: rgba(255, 255, 255, 0.94);
}

body.frontend-body .brutal-hero-summary {
    display: grid;
    gap: 14px;
    align-content: start;
}

body.frontend-body .brutal-eyebrow {
    background: var(--theme-accent-soft);
}

body.frontend-body .brutal-price-strip {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 14px;
}

body.frontend-body .brutal-price-card,
body.frontend-body .brutal-status-card {
    padding: 14px 16px;
    border: 1px solid var(--theme-line);
    border-radius: 10px;
    box-shadow: var(--theme-shadow-sm);
}

body.frontend-body .brutal-price-card {
    background: var(--theme-accent-soft);
}

body.frontend-body .brutal-status-card {
    min-width: 118px;
    display: grid;
    place-items: center;
    text-align: center;
    background: #fff;
    color: var(--theme-accent);
    font-size: 12px;
    font-weight: 600;
}

body.frontend-body .price-label {
    margin-bottom: 6px;
    color: var(--theme-muted);
    font-size: 12px;
    font-weight: 600;
}

body.frontend-body .price-value {
    color: var(--theme-accent);
    font-size: clamp(30px, 5vw, 44px);
    line-height: 1;
    font-weight: 700;
}

body.frontend-body .brutal-detail-block,
body.frontend-body .brutal-query-shell,
body.frontend-body .results-shell,
body.frontend-body .brutal-panel {
    border: 1px solid var(--theme-line);
    border-radius: 12px;
    background: #fff;
    box-shadow: var(--theme-shadow);
}

body.frontend-body .brutal-detail-block {
    padding: 14px;
}

body.frontend-body .brutal-detail-note,
body.frontend-body .query-tip,
body.frontend-body .brutal-biz-hint {
    margin: 0;
    color: #94a3b8;
    font-size: 11px;
    font-weight: 500;
    text-transform: none;
}

body.frontend-body .product-detail-html {
    display: grid;
    gap: 10px;
    font-size: 14px;
    color: var(--theme-ink);
}

body.frontend-body .product-detail-html table {
    width: 100%;
    border-collapse: collapse;
}

body.frontend-body .product-detail-html th,
body.frontend-body .product-detail-html td {
    border: 1px solid var(--theme-line);
    padding: 8px 10px;
}

body.frontend-body .brutal-hero-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

body.frontend-body .brutal-work-grid {
    display: grid;
    grid-template-columns: minmax(0, 1.4fr) minmax(320px, 0.9fr);
    grid-template-areas: 'biz buy';
    gap: 22px;
}

body.frontend-body #brutal-buy-panel {
    grid-area: buy;
    align-self: start;
    position: sticky;
    top: 18px;
}

body.frontend-body #brutal-biz-panel {
    grid-area: biz;
}

body.frontend-body .brutal-panel {
    padding: 18px;
}

body.frontend-body .brutal-panel-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 16px;
}

body.frontend-body .brutal-panel-title,
body.frontend-body .results-head h2 {
    margin: 0;
    color: var(--theme-ink);
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: 18px;
    font-weight: 700;
    text-transform: none;
}

body.frontend-body .brutal-biz-result {
    min-height: 220px;
    padding: 14px;
    border: 1px solid var(--theme-line);
    border-radius: 10px;
    background: var(--theme-panel-alt);
}

body.frontend-body .brutal-biz-empty {
    color: var(--theme-muted);
    font-size: 13px;
    font-weight: 500;
}

body.frontend-body .brutal-field-group {
    display: grid;
    gap: 8px;
    margin-bottom: 16px;
}

body.frontend-body .brutal-field-label,
body.frontend-body #product-adapter-ui .form-label {
    color: var(--theme-ink);
    font-family: 'Inter', 'Noto Sans SC', sans-serif;
    font-size: 12px;
    font-weight: 600;
    text-transform: none;
}

body.frontend-body .brutal-input,
body.frontend-body .brutal-textarea,
body.frontend-body .query-input,
body.frontend-body #product-adapter-ui .form-control {
    width: 100%;
    min-height: 46px;
    border: 1px solid var(--theme-line);
    border-radius: 8px;
    background: #fff;
    color: var(--theme-ink);
    padding: 10px 12px;
    box-shadow: none;
    font-size: 14px;
}

body.frontend-body .brutal-textarea {
    min-height: 110px;
    resize: vertical;
}

body.frontend-body .brutal-input:focus,
body.frontend-body .brutal-textarea:focus,
body.frontend-body .query-input:focus,
body.frontend-body #product-adapter-ui .form-control:focus {
    outline: none;
    border-color: rgba(44, 90, 160, 0.42);
    box-shadow: 0 0 0 3px rgba(44, 90, 160, 0.12);
}

body.frontend-body .brutal-coupon-row {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 10px;
}

body.frontend-body .coupon-result {
    padding: 10px 12px;
    border: 1px solid var(--theme-line);
    border-radius: 8px;
    background: #fff;
    font-size: 13px;
    font-weight: 500;
}

body.frontend-body .coupon-result.success {
    border-left: 3px solid var(--theme-success);
}

body.frontend-body .coupon-result.error {
    border-left: 3px solid var(--theme-danger);
}

body.frontend-body .coupon-info {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
}

body.frontend-body .coupon-clear {
    cursor: pointer;
}

body.frontend-body #couponCode.verified {
    background: #f0fdf4;
}

body.frontend-body .invalid-feedback {
    color: var(--theme-danger);
    font-size: 12px;
    font-weight: 500;
}

body.frontend-body #payment-methods-container,
body.frontend-body .brutal-payment-container,
body.frontend-body #product-adapter-ui {
    display: grid;
    gap: 10px;
    margin-bottom: 16px;
}

body.frontend-body .brutal-inline-warning {
    padding: 12px;
    border-radius: 8px;
    background: #fff7ed;
    border-left: 3px solid var(--theme-warning);
    color: #9a3412;
    font-size: 13px;
    font-weight: 500;
}

body.frontend-body .brutal-price-breakdown {
    display: grid;
    gap: 10px;
    margin-bottom: 16px;
    padding: 14px;
    border: 1px solid var(--theme-line);
    border-radius: 10px;
    background: var(--theme-panel-alt);
}

body.frontend-body .price-line,
body.frontend-body .price-total {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    font-size: 13px;
    font-weight: 500;
}

body.frontend-body .price-total {
    padding-top: 10px;
    border-top: 1px solid var(--theme-line);
    color: var(--theme-ink);
    font-size: 14px;
    font-weight: 700;
    text-transform: none;
}

body.frontend-body .brutal-submit-btn {
    width: 100%;
}

body.frontend-body .brutal-helper-list {
    display: grid;
    gap: 10px;
    margin: 16px 0 0;
    padding: 0;
    list-style: none;
}

body.frontend-body .brutal-helper-list li {
    display: grid;
    gap: 2px;
    padding: 10px 12px;
    border: 1px solid var(--theme-line);
    border-radius: 8px;
    background: var(--theme-panel-alt);
}

body.frontend-body .brutal-helper-list span {
    color: var(--theme-muted);
    font-size: 12px;
}

body.frontend-body #product-adapter-ui .mb-3 {
    margin-bottom: 0 !important;
    display: grid;
    gap: 8px;
}

body.frontend-body #product-adapter-ui .input-group.password-input-group {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 10px;
    align-items: stretch;
}

body.frontend-body .btn-toggle-password,
body.frontend-body #product-adapter-ui .btn,
body.frontend-body .order-actions .btn {
    border: 1px solid var(--theme-line);
    border-radius: 8px;
    background: #fff;
    color: var(--theme-accent);
    box-shadow: none;
    font-size: 12px;
    font-weight: 600;
}

body.frontend-body #product-adapter-ui .btn-primary,
body.frontend-body .btn-refresh {
    background: var(--theme-accent);
    color: #fff;
    border-color: transparent;
}

body.frontend-body .course-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
}

body.frontend-body .course-summary {
    color: var(--theme-muted);
    font-size: 12px;
    font-weight: 500;
}

body.frontend-body .course-grid {
    display: grid;
    gap: 10px;
}

body.frontend-body .course-card {
    display: block;
    cursor: pointer;
}

body.frontend-body .course-checkbox {
    position: absolute;
    opacity: 0;
    pointer-events: none;
}

body.frontend-body .course-card-body {
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 12px;
    padding: 12px;
    border: 1px solid var(--theme-line);
    border-radius: 8px;
    background: #fff;
}

body.frontend-body .course-card.selected .course-card-body {
    border-color: rgba(44, 90, 160, 0.38);
    background: var(--theme-accent-soft);
}

body.frontend-body .course-card-check {
    width: 22px;
    height: 22px;
    display: inline-grid;
    place-items: center;
    border: 1px solid var(--theme-line);
    border-radius: 6px;
    background: #fff;
}

body.frontend-body .course-card.selected .course-card-check {
    background: var(--theme-accent);
    color: #fff;
    border-color: var(--theme-accent);
}

body.frontend-body .course-card-name {
    color: var(--theme-ink);
    font-size: 13px;
    font-weight: 600;
}

body.frontend-body .course-card-meta {
    color: var(--theme-muted);
    font-size: 12px;
    font-weight: 500;
}

body.frontend-body #selfCourseResult {
    border: 1px solid var(--theme-line) !important;
    border-radius: 10px !important;
    background: var(--theme-panel-alt) !important;
}

body.frontend-body #selfCourseResult table {
    width: 100%;
    border-collapse: collapse;
}

body.frontend-body #selfCourseResult th,
body.frontend-body #selfCourseResult td {
    border: 1px solid var(--theme-line);
    padding: 8px 10px;
}
