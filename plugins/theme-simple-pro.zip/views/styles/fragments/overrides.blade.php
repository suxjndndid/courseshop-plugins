{{-- SimplePro 主题特有覆盖样式 --}}
@media (max-width: 575px) {
    body.frontend-body .brutal-home-hero {
        margin-top: 28px;
    }

    body.frontend-body .brutal-products-grid {
        grid-template-columns: 1fr;
    }

    body.frontend-body .frontend-footer-shell,
    body.frontend-body .frontend-footer-brand,
    body.frontend-body .frontend-footer-links {
        width: 100%;
    }
}
