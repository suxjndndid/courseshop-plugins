<style>
@include('theme-simple-pro::styles.fragments.shell')
@include('theme-simple-pro::styles.fragments.catalog')
@include('theme-simple-pro::styles.fragments.detail')
@include('theme-simple-pro::styles.fragments.query')
</style>
