<?php

use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Core\Contracts\NotificationChannelInterface;
use App\Core\Notification\Notification;
use App\Core\Admin\AdminMenu;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Http;

class PushPlusPlugin implements PluginInterface, NotificationChannelInterface
{
    public function id(): string { return 'notification-pushplus'; }
    public function name(): string { return 'PushPlus 推送'; }
    public function version(): string { return '1.0.0'; }
    public function type(): PluginType { return PluginType::Notification; }

    public function register(): void
    {
        $pluginPath = dirname(__FILE__);
        require_once $pluginPath . '/Controllers/SettingsController.php';
        app('view')->addNamespace('notification-pushplus', $pluginPath . '/views');
        AdminMenu::add([
            'group' => AdminMenu::GROUP_NOTIFICATION,
            'items' => [
                ['label' => 'PushPlus 推送', 'icon' => 'notification', 'route' => 'admin.plugin.notification-pushplus', 'order' => 57],
            ],
        ]);
        require $pluginPath . '/routes.php';
    }

    public function boot(): void
    {
        // 由 NotificationDispatcher 统一分发，不再自行监听事件
    }

    public function uninstall(): void
    {
        AdminMenu::remove('admin.plugin.notification-pushplus');
    }

    public function config(): array
    {
        return [
            'token' => '',
            'user' => '',
            'template' => 'html',
            'channel' => 'wechat',
            'webhook' => '',
            'callback_url' => '',
            'to' => '',
        ];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }

    // ==================== NotificationChannelInterface ====================

    public function send(Notification $notification): bool
    {
        try {
            $ctx = plugin_context($this->id());
            $token = $ctx->config('token');

            if (empty($token)) {
                return false;
            }

            $payload = [
                'token' => $token,
                'title' => $notification->subject,
                'content' => nl2br($notification->body),
                'template' => $ctx->config('template', 'html'),
                'channel' => $ctx->config('channel', 'wechat'),
                'webhook' => $ctx->config('webhook'),
                'callbackUrl' => $ctx->config('callback_url'),
                'timestamp' => time() * 1000,
            ];

            if ($ctx->config('to')) {
                $payload['to'] = $ctx->config('to');
            }

            $response = Http::post('http://www.pushplus.plus/send', $payload);

            return $response->successful() && ($response->json('code') === 200);
        } catch (\Throwable $e) {
            plugin_context($this->id())->logger()->error('PushPlus 推送异常', ['error' => $e->getMessage()]);
            return false;
        }
    }

    public function supports(string $eventType): bool
    {
        return true;
    }

}
er, string $type, string $summary): void
    {
        $this->send(new Notification(
            type: $type,
            subject: "[{$order->order_no}] {$summary}",
            body: "商品: {$order->product_name}\n金额: {$order->final_amount}\n时间: " . now()->format('Y-m-d H:i:s'),
            data: ['order_no' => $order->order_no, 'product_name' => $order->product_name, 'amount' => $order->final_amount]
        ));
    }
}
