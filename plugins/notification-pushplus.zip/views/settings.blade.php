@extends('admin.layouts.app')

@section('title', 'PushPlus 配置')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 class="text-lg font-medium text-gray-900 mb-6">PushPlus 配置</h3>

        @if(session('success'))
            <div class="mb-4 p-4 bg-green-50 border-l-4 border-green-400 text-green-700">
                {{ session('success') }}
            </div>
        @endif

        @if($errors->any())
            <div class="mb-4 p-4 bg-red-50 border-l-4 border-red-400 text-red-700">
                <ul class="list-disc list-inside">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('admin.plugin.notification-pushplus.save') }}" method="POST">
            @csrf
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Token</label>
                    <input type="text" name="token" value="{{ old('token', $settings['token'] ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" required>
                    <p class="mt-1 text-xs text-gray-500">PushPlus 官网获取的 token</p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Topic (User)</label>
                    <input type="text" name="user" value="{{ old('user', $settings['user'] ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                    <p class="mt-1 text-xs text-gray-500">群组编码，不填则发给自己</p>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Template</label>
                        <select name="template" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            <option value="html" {{ ($settings['template'] ?? 'html') == 'html' ? 'selected' : '' }}>HTML</option>
                            <option value="txt" {{ ($settings['template'] ?? '') == 'txt' ? 'selected' : '' }}>Text</option>
                            <option value="json" {{ ($settings['template'] ?? '') == 'json' ? 'selected' : '' }}>JSON</option>
                            <option value="markdown" {{ ($settings['template'] ?? '') == 'markdown' ? 'selected' : '' }}>Markdown</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Channel</label>
                        <select name="channel" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            <option value="wechat" {{ ($settings['channel'] ?? 'wechat') == 'wechat' ? 'selected' : '' }}>微信</option>
                            <option value="webhook" {{ ($settings['channel'] ?? '') == 'webhook' ? 'selected' : '' }}>Webhook</option>
                            <option value="cp" {{ ($settings['channel'] ?? '') == 'cp' ? 'selected' : '' }}>企业微信</option>
                            <option value="mail" {{ ($settings['channel'] ?? '') == 'mail' ? 'selected' : '' }}>邮件</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Webhook URL</label>
                    <input type="text" name="webhook" value="{{ old('webhook', $settings['webhook'] ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">To (好友/群组令牌)</label>
                    <input type="text" name="to" value="{{ old('to', $settings['to'] ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                </div>

                <div class="rounded-md border border-blue-100 bg-blue-50 p-3 text-sm text-blue-800">
                    分发规则已统一迁移到后台“系统 → 通知分发”，这里仅维护 PushPlus 的发送参数。
                </div>

                <div class="pt-4">
                    <button type="submit" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        保存配置
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
