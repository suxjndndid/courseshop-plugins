<?php

namespace NotificationPushplus\Controllers;

use App\Models\Setting;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;

class SettingsController
{
    public function index()
    {
        $settings = Setting::getGroup('notification-pushplus');
        return view('notification-pushplus::settings', ['settings' => $settings]);
    }

    public function save(Request $request)
    {
        $request->validate([
            'token' => 'required|string',
        ]);
        
        Setting::setGroup('notification-pushplus', [
            'token' => $request->input('token'),
            'user' => $request->input('user'),
            'template' => $request->input('template', 'html'),
            'channel' => $request->input('channel', 'wechat'),
            'webhook' => $request->input('webhook'),
            'callback_url' => $request->input('callback_url'),
            'to' => $request->input('to'),
        ]);
        Setting::where('setting_group', 'notification-pushplus')
            ->whereIn('key', ['enabled_events', 'route_use_legacy_supports'])
            ->delete();

        app(ActivityLogService::class)->log('setting', '更新 PushPlus 配置');

        return redirect()->route('admin.plugin.notification-pushplus')->with('success', 'PushPlus 配置已保存');
    }
}
