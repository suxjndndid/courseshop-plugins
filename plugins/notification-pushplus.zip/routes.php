<?php

use NotificationPushplus\Controllers\SettingsController;
use Illuminate\Support\Facades\Route;

admin_route_group(function () {
    Route::get('/plugin/notification-pushplus', [SettingsController::class, 'index'])
        ->name('admin.plugin.notification-pushplus');
    Route::post('/plugin/notification-pushplus', [SettingsController::class, 'save'])
        ->name('admin.plugin.notification-pushplus.save');
});
