<?php

use Illuminate\Support\Facades\Route;

Route::prefix('admin')->middleware('admin.auth')->group(function () {
    Route::get('/plugin/notification-pushplus', [\NotificationPushplus\Controllers\SettingsController::class, 'index'])
        ->name('admin.plugin.notification-pushplus');
    Route::post('/plugin/notification-pushplus', [\NotificationPushplus\Controllers\SettingsController::class, 'save'])
        ->name('admin.plugin.notification-pushplus.save');
});
