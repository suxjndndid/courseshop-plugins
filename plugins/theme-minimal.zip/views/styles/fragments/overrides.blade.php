@media (max-width: 575px) {
    body.frontend-body .brutal-home-hero {
        margin-top: 28px;
    }

    body.frontend-body .brutal-products-grid {
        grid-template-columns: 1fr;
    }

    body.frontend-body .frontend-footer-shell,
    body.frontend-body .frontend-footer-brand,
    body.frontend-body .frontend-footer-links {
        width: 100%;
    }
}

body.frontend-body .frontend-brand-mark,
body.frontend-body .frontend-footer-mark,
body.frontend-body .frontend-nav-toggle,
body.frontend-body .frontend-theme-switcher-trigger,
body.frontend-body .frontend-theme-switcher-trigger-action,
body.frontend-body .frontend-theme-switcher-panel,
body.frontend-body .frontend-theme-switcher-close,
body.frontend-body .frontend-theme-option,
body.frontend-body .brutal-home-hero,
body.frontend-body .brutal-home-content,
body.frontend-body .brutal-announcement-strip,
body.frontend-body .brutal-query-title-bar,
body.frontend-body .brutal-query-shell,
body.frontend-body .results-shell,
body.frontend-body .brutal-detail-ticker,
body.frontend-body .brutal-product-hero,
body.frontend-body .brutal-panel,
body.frontend-body .brutal-detail-block,
body.frontend-body .query-input,
body.frontend-body .query-tab,
body.frontend-body .query-btn,
body.frontend-body .clear-btn,
body.frontend-body .brutal-input,
body.frontend-body .brutal-textarea,
body.frontend-body .brutal-submit-btn,
body.frontend-body .brutal-coupon-btn,
body.frontend-body .brutal-button,
body.frontend-body .brutal-ghost-button,
body.frontend-body .brutal-hero-btn,
body.frontend-body .brutal-product,
body.frontend-body .brutal-buy-btn,
body.frontend-body .custom-toast,
body.frontend-body .confirm-dialog,
body.frontend-body .confirm-btn {
    border-radius: 0 !important;
}

body.frontend-body .frontend-nav-shell,
body.frontend-body .frontend-footer-shell {
    border-color: #f0f0f0;
}

body.frontend-body .frontend-brand-mark,
body.frontend-body .frontend-footer-mark {
    border-color: var(--theme-line);
    background: #fff;
}

body.frontend-body .frontend-nav-link.active,
body.frontend-body .frontend-nav-link:hover,
body.frontend-body .query-tab.active,
body.frontend-body .brutal-chip.is-active,
body.frontend-body .page-item.active .page-link {
    background: #000 !important;
    color: #fff !important;
    border-color: #000 !important;
}

body.frontend-body .brutal-home-hero,
body.frontend-body .brutal-home-content,
body.frontend-body .brutal-product-hero,
body.frontend-body .brutal-panel,
body.frontend-body .results-shell,
body.frontend-body .brutal-query-title-bar,
body.frontend-body .brutal-query-shell,
body.frontend-body .brutal-detail-block {
    box-shadow: none;
}

body.frontend-body .brutal-announcement-strip,
body.frontend-body .brutal-disclaimer,
body.frontend-body .brutal-hitokoto-box {
    background: #f9f9f9;
}

body.frontend-body .brutal-hero-title,
body.frontend-body .brutal-panel-title,
body.frontend-body .results-head h2,
body.frontend-body .brutal-section-title {
    font-family: system-ui, -apple-system, 'Noto Sans SC', sans-serif;
    letter-spacing: 0;
    text-transform: none;
}

body.frontend-body .brutal-products-grid {
    grid-template-columns: repeat(auto-fit, minmax(180px, 220px));
    justify-content: start;
}

body.frontend-body .brutal-product {
    background: #f9f9f9;
    border: 1px solid var(--theme-line);
}

body.frontend-body .brutal-product:hover {
    background: #f0f0f0;
}

body.frontend-body .brutal-product-price,
body.frontend-body .price-value {
    color: #000;
}

body.frontend-body .brutal-button,
body.frontend-body .brutal-submit-btn,
body.frontend-body .query-btn,
body.frontend-body .brutal-buy-btn,
body.frontend-body .brutal-hero-btn {
    background: #000;
    color: #fff;
    border-color: #000;
    box-shadow: none;
}

body.frontend-body .brutal-ghost-button,
body.frontend-body .clear-btn,
body.frontend-body .brutal-coupon-btn {
    background: #fff;
    color: #000;
    border-color: var(--theme-line);
    box-shadow: none;
}
