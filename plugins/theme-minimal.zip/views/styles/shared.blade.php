<style>
@include('theme-minimal::styles.fragments.shell')
@include('theme-minimal::styles.fragments.catalog')
@include('theme-minimal::styles.fragments.detail')
@include('theme-minimal::styles.fragments.query')
@include('theme-minimal::styles.fragments.overrides')
</style>
