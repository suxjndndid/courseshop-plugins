<?php

use App\Core\Contracts\FrontendThemeInterface;
use App\Core\Hook\Hook;
use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Services\FrontendThemeService;

class MinimalThemePlugin implements PluginInterface, FrontendThemeInterface
{
    public function id(): string
    {
        return 'theme-minimal';
    }

    public function name(): string
    {
        return '极简留白主题';
    }

    public function version(): string
    {
        return '1.0.0';
    }

    public function type(): PluginType
    {
        return PluginType::Theme;
    }

    public function register(): void
    {
        app('view')->addNamespace('theme-minimal', dirname(__FILE__) . '/views');
    }

    public function boot(): void
    {
        Hook::addFilter('frontend.head', function (string $html): string {
            if (!app(FrontendThemeService::class)->isActiveTheme($this->id())) {
                return $html;
            }

            return $html . "\n" . view('theme-minimal::styles.shared')->render() . "\n";
        }, 10);
    }

    public function uninstall(): void
    {
    }

    public function config(): array
    {
        return [];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }

    public function frontendThemeLabel(): string
    {
        return '极简留白';
    }

    public function frontendThemeDescription(): string
    {
        return '留白更多、黑白更纯，浏览时会更安静，也更聚焦内容本身。';
    }

    public function frontendThemeOrder(): int
    {
        return 30;
    }
}
