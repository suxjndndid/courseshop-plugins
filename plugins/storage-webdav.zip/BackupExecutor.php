<?php

use App\Core\Contracts\BackupableInterface;
use App\Core\Plugin\PluginManager;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Process;

/**
 * 同步执行器
 *
 * 从老项目 WangKeLava/app/Services/Admin/BackupService.php 提取的核心同步逻辑。
 * 负责完整同步流程：数据库导出 → .env 复制 → 文件收集 → ZIP 打包 → 上传 → 轮换。
 * 远程保留 N 份快照，支持任意时间点恢复。空数据库时自动跳过，防止覆盖有效远程数据。
 *
 * 与老项目的关键区别：
 * - 配置来源：plugin_config() 替代 config()
 * - 存储操作：委托给 WebDAVClient，不直接操作 HTTP
 * - 同步路径：通过 BackupableInterface 动态收集（不硬编码）
 * - 临时文件目录：storage_path('app/backups')
 */
class BackupExecutor
{
    private WebDAVClient $client;
    private string $tempPath;

    /**
     * @param WebDAVClient $client WebDAV 客户端实例，用于远程存储操作
     */
    public function __construct(WebDAVClient $client)
    {
        $this->client = $client;
        $this->tempPath = storage_path('app/backups');

        // 确保临时目录存在（递归创建），类似 mkdir -p
        if (!File::exists($this->tempPath)) {
            File::makeDirectory($this->tempPath, 0755, true);
        }
    }

    // =====================================================================
    //  完整同步入口
    // =====================================================================

    /**
     * 执行完整同步（数据库 + .env + 文件）
     *
     * 流程：空库检查 → 逐项同步 → 全部成功后轮换 → 返回结果
     *
     * @return array ['success' => bool, 'message' => string, 'details' => [...]]
     */
    public function syncFull(): array
    {
        $startTime = microtime(true);
        $timestamp = date('Ymd_His');

        // 空库检查：防止空数据库覆盖有效远程数据
        $emptyCheck = $this->checkDatabaseNotEmpty();
        if (!$emptyCheck['success']) {
            return $emptyCheck;
        }

        $results = [
            'database' => $this->backupDatabase($timestamp),
            'env' => $this->backupEnv($timestamp),
            'files' => $this->backupFiles($timestamp),
        ];

        $success = $results['database']['success']
            && $results['env']['success']
            && $results['files']['success'];

        // 全部成功后执行轮换，删除超出保留数量的旧同步记录
        if ($success) {
            $keepCount = (int) plugin_context('storage-webdav')->config('keep_count', 3);
            $this->rotateBackups($keepCount);
        }

        $duration = round(microtime(true) - $startTime, 2);

        // 记录同步日志到 backup_logs 表
        $this->logBackup('sync', $success ? 'success' : 'failure', array_keys($results), $success ? "完整同步成功，耗时 {$duration}s" : '部分同步失败', $duration);

        return [
            'success' => $success,
            'message' => $success ? "完整同步成功，耗时 {$duration}s" : '部分同步失败',
            'details' => $results,
        ];
    }

    // =====================================================================
    //  分项同步
    // =====================================================================

    /**
     * 同步数据库：mysqldump → ZIP → 上传到 backups/{timestamp}/database.sql.zip
     *
     * @param string $timestamp 时间戳目录名（如 20260324_120000）
     * @return array ['success' => bool, 'message' => string]
     */
    public function backupDatabase(string $timestamp): array
    {
        $sqlFile = $this->tempPath . '/database.sql';
        $zipFile = $this->tempPath . '/database.sql.zip';

        try {
            // 第一步：mysqldump 导出
            $result = $this->dumpDatabase($sqlFile);
            if (!$result['success']) {
                return $result;
            }

            // 第二步：压缩为 ZIP
            $zipResult = $this->createZip($zipFile, [$sqlFile], 'database.sql');
            if (!$zipResult['success']) {
                return $zipResult;
            }

            // 清理临时 SQL 文件
            File::delete($sqlFile);

            // 第三步：上传到 WebDAV
            $uploadResult = $this->client->upload($zipFile, "backups/{$timestamp}/database.sql.zip");
            File::delete($zipFile);

            return $uploadResult;
        } catch (\Exception $e) {
            plugin_context('storage-webdav')->logger()->error('数据库同步失败', ['error' => $e->getMessage()]);
            return ['success' => false, 'message' => '数据库同步失败: ' . $e->getMessage()];
        }
    }

    /**
     * 同步 .env 文件：复制 → ZIP → 上传到 backups/{timestamp}/env.zip
     *
     * @param string $timestamp 时间戳目录名
     * @return array ['success' => bool, 'message' => string]
     */
    public function backupEnv(string $timestamp): array
    {
        $envFile = base_path('.env');
        $zipFile = $this->tempPath . '/env.zip';

        try {
            if (!File::exists($envFile)) {
                return ['success' => false, 'message' => '.env 文件不存在'];
            }

            $zipResult = $this->createZip($zipFile, [$envFile], '.env');
            if (!$zipResult['success']) {
                return $zipResult;
            }

            $uploadResult = $this->client->upload($zipFile, "backups/{$timestamp}/env.zip");
            File::delete($zipFile);

            return $uploadResult;
        } catch (\Exception $e) {
            plugin_context('storage-webdav')->logger()->error('.env 同步失败', ['error' => $e->getMessage()]);
            return ['success' => false, 'message' => '.env 同步失败: ' . $e->getMessage()];
        }
    }

    /**
     * 同步文件：收集所有 BackupableInterface 声明的路径 → ZIP → 上传
     *
     * 通过 BackupableInterface 动态收集同步路径：
     * 框架核心和各插件各自声明需要同步的文件/目录，
     * 同步执行器只负责打包上传，不硬编码同步范围。
     *
     * @param string $timestamp 时间戳目录名
     * @return array ['success' => bool, 'message' => string]
     */
    public function backupFiles(string $timestamp): array
    {
        $zipFile = $this->tempPath . '/files.zip';

        try {
            $filesToBackup = $this->collectBackupPaths();

            if (empty($filesToBackup)) {
                return ['success' => true, 'message' => '没有需要同步的文件'];
            }

            $zipResult = $this->createZipFromPaths($zipFile, $filesToBackup);
            if (!$zipResult['success'] || str_contains($zipResult['message'], '没有需要备份的文件')) {
                return $zipResult;
            }

            $uploadResult = $this->client->upload($zipFile, "backups/{$timestamp}/files.zip");
            File::delete($zipFile);

            return $uploadResult;
        } catch (\Exception $e) {
            plugin_context('storage-webdav')->logger()->error('文件同步失败', ['error' => $e->getMessage()]);
            return ['success' => false, 'message' => '文件同步失败: ' . $e->getMessage()];
        }
    }

    // =====================================================================
    //  轮换管理
    // =====================================================================

    /**
     * 轮换同步：列出时间戳目录，删除超出保留数量的旧目录
     *
     * 按目录名降序排列（最新在前），保留 $keepCount 个，删除其余。
     *
     * @param int $keepCount 保留的备份数量
     */
    public function rotateBackups(int $keepCount): void
    {
        try {
            $result = $this->client->listDirectory('backups/');
            $dirs = $result['dirs'] ?? [];

            if (count($dirs) <= $keepCount) {
                return;
            }

            // 按目录名降序排列（时间戳格式保证字典序 = 时间序）
            usort($dirs, fn($a, $b) => strcmp($b, $a));

            // array_slice 跳过前 $keepCount 个（保留的），剩余的需要删除
            $dirsToDelete = array_slice($dirs, $keepCount);

            foreach ($dirsToDelete as $dir) {
                // 目录路径末尾加 / 表示删除整个目录及其内容
                $this->client->delete('backups/' . $dir . '/');
                plugin_context('storage-webdav')->logger()->info('轮换删除旧同步目录', ['dir' => $dir]);
            }
        } catch (\Exception $e) {
            plugin_context('storage-webdav')->logger()->warning('轮换同步清理失败', ['error' => $e->getMessage()]);
        }
    }

    // =====================================================================
    //  同步列表与恢复
    // =====================================================================

    /**
     * 获取同步列表：返回各时间戳目录及其包含的组件
     *
     * @return array [['timestamp' => string, 'time' => string, 'components' => array], ...]
     */
    public function getBackupList(): array
    {
        $result = $this->client->listDirectory('backups/');
        $dirs = $result['dirs'] ?? [];

        if (empty($dirs)) {
            return [];
        }

        // 按目录名降序排列（最新在前）
        usort($dirs, fn($a, $b) => strcmp($b, $a));

        $backups = [];
        foreach ($dirs as $dir) {
            // 解析时间戳目录名：20260324_120000 → 2026-03-24 12:00:00
            $time = '未知';
            if (preg_match('/(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})/', $dir, $m)) {
                $time = "{$m[1]}-{$m[2]}-{$m[3]} {$m[4]}:{$m[5]}:{$m[6]}";
            }

            // 查询该时间戳目录下包含的同步组件
            $components = $this->getBackupComponents($dir);

            $backups[] = [
                'timestamp' => $dir,
                'time' => $time,
                'components' => $components,
            ];
        }

        return $backups;
    }

    /**
     * 从指定同步点恢复（按选择的组件）
     *
     * @param string $timestamp 时间戳目录名
     * @param array $components 要恢复的组件列表（如 ['database', 'env', 'files']）
     * @return array ['success' => bool, 'message' => string, 'details' => [...]]
     */
    public function restoreFromBackup(string $timestamp, array $components = ['env', 'database', 'files']): array
    {
        $startTime = microtime(true);
        $results = [];

        if (in_array('env', $components)) {
            $results['env'] = $this->restoreEnv($timestamp);
        }

        if (in_array('database', $components)) {
            $results['database'] = $this->restoreDatabase($timestamp);
        }

        if (in_array('files', $components)) {
            $results['files'] = $this->restoreFiles($timestamp);
        }

        $success = true;
        foreach ($results as $r) {
            if (!$r['success']) {
                $success = false;
                break;
            }
        }

        $duration = round(microtime(true) - $startTime, 2);

        plugin_context('storage-webdav')->logger()->info('备份恢复' . ($success ? '成功' : '部分失败'), [
            'timestamp' => $timestamp,
            'components' => $components,
            'duration' => $duration,
        ]);

        $this->logBackup('restore', $success ? 'success' : 'failure', $components, $success ? "恢复成功，耗时 {$duration}s" : '部分恢复失败', $duration);

        return [
            'success' => $success,
            'message' => $success ? '恢复成功，请重启应用使配置生效' : '部分恢复失败',
            'details' => $results,
        ];
    }

    /**
     * 测试 WebDAV 连接（代理到 WebDAVClient）
     *
     * @return array ['success' => bool, 'message' => string]
     */
    public function testConnection(): array
    {
        return $this->client->testConnection();
    }

    // =====================================================================
    //  私有方法：数据库操作
    // =====================================================================

    /**
     * 使用 mysqldump 导出数据库
     *
     * Process::timeout(300) — Laravel Process facade，
     * 设置 300 秒超时防止大数据库导出时进程卡死。
     * --ssl=0 禁用 SSL 连接（Docker 容器间通信不需要）。
     *
     * @param string $outputFile SQL 导出文件路径
     * @return array ['success' => bool, 'message' => string]
     */
    private function dumpDatabase(string $outputFile): array
    {
        $host = config('database.connections.mysql.host');
        $port = config('database.connections.mysql.port');
        $database = config('database.connections.mysql.database');
        $username = config('database.connections.mysql.username');
        $password = config('database.connections.mysql.password');

        /**
         * sprintf + escapeshellarg 构建 shell 命令：
         * escapeshellarg() 对参数进行转义，防止 shell 注入攻击。
         * 输出重定向 > 将 mysqldump 结果写入文件。
         */
        $command = sprintf(
            'mysqldump --ssl=0 -h %s -P %s -u %s -p%s %s > %s',
            escapeshellarg($host),
            escapeshellarg($port),
            escapeshellarg($username),
            escapeshellarg($password),
            escapeshellarg($database),
            escapeshellarg($outputFile)
        );

        /**
         * Process::timeout(300)->run() — Laravel 的进程管理：
         * - timeout(300)：设置最大执行时间 300 秒（5 分钟）
         * - run()：同步执行命令并等待完成
         * - failed()：检查进程退出码是否非零
         * - errorOutput()：获取 stderr 输出
         */
        $result = Process::timeout(300)->run($command);

        if ($result->failed()) {
            return ['success' => false, 'message' => 'mysqldump 失败: ' . $result->errorOutput()];
        }

        if (!File::exists($outputFile) || File::size($outputFile) === 0) {
            return ['success' => false, 'message' => '数据库导出文件为空'];
        }

        // 修复 MySQL 生成列（GENERATED COLUMNS）的 INSERT 语句
        $this->fixGeneratedColumnsInDump($outputFile, $database);

        return ['success' => true, 'message' => '数据库导出成功'];
    }

    /**
     * 修复 mysqldump 导出中的生成列问题
     *
     * MySQL GENERATED COLUMNS（如 remaining_usage AS (total_usage - used_count)）
     * 在 mysqldump 输出中会包含生成列的值，导致 IMPORT 时报错。
     * 此方法查询 INFORMATION_SCHEMA 找到生成列，重写 INSERT 语句排除这些列。
     *
     * @param string $sqlFile SQL 文件路径
     * @param string $database 数据库名
     */
    private function fixGeneratedColumnsInDump(string $sqlFile, string $database): void
    {
        /**
         * 查询 INFORMATION_SCHEMA.COLUMNS：
         * GENERATION_EXPRESSION != '' 的列就是生成列（虚拟列或存储列）
         */
        $generated = DB::select(
            "SELECT TABLE_NAME, COLUMN_NAME
             FROM INFORMATION_SCHEMA.COLUMNS
             WHERE TABLE_SCHEMA = ? AND GENERATION_EXPRESSION != ''",
            [$database]
        );

        if (empty($generated)) {
            return;
        }

        // 按表名分组生成列
        $tableGenCols = [];
        foreach ($generated as $col) {
            $tableGenCols[$col->TABLE_NAME][] = $col->COLUMN_NAME;
        }

        $pdo = DB::connection()->getPdo();
        $content = file_get_contents($sqlFile);

        foreach ($tableGenCols as $tableName => $genColNames) {
            // 获取该表所有非生成列（用于重写 INSERT 语句）
            $allCols = DB::select(
                "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND GENERATION_EXPRESSION = ''
                 ORDER BY ORDINAL_POSITION",
                [$database, $tableName]
            );

            $colNames = array_map(fn($c) => $c->COLUMN_NAME, $allCols);
            $selectCols = implode(',', array_map(fn($c) => "`{$c}`", $colNames));

            // 从数据库重新查询数据（只选非生成列）
            $rows = DB::select("SELECT {$selectCols} FROM `{$tableName}`");

            $newInsert = '';
            if (!empty($rows)) {
                $valueSets = [];
                foreach ($rows as $row) {
                    $values = [];
                    foreach ($colNames as $colName) {
                        $val = $row->$colName;
                        // PDO::quote() 正确转义字符串值，NULL 保持原样
                        $values[] = $val === null ? 'NULL' : $pdo->quote((string) $val);
                    }
                    $valueSets[] = '(' . implode(',', $values) . ')';
                }
                $newInsert = "INSERT INTO `{$tableName}` ({$selectCols}) VALUES " . implode(',', $valueSets) . ";";
            }

            // 正则替换原来的 INSERT 语句
            $pattern = '/INSERT INTO `' . preg_quote($tableName, '/') . '` VALUES\s*[^;]+;\n?/';
            $content = preg_replace($pattern, $newInsert ? $newInsert . "\n" : '', $content);

            plugin_context('storage-webdav')->logger()->debug('修复生成列导出', [
                'table' => $tableName,
                'generated_columns' => $genColNames,
                'row_count' => count($rows),
            ]);
        }

        file_put_contents($sqlFile, $content);
    }

    /**
     * 空库检查：防止空数据库覆盖远程有效同步数据
     *
     * 统计所有业务表的行数（排除 Laravel 系统表），
     * 如果总行数为 0 则拒绝备份。
     *
     * @return array ['success' => bool, 'message' => string]
     */
    private function checkDatabaseNotEmpty(): array
    {
        try {
            $tableCount = DB::select(
                "SELECT COUNT(*) as cnt FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ?",
                [config('database.connections.mysql.database')]
            );

            $rowCount = 0;
            if ($tableCount[0]->cnt > 0) {
                $tables = DB::select("SHOW TABLES");
                // 排除 Laravel 系统表（迁移/缓存/队列等）
                $systemTables = ['migrations', 'cache', 'cache_locks', 'sessions', 'jobs', 'failed_jobs', 'job_batches'];
                foreach ($tables as $table) {
                    $tableName = array_values((array) $table)[0];
                    if (in_array($tableName, $systemTables)) {
                        continue;
                    }
                    $count = DB::select("SELECT COUNT(*) as cnt FROM `{$tableName}`");
                    $rowCount += $count[0]->cnt;
                }
            }

            if ($rowCount === 0) {
                plugin_context('storage-webdav')->logger()->warning('同步跳过：数据库为空，拒绝覆盖远程数据');
                return ['success' => false, 'message' => '数据库为空，已跳过同步以保护远程数据'];
            }

            return ['success' => true, 'message' => 'ok'];
        } catch (\Exception $e) {
            return ['success' => false, 'message' => '数据库检查失败: ' . $e->getMessage()];
        }
    }

    // =====================================================================
    //  私有方法：ZIP 操作
    // =====================================================================

    /**
     * 创建 ZIP 压缩包（单文件模式）
     *
     * 使用 PHP 内置 ZipArchive 类。
     * addFromString() 从内存添加文件内容（读取后写入 ZIP）。
     *
     * @param string $zipFile 输出 ZIP 文件路径
     * @param array $files 要压缩的文件路径列表
     * @param string|null $entryName ZIP 内的文件名（只有一个文件时使用）
     * @return array ['success' => bool, 'message' => string]
     */
    private function createZip(string $zipFile, array $files, ?string $entryName = null): array
    {
        $zip = new ZipArchive();

        /**
         * ZipArchive::CREATE | ZipArchive::OVERWRITE：
         * - CREATE：如果不存在则创建
         * - OVERWRITE：如果已存在则覆盖
         * open() 返回 true 表示成功，否则返回错误码
         */
        if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            return ['success' => false, 'message' => '无法创建压缩包'];
        }

        foreach ($files as $file) {
            $name = $entryName ?? basename($file);
            $content = file_get_contents($file);
            if ($content !== false) {
                $zip->addFromString($name, $content);
            }
        }

        $zip->close();

        if (!File::exists($zipFile)) {
            return ['success' => false, 'message' => 'ZIP 文件创建失败'];
        }

        return ['success' => true, 'message' => '压缩成功'];
    }

    /**
     * 从目录列表创建 ZIP（多目录模式）
     *
     * 遍历每个目录，将其中所有文件添加到 ZIP 中，
     * 保留目录结构（baseName/relativePath）。
     *
     * @param string $zipFile 输出 ZIP 文件路径
     * @param array $directories 要压缩的目录路径列表
     * @return array ['success' => bool, 'message' => string]
     */
    private function createZipFromPaths(string $zipFile, array $directories): array
    {
        $zip = new ZipArchive();

        if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            return ['success' => false, 'message' => '无法创建压缩包'];
        }

        $fileCount = 0;

        foreach ($directories as $directory) {
            if (!File::isDirectory($directory)) {
                continue;
            }

            $baseName = basename($directory);
            // File::allFiles() 递归获取目录下所有文件
            $files = File::allFiles($directory);

            foreach ($files as $file) {
                // getRelativePathname() 获取相对于扫描目录的路径
                $relativePath = $baseName . '/' . $file->getRelativePathname();
                $content = file_get_contents($file->getRealPath());
                if ($content !== false) {
                    $zip->addFromString($relativePath, $content);
                    $fileCount++;
                }
            }
        }

        $zip->close();

        if ($fileCount === 0) {
            return ['success' => true, 'message' => '没有需要同步的文件'];
        }

        if (!File::exists($zipFile)) {
            return ['success' => false, 'message' => 'ZIP 文件创建失败'];
        }

        return ['success' => true, 'message' => "压缩成功，共 {$fileCount} 个文件"];
    }

    /**
     * 解压 ZIP 文件到指定目录
     *
     * 安全说明：
     * - 不直接调用 extractTo()，而是逐条目写入；
     * - 每个条目都做路径规范化，拒绝 `..`、绝对路径、Windows 盘符路径；
     * - 即使远程备份被篡改，也不能借恢复流程把文件写到目标目录之外。
     *
     * @param string $zipFile ZIP 文件路径
     * @param string $destination 解压目标目录
     * @return array ['success' => bool, 'message' => string]
     */
    private function extractZip(string $zipFile, string $destination): array
    {
        $zip = new ZipArchive();

        if ($zip->open($zipFile) !== true) {
            return ['success' => false, 'message' => '无法打开压缩包'];
        }

        try {
            if (!File::exists($destination)) {
                File::makeDirectory($destination, 0755, true);
            }

            for ($i = 0; $i < $zip->numFiles; $i++) {
                $stat = $zip->statIndex($i);
                if ($stat === false) {
                    return ['success' => false, 'message' => '读取压缩包条目失败'];
                }

                $entryName = (string) ($stat['name'] ?? '');
                try {
                    $normalizedEntry = $this->normalizeZipEntryName($entryName);
                } catch (\RuntimeException $e) {
                    return ['success' => false, 'message' => $e->getMessage()];
                }

                $targetPath = rtrim($destination, DIRECTORY_SEPARATOR)
                    . DIRECTORY_SEPARATOR
                    . str_replace('/', DIRECTORY_SEPARATOR, rtrim($normalizedEntry, '/'));

                if (str_ends_with($normalizedEntry, '/')) {
                    if (!File::exists($targetPath)) {
                        File::makeDirectory($targetPath, 0755, true);
                    }
                    continue;
                }

                $targetDir = dirname($targetPath);
                if (!File::exists($targetDir)) {
                    File::makeDirectory($targetDir, 0755, true);
                }

                $stream = $zip->getStream($entryName);
                if ($stream === false) {
                    return ['success' => false, 'message' => "读取压缩包条目失败: {$entryName}"];
                }

                $fileHandle = fopen($targetPath, 'wb');
                if ($fileHandle === false) {
                    fclose($stream);
                    return ['success' => false, 'message' => "写入解压文件失败: {$normalizedEntry}"];
                }

                stream_copy_to_stream($stream, $fileHandle);
                fclose($stream);
                fclose($fileHandle);
            }
        } finally {
            $zip->close();
        }

        return ['success' => true, 'message' => '解压成功'];
    }

    /**
     * 规范化 ZIP 条目名，并拒绝会逃逸目标目录的路径。
     *
     * 这里把 `a/b.txt` 这类相对路径视为合法，
     * 但以下情况全部拒绝：
     * - `../secret`
     * - `/etc/passwd`
     * - `C:/Windows/...`
     * - 含空字节或 `.` / `..` 段的路径
     */
    private function normalizeZipEntryName(string $entryName): string
    {
        $entryName = str_replace('\\', '/', $entryName);

        if ($entryName === '' || str_contains($entryName, "\0")) {
            throw new \RuntimeException('压缩包包含不安全路径');
        }

        if (str_starts_with($entryName, '/') || preg_match('/^[A-Za-z]:\//', $entryName) === 1) {
            throw new \RuntimeException("压缩包包含不安全路径: {$entryName}");
        }

        $isDirectory = str_ends_with($entryName, '/');
        $segments = array_values(array_filter(explode('/', trim($entryName, '/')), static fn (string $segment): bool => $segment !== ''));

        if (empty($segments)) {
            throw new \RuntimeException("压缩包包含不安全路径: {$entryName}");
        }

        foreach ($segments as $segment) {
            if ($segment === '.' || $segment === '..') {
                throw new \RuntimeException("压缩包包含不安全路径: {$entryName}");
            }
        }

        $normalized = implode('/', $segments);

        return $isDirectory ? $normalized . '/' : $normalized;
    }

    // =====================================================================
    //  私有方法：路径收集
    // =====================================================================

    /**
     * 收集所有需要同步的文件路径
     *
     * 遍历所有已加载的插件，找到实现 BackupableInterface 的插件，
     * 收集它们声明的同步路径中 type 不是 'database' 的文件/目录。
     * （数据库由 backupDatabase() 单独处理）
     *
     * instanceof 运算符：检查对象是否是某个类/接口的实例。
     * 用于在运行时判断插件是否实现了 BackupableInterface。
     *
     * @return array 需要同步的目录绝对路径列表
     */
    private function collectBackupPaths(): array
    {
        $filesToBackup = [];

        /**
         * app(PluginManager::class) — 从 Laravel 服务容器获取 PluginManager 单例。
         * getPlugins() 返回所有已加载的插件实例。
         */
        $plugins = app(PluginManager::class)->getPlugins();

        // 收集所有 BackupableInterface 实现：插件 + 框架核心（通过 tagged('backupable') 注册）
        $backupProviders = [];
        foreach ($plugins as $plugin) {
            if ($plugin instanceof BackupableInterface) {
                $backupProviders[] = $plugin;
            }
        }
        // tagged('backupable') 返回 AppServiceProvider 中注册的非插件 BackupableInterface 实现（如 DefaultBackupPaths）
        foreach (app()->tagged('backupable') as $provider) {
            $backupProviders[] = $provider;
        }

        foreach ($backupProviders as $provider) {
            foreach ($provider->backupPaths() as $backupItem) {
                // 跳过数据库类型（由 backupDatabase() 单独处理）
                if (($backupItem['type'] ?? null) === 'database') {
                    continue;
                }

                $path = $backupItem['path'] ?? null;
                if ($path === null) {
                    continue;
                }

                // 转换为绝对路径
                $absolutePath = base_path($path);
                if (File::exists($absolutePath) && File::isDirectory($absolutePath)) {
                    $files = File::allFiles($absolutePath);
                    if (count($files) > 0) {
                        $filesToBackup[] = $absolutePath;
                    }
                }
            }
        }

        return $filesToBackup;
    }

    // =====================================================================
    //  私有方法：恢复操作
    // =====================================================================

    /**
     * 恢复 .env 文件
     *
     * 下载 → 解压 → 备份当前 .env → 覆盖
     *
     * @param string $timestamp 时间戳目录名
     * @return array ['success' => bool, 'message' => string]
     */
    private function restoreEnv(string $timestamp): array
    {
        $zipFile = $this->tempPath . '/restore_env.zip';
        $envFile = base_path('.env');

        try {
            $downloadResult = $this->client->download("backups/{$timestamp}/env.zip", $zipFile);
            if (!$downloadResult['success']) {
                return $downloadResult;
            }

            $extractResult = $this->extractZip($zipFile, $this->tempPath);
            File::delete($zipFile);

            if (!$extractResult['success']) {
                return $extractResult;
            }

            // 备份当前 .env（加时间戳后缀防止覆盖）
            if (File::exists($envFile)) {
                File::copy($envFile, $envFile . '.backup.' . date('YmdHis'));
            }

            $extractedEnv = $this->tempPath . '/.env';
            if (!File::exists($extractedEnv)) {
                return ['success' => false, 'message' => '解压后未找到 .env 文件'];
            }

            File::move($extractedEnv, $envFile);

            return ['success' => true, 'message' => '.env 恢复成功'];
        } catch (\Exception $e) {
            plugin_context('storage-webdav')->logger()->error('恢复 .env 失败', ['error' => $e->getMessage()]);
            return ['success' => false, 'message' => '恢复 .env 失败: ' . $e->getMessage()];
        }
    }

    /**
     * 恢复数据库
     *
     * 下载 → 解压 → 修复生成列 → 清空现有表 → mysql 导入
     *
     * @param string $timestamp 时间戳目录名
     * @return array ['success' => bool, 'message' => string]
     */
    private function restoreDatabase(string $timestamp): array
    {
        $zipFile = $this->tempPath . '/restore_database.zip';
        $sqlFile = $this->tempPath . '/database.sql';

        try {
            $downloadResult = $this->client->download("backups/{$timestamp}/database.sql.zip", $zipFile);
            if (!$downloadResult['success']) {
                return $downloadResult;
            }

            $extractResult = $this->extractZip($zipFile, $this->tempPath);
            File::delete($zipFile);

            if (!$extractResult['success']) {
                return $extractResult;
            }

            if (!File::exists($sqlFile)) {
                return ['success' => false, 'message' => '解压后未找到 SQL 文件'];
            }

            $restoreResult = $this->importDatabase($sqlFile);
            File::delete($sqlFile);

            return $restoreResult;
        } catch (\Exception $e) {
            plugin_context('storage-webdav')->logger()->error('恢复数据库失败', ['error' => $e->getMessage()]);
            return ['success' => false, 'message' => '恢复数据库失败: ' . $e->getMessage()];
        }
    }

    /**
     * 恢复文件
     *
     * 下载 → 解压 → 覆盖到原目录
     *
     * @param string $timestamp 时间戳目录名
     * @return array ['success' => bool, 'message' => string]
     */
    private function restoreFiles(string $timestamp): array
    {
        $zipFile = $this->tempPath . '/restore_files.zip';
        $extractDir = $this->tempPath . '/restore_files_extract';

        try {
            $downloadResult = $this->client->download("backups/{$timestamp}/files.zip", $zipFile);
            if (!$downloadResult['success']) {
                return $downloadResult;
            }

            if (File::exists($extractDir)) {
                File::deleteDirectory($extractDir);
            }
            File::makeDirectory($extractDir, 0755, true);

            $extractResult = $this->extractZip($zipFile, $extractDir);
            File::delete($zipFile);

            if (!$extractResult['success']) {
                return $extractResult;
            }

            // 收集所有声明的备份路径，逐个恢复
            $backupPaths = $this->collectBackupPaths();
            foreach ($backupPaths as $targetPath) {
                $dirName = basename($targetPath);
                $sourceDir = $extractDir . '/' . $dirName;

                if (File::exists($sourceDir)) {
                    // 清空目标目录
                    if (File::exists($targetPath)) {
                        try {
                            File::deleteDirectory($targetPath);
                        } catch (\Exception $e) {
                            File::cleanDirectory($targetPath);
                        }
                    }
                    if (!File::exists($targetPath)) {
                        File::makeDirectory($targetPath, 0755, true);
                    }

                    // 逐文件复制，单个失败不影响整体
                    foreach (File::allFiles($sourceDir) as $file) {
                        $destFile = $targetPath . '/' . $file->getRelativePathname();
                        $destDir = dirname($destFile);
                        if (!File::exists($destDir)) {
                            File::makeDirectory($destDir, 0755, true);
                        }
                        try {
                            File::copy($file->getRealPath(), $destFile);
                        } catch (\Exception $e) {
                            plugin_context('storage-webdav')->logger()->warning('文件恢复跳过', [
                                'file' => $file->getRelativePathname(),
                                'error' => $e->getMessage(),
                            ]);
                        }
                    }
                }
            }

            File::deleteDirectory($extractDir);

            return ['success' => true, 'message' => '文件恢复成功'];
        } catch (\Exception $e) {
            plugin_context('storage-webdav')->logger()->error('恢复文件失败', ['error' => $e->getMessage()]);
            return ['success' => false, 'message' => '恢复文件失败: ' . $e->getMessage()];
        }
    }

    /**
     * 导入 SQL 文件到数据库
     *
     * 先修复生成列 → 清空所有表 → mysql 命令导入
     *
     * @param string $sqlFile SQL 文件路径
     * @return array ['success' => bool, 'message' => string]
     */
    private function importDatabase(string $sqlFile): array
    {
        $host = config('database.connections.mysql.host');
        $port = config('database.connections.mysql.port');
        $database = config('database.connections.mysql.database');
        $username = config('database.connections.mysql.username');
        $password = config('database.connections.mysql.password');

        // 修复 SQL 文件中的生成列 INSERT 语句
        $this->fixGeneratedColumnsInSqlFile($sqlFile);

        // 清空现有表（SET FOREIGN_KEY_CHECKS = 0 临时禁用外键约束）
        try {
            DB::statement('SET FOREIGN_KEY_CHECKS = 0');
            $tables = DB::select("SHOW TABLES");
            foreach ($tables as $table) {
                $tableName = array_values((array) $table)[0];
                DB::statement("DROP TABLE IF EXISTS `{$tableName}`");
            }
            DB::statement('SET FOREIGN_KEY_CHECKS = 1');
            plugin_context('storage-webdav')->logger()->info('恢复前已清空数据库所有表');
        } catch (\Exception $e) {
            plugin_context('storage-webdav')->logger()->warning('恢复前清表失败，继续尝试恢复', ['error' => $e->getMessage()]);
        }

        // 使用 mysql 命令导入（输入重定向 <）
        $command = sprintf(
            'mysql --ssl=0 -h %s -P %s -u %s -p%s %s < %s',
            escapeshellarg($host),
            escapeshellarg($port),
            escapeshellarg($username),
            escapeshellarg($password),
            escapeshellarg($database),
            escapeshellarg($sqlFile)
        );

        $result = Process::timeout(300)->run($command);

        if ($result->failed()) {
            return ['success' => false, 'message' => '数据库恢复失败: ' . $result->errorOutput()];
        }

        return ['success' => true, 'message' => '数据库恢复成功'];
    }

    /**
     * 修复 SQL 文件中的生成列 INSERT 语句（恢复前调用）
     *
     * 通过分析 CREATE TABLE 语句中的 GENERATED ALWAYS 关键字，
     * 找到生成列并从 INSERT 语句中移除。
     *
     * @param string $sqlFile SQL 文件路径
     */
    private function fixGeneratedColumnsInSqlFile(string $sqlFile): void
    {
        $content = file_get_contents($sqlFile);

        /**
         * 正则匹配 CREATE TABLE 语句：
         * - /s 修饰符使 . 匹配换行符
         * - 提取表名和列定义
         */
        preg_match_all('/CREATE TABLE `(\w+)` \((.*?)\n\)/s', $content, $createMatches);

        $genTables = [];
        foreach ($createMatches[1] as $i => $table) {
            // 查找包含 GENERATED ALWAYS 的列
            if (preg_match_all('/`(\w+)`.*?GENERATED ALWAYS/i', $createMatches[2][$i], $colMatches)) {
                // 获取所有列名
                preg_match_all('/^\s+`(\w+)`/m', $createMatches[2][$i], $allColMatches);
                $genTables[$table] = [
                    'all_cols' => $allColMatches[1],
                    'gen_cols' => $colMatches[1],
                ];
            }
        }

        if (empty($genTables)) {
            return;
        }

        foreach ($genTables as $table => $info) {
            // 找到生成列在列列表中的索引位置
            $genIndices = [];
            foreach ($info['gen_cols'] as $genCol) {
                $idx = array_search($genCol, $info['all_cols']);
                if ($idx !== false) {
                    $genIndices[] = $idx;
                }
            }

            // 构建非生成列列表
            $nonGenCols = array_values(array_filter($info['all_cols'], fn($c) => !in_array($c, $info['gen_cols'])));
            $colList = implode(',', array_map(fn($c) => "`{$c}`", $nonGenCols));

            // 重写 INSERT 语句，移除生成列的值
            $pattern = '/INSERT INTO `' . preg_quote($table, '/') . '` VALUES\s*(\([^;]+\));/s';
            if (preg_match($pattern, $content, $insertMatch)) {
                preg_match_all('/\(([^)]+)\)/', $insertMatch[1], $rows);
                $newRows = [];

                foreach ($rows[1] as $row) {
                    $values = str_getcsv($row, ',', "'");
                    // 从后往前删除生成列的值（避免索引偏移）
                    rsort($genIndices);
                    foreach ($genIndices as $idx) {
                        array_splice($values, $idx, 1);
                    }
                    $formatted = array_map(function ($v) {
                        if ($v === 'NULL') {
                            return 'NULL';
                        }

                        return "'" . addslashes($v) . "'";
                    }, $values);
                    $newRows[] = '(' . implode(',', $formatted) . ')';
                }

                $newInsert = "INSERT INTO `{$table}` ({$colList}) VALUES " . implode(',', $newRows) . ';';
                $content = preg_replace($pattern, $newInsert, $content);

                plugin_context('storage-webdav')->logger()->info('恢复前修复生成列', [
                    'table' => $table,
                    'gen_cols' => $info['gen_cols'],
                    'rows' => count($newRows),
                ]);
            }
        }

        file_put_contents($sqlFile, $content);
    }

    // =====================================================================
    //  私有方法：辅助
    // =====================================================================

    /**
     * 查询某个时间戳目录下包含的同步组件
     *
     * PROPFIND 该目录，检查响应中是否包含特定文件名。
     *
     * @param string $timestamp 时间戳目录名
     * @return array 组件列表（如 ['database', 'env', 'files']）
     */
    private function getBackupComponents(string $timestamp): array
    {
        $result = $this->client->listDirectory("backups/{$timestamp}/");

        // listDirectory 解析时间戳目录名，但这里我们需要检查文件
        // 用 PROPFIND 的原始响应来判断文件是否存在
        if (!$result['success']) {
            return [];
        }

        // 重新发送 PROPFIND 获取文件列表（listDirectory 只解析时间戳目录）
        $components = [];
        try {
            $url = rtrim(plugin_context('storage-webdav')->config('webdav_url', ''), '/');
            $basePath = trim(plugin_context('storage-webdav')->config('webdav_path', '/backup'), '/');
            $username = plugin_context('storage-webdav')->config('webdav_username', '');
            $password = plugin_context('storage-webdav')->config('webdav_password', '');

            $fullPath = $url . '/' . $basePath . '/backups/' . $timestamp . '/';

            $response = \Illuminate\Support\Facades\Http::withBasicAuth($username, $password)
                ->withOptions(['verify' => false, 'timeout' => 10])
                ->withHeaders([
                    'Depth' => '1',
                    'Content-Type' => 'application/xml',
                ])
                ->send('PROPFIND', $fullPath);

            $body = $response->body();

            if (str_contains($body, 'database.sql.zip')) {
                $components[] = 'database';
            }
            if (str_contains($body, 'env.zip')) {
                $components[] = 'env';
            }
            if (str_contains($body, 'files.zip')) {
                $components[] = 'files';
            }
        } catch (\Exception $e) {
            // 查询组件失败不影响整体列表
        }

        return $components;
    }

    /**
     * 记录同步/恢复日志到 backup_logs 表
     *
     * @param string $action 操作类型（sync/restore）
     * @param string $status 操作状态（success/failure）
     * @param array $components 涉及的组件列表
     * @param string $message 操作结果描述
     * @param float $duration 操作耗时（秒）
     */
    private function logBackup(string $action, string $status, array $components, string $message, float $duration): void
    {
        try {
            DB::table('backup_logs')->insert([
                'action' => $action,
                'status' => $status,
                'components' => json_encode($components),
                'message' => $message,
                'duration_seconds' => $duration,
                'created_at' => now(),
            ]);
        } catch (\Exception $e) {
            // backup_logs 表可能尚未创建，静默忽略
            plugin_context('storage-webdav')->logger()->debug('同步日志写入失败（表可能不存在）', ['error' => $e->getMessage()]);
        }
    }
}
