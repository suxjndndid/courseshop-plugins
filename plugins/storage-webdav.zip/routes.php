<?php

/**
 * WebDAV 插件路由定义
 *
 * 所有路由集中注册，指向 Controller 方法，无闭包。
 * 由 WebDAVPlugin::register() 中 require 加载。
 */

use WebDAV\Controllers\SettingsController;
use WebDAV\Controllers\SyncController;
use Illuminate\Support\Facades\Route;

admin_route_group(function () {
    // 设置页
    Route::get('/plugin/storage-webdav/settings', [SettingsController::class, 'index'])
        ->name('admin.plugin.storage-webdav.settings');

    Route::post('/plugin/storage-webdav/settings', [SettingsController::class, 'save'])
        ->name('admin.plugin.storage-webdav.settings.save');

    // AJAX 操作
    Route::post('/plugin/storage-webdav/sync', [SyncController::class, 'sync'])
        ->name('admin.plugin.storage-webdav.sync');

    Route::post('/plugin/storage-webdav/restore', [SyncController::class, 'restore'])
        ->name('admin.plugin.storage-webdav.restore');

    Route::post('/plugin/storage-webdav/test-connection', [SyncController::class, 'testConnection'])
        ->name('admin.plugin.storage-webdav.test-connection');

    Route::get('/plugin/storage-webdav/list', [SyncController::class, 'list'])
        ->name('admin.plugin.storage-webdav.list');
});
