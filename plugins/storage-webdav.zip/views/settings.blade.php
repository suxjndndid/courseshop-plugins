{{-- WebDAV 同步管理页面（连接配置 + 同步设置 + 同步管理/恢复） --}}
@extends('admin.layouts.app')

@section('title', '同步管理 - WebDAV')

@section('content')
<div class="max-w-4xl mx-auto space-y-6">

    {{-- 全局操作消息 --}}
    @if(session('success'))
    <div class="p-4 bg-green-50 border border-green-200 text-green-700 rounded-xl text-sm">
        {{ session('success') }}
    </div>
    @endif

    @if($errors->any())
    <div class="p-4 bg-red-50 border border-red-200 text-red-700 rounded-xl text-sm">
        @foreach($errors->all() as $error)
            <p>{{ $error }}</p>
        @endforeach
    </div>
    @endif

    {{-- ==================== 卡片 1：WebDAV 连接配置 ==================== --}}
    <div class="bg-white rounded-xl shadow-sm border p-6">
        <h2 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <svg class="w-5 h-5 mr-2 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
            </svg>
            WebDAV 连接配置
        </h2>

        <form id="settings-form" action="{{ route('admin.plugin.storage-webdav.settings.save') }}" method="POST">
            @csrf

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                {{-- WebDAV 服务器地址 --}}
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">WebDAV 服务器地址</label>
                    <input type="url" name="webdav_url" value="{{ $settings['webdav_url'] ?? '' }}"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                           placeholder="https://dav.jianguoyun.com/dav" required>
                </div>

                {{-- 用户名 --}}
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">用户名</label>
                    <input type="text" name="webdav_username" value="{{ $settings['webdav_username'] ?? '' }}"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                           placeholder="请输入 WebDAV 用户名" required>
                </div>

                {{-- 密码 --}}
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">密码</label>
                    <input type="password" name="webdav_password" value=""
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                           placeholder="{{ !empty($settings['webdav_password']) ? '已设置（留空不修改）' : '请输入密码' }}">
                    <p class="text-xs text-gray-400 mt-1">留空不修改</p>
                </div>

                {{-- 远程路径 --}}
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">远程同步路径</label>
                    <input type="text" name="webdav_path" value="{{ $settings['webdav_path'] ?? '/backup' }}"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                           placeholder="/backup" required>
                </div>

                {{-- 保留数量 --}}
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">保留份数</label>
                    <input type="number" name="keep_count" value="{{ $settings['keep_count'] ?? 3 }}"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                           min="1" max="100" required>
                    <p class="text-xs text-gray-400 mt-1">远程最多保留 N 份，超出自动删除最旧的</p>
                </div>
            </div>

            {{-- ==================== 同步调度设置 ==================== --}}
            <div class="mt-6 pt-4 border-t">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">自动同步</h3>

                {{-- 启用开关 --}}
                <div class="flex items-center gap-3 mb-4">
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" name="sync_enabled" value="1" id="sync-enabled-toggle"
                               {{ ($settings['sync_enabled'] ?? false) ? 'checked' : '' }}
                               class="sr-only peer">
                        {{-- Toggle 开关样式：peer 选择器用于根据 checkbox 状态改变兄弟元素样式 --}}
                        <div class="w-9 h-5 bg-gray-200 peer-focus:ring-2 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                    </label>
                    <span class="text-sm text-gray-600">启用自动同步</span>
                </div>

                {{-- 频率选择：radio 按钮组 --}}
                <div id="sync-frequency-options" class="{{ ($settings['sync_enabled'] ?? false) ? '' : 'hidden' }}">
                    <label class="block text-sm font-medium text-gray-700 mb-2">同步频率</label>
                    <div class="flex flex-wrap gap-3 mb-3">
                        @php $currentFreq = $settings['sync_frequency'] ?? '24h'; @endphp
                        <label class="inline-flex items-center cursor-pointer">
                            <input type="radio" name="sync_frequency" value="6h" {{ $currentFreq === '6h' ? 'checked' : '' }}
                                   class="text-indigo-600 focus:ring-indigo-500">
                            <span class="ml-1.5 text-sm text-gray-700">每 6 小时</span>
                        </label>
                        <label class="inline-flex items-center cursor-pointer">
                            <input type="radio" name="sync_frequency" value="12h" {{ $currentFreq === '12h' ? 'checked' : '' }}
                                   class="text-indigo-600 focus:ring-indigo-500">
                            <span class="ml-1.5 text-sm text-gray-700">每 12 小时</span>
                        </label>
                        <label class="inline-flex items-center cursor-pointer">
                            <input type="radio" name="sync_frequency" value="24h" {{ $currentFreq === '24h' ? 'checked' : '' }}
                                   class="text-indigo-600 focus:ring-indigo-500">
                            <span class="ml-1.5 text-sm text-gray-700">每天（凌晨 2 点）</span>
                        </label>
                        <label class="inline-flex items-center cursor-pointer">
                            <input type="radio" name="sync_frequency" value="custom" {{ $currentFreq === 'custom' ? 'checked' : '' }}
                                   class="text-indigo-600 focus:ring-indigo-500">
                            <span class="ml-1.5 text-sm text-gray-700">自定义</span>
                        </label>
                    </div>

                    {{-- 自定义 cron 输入框（仅 frequency=custom 时显示） --}}
                    <div id="custom-cron-input" class="{{ $currentFreq === 'custom' ? '' : 'hidden' }} mb-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Cron 表达式</label>
                        <input type="text" name="sync_cron" value="{{ $settings['sync_cron'] ?? '0 2 * * *' }}"
                               class="w-full max-w-xs px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                               placeholder="0 2 * * *">
                        <p class="text-xs text-gray-400 mt-1">标准 5 段 cron 格式：分 时 日 月 周</p>
                    </div>
                </div>
            </div>

            {{-- 操作按钮 --}}
            <div class="flex items-center gap-3 mt-6 pt-4 border-t">
                <button type="submit"
                        class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm transition-colors">
                    保存配置
                </button>
                <button type="button" id="btn-test-connection"
                        class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg text-sm hover:bg-gray-50 transition-colors">
                    测试连接
                </button>
                <span id="test-connection-result" class="text-sm hidden"></span>
            </div>
        </form>
    </div>

    {{-- ==================== 卡片 2：同步管理 ==================== --}}
    <div class="bg-white rounded-xl shadow-sm border overflow-x-auto">
        <div class="px-6 py-4 border-b flex items-center justify-between">
            <h2 class="text-lg font-semibold text-gray-800 flex items-center">
                <svg class="w-5 h-5 mr-2 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                </svg>
                同步记录
            </h2>
            <div class="flex gap-2">
                <button type="button" id="btn-refresh-list"
                        class="px-3 py-1.5 text-xs border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-50">
                    刷新
                </button>
                <button type="button" id="btn-sync-now"
                        class="px-3 py-1.5 text-xs bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg">
                    立即同步
                </button>
            </div>
        </div>

        {{-- 状态消息 --}}
        <div id="status-message" class="hidden mx-6 mt-4 p-3 rounded-lg border text-sm"></div>

        {{-- 加载中 --}}
        <div id="loading-state" class="px-6 py-8 text-center text-gray-400">
            <svg class="animate-spin h-5 w-5 mx-auto mb-2" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path>
            </svg>
            正在加载同步列表...
        </div>

        {{-- 空状态 --}}
        <div id="empty-state" class="hidden px-6 py-8 text-center text-gray-400">
            暂无同步记录，点击「立即同步」创建第一个快照
        </div>

        {{-- 同步表格 --}}
        <table id="backup-table" class="hidden w-full text-sm">
            <thead class="bg-gray-50 border-b">
                <tr>
                    <th class="px-6 py-3 text-left font-medium text-gray-600">时间戳</th>
                    <th class="px-6 py-3 text-left font-medium text-gray-600">同步时间</th>
                    <th class="px-6 py-3 text-left font-medium text-gray-600">包含组件</th>
                    <th class="px-6 py-3 text-right font-medium text-gray-600">操作</th>
                </tr>
            </thead>
            <tbody id="backup-table-body" class="divide-y"></tbody>
        </table>
    </div>

    {{-- ==================== 恢复弹窗（默认隐藏） ==================== --}}
    <div id="restore-modal" class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black/50">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-md mx-4 p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-1">恢复确认</h3>
            <p class="text-sm text-gray-500 mb-4">
                从 <span id="restore-timestamp" class="font-mono text-gray-800"></span> 恢复
            </p>

            <p class="text-sm font-medium text-gray-700 mb-2">选择要恢复的组件：</p>
            <div id="restore-components" class="space-y-2 mb-4"></div>

            <div class="p-3 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-700 mb-4">
                恢复数据库将清空当前所有表，恢复 .env 将覆盖当前配置（会自动备份当前 .env）。此操作不可撤销，请确认！
            </div>

            <div id="restore-confirm-wrap" class="hidden mb-4">
                <label for="restore-confirm-phrase" class="block text-sm font-medium text-gray-700 mb-2">
                    若包含“数据库”或“环境配置”，请输入 <code class="px-1 py-0.5 rounded bg-gray-100 text-red-600">RESTORE</code> 确认
                </label>
                <input type="text"
                       id="restore-confirm-phrase"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-red-500 focus:border-red-500"
                       placeholder="输入 RESTORE">
            </div>

            <div class="flex justify-end gap-2">
                <button type="button" id="btn-restore-cancel"
                        class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg text-sm hover:bg-gray-50">
                    取消
                </button>
                <button type="button" id="btn-restore-confirm"
                        class="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-sm">
                    确认恢复
                </button>
            </div>
        </div>
    </div>
</div>

{{-- ==================== JavaScript ==================== --}}
<script>
var componentLabels = { 'database': '数据库', 'env': '环境配置', 'files': '文件' };
var csrfToken = '{{ csrf_token() }}';
var currentRestoreTimestamp = '';

function selectedRestoreComponents() {
    var checked = document.querySelectorAll('#restore-components input[name="restore_component"]:checked');
    return Array.from(checked).map(function(el) { return el.value; });
}

function restoreNeedsHighRiskConfirm(components) {
    return components.includes('database') || components.includes('env');
}

function syncRestoreConfirmUi() {
    var components = selectedRestoreComponents();
    var wrap = document.getElementById('restore-confirm-wrap');
    var input = document.getElementById('restore-confirm-phrase');

    if (restoreNeedsHighRiskConfirm(components)) {
        wrap.classList.remove('hidden');
        return;
    }

    wrap.classList.add('hidden');
    input.value = '';
}

/** 显示状态消息 */
function showStatus(message, type) {
    var el = document.getElementById('status-message');
    el.textContent = message;
    el.className = 'mx-6 mt-4 p-3 rounded-lg border text-sm '
        + (type === 'success' ? 'bg-green-50 border-green-200 text-green-700'
        : type === 'error' ? 'bg-red-50 border-red-200 text-red-700'
        : 'bg-blue-50 border-blue-200 text-blue-700');
}

/** 加载同步列表 */
function loadBackupList() {
    var loadingEl = document.getElementById('loading-state');
    var emptyEl = document.getElementById('empty-state');
    var tableEl = document.getElementById('backup-table');
    var tbodyEl = document.getElementById('backup-table-body');

    loadingEl.classList.remove('hidden');
    emptyEl.classList.add('hidden');
    tableEl.classList.add('hidden');

    fetch('{{ route("admin.plugin.storage-webdav.list") }}', { headers: { 'Accept': 'application/json' } })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        loadingEl.classList.add('hidden');
        if (!data.success) { showStatus(data.message || '获取失败', 'error'); emptyEl.classList.remove('hidden'); return; }
        var backups = data.backups || [];
        if (backups.length === 0) { emptyEl.classList.remove('hidden'); return; }

        tbodyEl.innerHTML = '';
        for (var i = 0; i < backups.length; i++) {
            var b = backups[i];
            var comps = (b.components || []).map(function(c) {
                return '<span class="inline-block text-xs px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-600 mr-1">' + (componentLabels[c] || c) + '</span>';
            }).join('') || '<span class="text-gray-400">--</span>';

            var row = document.createElement('tr');
            row.className = 'hover:bg-gray-50';

            row.innerHTML =
                '<td class="px-6 py-3 font-mono text-gray-800">' + b.timestamp + '</td>'
                + '<td class="px-6 py-3 text-gray-600">' + b.time + '</td>'
                + '<td class="px-6 py-3">' + comps + '</td>'
                + '<td class="px-6 py-3 text-right">'
                + '<button type="button" '
                + 'class="text-xs px-2.5 py-1 border border-amber-300 text-amber-700 rounded hover:bg-amber-50 transition-colors" '
                + 'onclick="openRestoreModal(\'' 
                + b.timestamp 
                + '\',' 
                + JSON.stringify(b.components).replace(/"/g, '&quot;') 
                + ')">'
                + '恢复</button>'
                + '</td>';

            tbodyEl.appendChild(row);
        }
        tableEl.classList.remove('hidden');
    })
    .catch(function(e) { loadingEl.classList.add('hidden'); emptyEl.classList.remove('hidden'); showStatus('获取失败: ' + e.message, 'error'); });
}

/** 打开恢复弹窗 */
function openRestoreModal(timestamp, components) {
    currentRestoreTimestamp = timestamp;
    document.getElementById('restore-timestamp').textContent = timestamp;

    var container = document.getElementById('restore-components');
    container.innerHTML = '';
    components.forEach(function(c) {
        var label = document.createElement('label');
        label.className = 'flex items-center gap-2 cursor-pointer';
        label.innerHTML = '<input type="checkbox" name="restore_component" value="' + c + '" checked '
            + 'class="text-indigo-600 rounded focus:ring-indigo-500">'
            + '<span class="text-sm text-gray-700">' + (componentLabels[c] || c) + '</span>';
        container.appendChild(label);
    });

    document.getElementById('restore-confirm-phrase').value = '';
    syncRestoreConfirmUi();
    container.querySelectorAll('input[name="restore_component"]').forEach(function(el) {
        el.addEventListener('change', syncRestoreConfirmUi);
    });

    document.getElementById('restore-modal').classList.remove('hidden');
}

/** 关闭恢复弹窗 */
document.getElementById('btn-restore-cancel').addEventListener('click', function() {
    document.getElementById('restore-modal').classList.add('hidden');
});

/** 确认恢复 */
document.getElementById('btn-restore-confirm').addEventListener('click', function() {
    var components = selectedRestoreComponents();
    var confirmPhrase = document.getElementById('restore-confirm-phrase').value.trim();

    if (components.length === 0) {
        showNotification('请至少选择一个要恢复的组件', 'error');
        return;
    }

    if (restoreNeedsHighRiskConfirm(components) && confirmPhrase !== 'RESTORE') {
        showNotification('恢复数据库或环境配置前，请先输入 RESTORE 确认', 'error');
        return;
    }

    var btn = this;
    btn.disabled = true; btn.textContent = '恢复中...';
    document.getElementById('restore-modal').classList.add('hidden');
    showStatus('正在恢复数据，请勿关闭页面...', 'info');

    fetch('{{ route("admin.plugin.storage-webdav.restore") }}', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken, 'Accept': 'application/json' },
        body: JSON.stringify({
            timestamp: currentRestoreTimestamp,
            components: components,
            confirm_phrase: confirmPhrase
        }),
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        showStatus(data.message || (data.success ? '恢复成功' : '恢复失败'), data.success ? 'success' : 'error');
        showNotification(data.message || (data.success ? '恢复成功' : '恢复失败'), data.success ? 'success' : 'error');
    })
    .catch(function(e) { showStatus('恢复请求失败: ' + e.message, 'error'); showNotification('恢复请求失败: ' + e.message, 'error'); })
    .finally(function() { btn.disabled = false; btn.textContent = '确认恢复'; });
});

/** 测试连接 */
document.getElementById('btn-test-connection').addEventListener('click', function() {
    var btn = this;
    var result = document.getElementById('test-connection-result');
    btn.disabled = true; btn.textContent = '测试中...';
    result.classList.remove('hidden'); result.textContent = '正在连接...'; result.className = 'text-sm text-gray-500';

    fetch('{{ route("admin.plugin.storage-webdav.test-connection") }}', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken, 'Accept': 'application/json' },
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        result.textContent = data.message;
        result.className = 'text-sm font-medium ' + (data.success ? 'text-green-600' : 'text-red-600');
        showNotification(data.message, data.success ? 'success' : 'error');
    })
    .catch(function(e) { result.textContent = '请求失败: ' + e.message; result.className = 'text-sm text-red-600'; showNotification('请求失败: ' + e.message, 'error'); })
    .finally(function() { btn.disabled = false; btn.textContent = '测试连接'; });
});

/** 立即同步 */
document.getElementById('btn-sync-now').addEventListener('click', function() {
    showConfirmDialog('确认同步', '确认执行完整同步？', '将创建一个新的远程快照，此操作可能需要几分钟', 'warning').then(function(confirmed) {
    if (!confirmed) return;
    var btn = document.getElementById('btn-sync-now');
    btn.disabled = true; btn.textContent = '同步中...';
    showStatus('正在执行完整同步，请耐心等待...', 'info');

    fetch('{{ route("admin.plugin.storage-webdav.sync") }}', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken, 'Accept': 'application/json' },
    })
    .then(function(r) { return r.json(); })
    .then(function(data) { showStatus(data.message || (data.success ? '同步成功' : '同步失败'), data.success ? 'success' : 'error'); showNotification(data.message || (data.success ? '同步成功' : '同步失败'), data.success ? 'success' : 'error'); if (data.success) loadBackupList(); })
    .catch(function(e) { showStatus('请求失败: ' + e.message, 'error'); showNotification('请求失败: ' + e.message, 'error'); })
    .finally(function() { btn.disabled = false; btn.textContent = '立即同步'; });
    });
});

/** 刷新列表 */
document.getElementById('btn-refresh-list').addEventListener('click', loadBackupList);

/** 同步开关切换：显示/隐藏频率选项 */
document.getElementById('sync-enabled-toggle').addEventListener('change', function() {
    document.getElementById('sync-frequency-options').classList.toggle('hidden', !this.checked);
});

/** 频率 radio 切换：显示/隐藏自定义 cron 输入 */
document.querySelectorAll('input[name="sync_frequency"]').forEach(function(radio) {
    radio.addEventListener('change', function() {
        document.getElementById('custom-cron-input').classList.toggle('hidden', this.value !== 'custom');
    });
});

/** 页面加载时自动获取列表 */
loadBackupList();
</script>
@endsection
