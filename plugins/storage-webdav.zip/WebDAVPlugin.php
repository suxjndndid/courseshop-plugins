<?php

use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Core\Contracts\BackupStorageInterface;
use App\Core\Contracts\BackupableInterface;
use App\Core\Admin\AdminMenu;
use Illuminate\Support\Facades\Route;

/**
 * WebDAV 同步存储插件
 *
 * 实现三个接口（implements 多接口）：
 * - PluginInterface：框架插件生命周期管理（9 个方法）
 * - BackupStorageInterface：存储能力（upload/download/list/delete）
 * - BackupableInterface：声明式同步白名单（backupPaths 声明框架核心需要同步的路径）
 *
 * 插件职责：
 * 1. 提供 WebDAV 远程存储能力（通过 WebDAVClient）
 * 2. 提供完整同步/恢复流程（通过 BackupExecutor）
 * 3. 声明框架核心同步路径（数据库 + .env）
 * 4. 注册后台管理页面（同步管理 + 同步设置）
 */
class WebDAVPlugin implements PluginInterface, BackupStorageInterface, BackupableInterface
{
    /**
     * WebDAV 客户端实例
     *
     * @var WebDAVClient|null 延迟初始化，首次调用存储方法时创建
     */
    private ?WebDAVClient $client = null;

    /**
     * 预设同步频率到 cron 表达式的映射
     *
     * @var array<string, string>
     */
    private const FREQUENCY_MAP = [
        '6h'  => '0 */6 * * *',
        '12h' => '0 */12 * * *',
        '24h' => '0 2 * * *',
    ];

    // ==================== PluginInterface 实现（9 个方法） ====================

    public function id(): string
    {
        return 'storage-webdav';
    }

    public function name(): string
    {
        return 'WebDAV 同步';
    }

    public function version(): string
    {
        return '1.0.0';
    }

    /**
     * 返回 PluginType 枚举值
     *
     * PluginType 是 PHP 8.1 Backed Enum，Storage 对应 'storage' 字符串值。
     * 框架通过此方法确定插件属于哪个槽位。
     */
    public function type(): PluginType
    {
        return PluginType::Storage;
    }

    /**
     * 注册阶段：加载依赖类、注册视图/菜单/路由/命令
     *
     * require_once 说明：
     * 因为插件类没有 namespace，不走 Composer 自动加载，
     * 需要手动 require_once 加载同目录下的辅助类。
     */
    public function register(): void
    {
        $pluginPath = dirname(__FILE__);

        // 加载插件辅助类（无 namespace，不走 autoload）
        require_once $pluginPath . '/WebDAVClient.php';
        require_once $pluginPath . '/BackupExecutor.php';
        require_once $pluginPath . '/Controllers/SettingsController.php';
        require_once $pluginPath . '/Controllers/SyncController.php';

        // 注册视图命名空间
        app('view')->addNamespace('storage-webdav', $pluginPath . '/views');

        // 注册后台菜单
        AdminMenu::add([
            'group' => \App\Core\Admin\AdminMenu::GROUP_STORAGE,
            'items' => [
                [
                    'label' => '同步管理',
                    'icon' => 'server',
                    'route' => 'admin.plugin.storage-webdav.settings',
                    'order' => 60,
                ],
            ],
        ]);

        // 注册 Artisan 命令（交互式恢复）
        require_once $pluginPath . '/SyncRestoreCommand.php';
        if (app()->runningInConsole()) {
            \Illuminate\Console\Application::starting(function ($artisan) {
                $artisan->resolve(\SyncRestoreCommand::class);
            });
        }

        // 加载路由文件（Controller 类路由，无闭包）
        require $pluginPath . '/routes.php';
    }

    /**
     * 启动阶段：注册自动同步定时任务
     *
     * 支持两种调度模式：
     * 1. 预设频率（6h/12h/24h）映射为固定 cron 表达式
     * 2. 自定义 cron 表达式（sync_frequency = 'custom' 时使用 sync_cron）
     *
     * 通过 PluginContext::scheduler() 注册 cron 任务，
     * 框架在所有插件 boot 完成后统一注入 Laravel Schedule。
     */
    public function boot(): void
    {
        $ctx = plugin_context($this->id());

        // 检查是否启用自动同步（DB 中可能是 1/0 或 true/false 字符串，统一转 bool）
        $syncEnabledRaw = $ctx->config('sync_enabled', false);
        $syncEnabled = filter_var($syncEnabledRaw, FILTER_VALIDATE_BOOLEAN);
        if (!$syncEnabled) {
            // 属于正常分支，记录为 info 并带上原始值，避免被误判为错误日志
            $ctx->logger()->info('自动同步未启用，跳过注册定时任务', ['raw' => $syncEnabledRaw]);
            return;
        }

        // 根据频率配置解析 cron 表达式
        $frequency = $ctx->config('sync_frequency', '24h');
        $cronExpression = self::FREQUENCY_MAP[$frequency]
            ?? $ctx->config('sync_cron', '0 2 * * *');

        $ctx->scheduler()->cron(
            $cronExpression,
            function () {
                $ctx = plugin_context('storage-webdav');
                $url = $ctx->config('webdav_url', '');
                if (empty($url)) {
                    $ctx->logger()->warning('自动同步跳过：WebDAV URL 未配置');
                    return;
                }

                $client = new \WebDAVClient(
                    $url,
                    $ctx->config('webdav_username', ''),
                    $ctx->config('webdav_password', ''),
                    $ctx->config('webdav_path', '/backup')
                );
                $executor = new \BackupExecutor($client);
                $result = $executor->syncFull();

                $ctx->logger()->info('自动同步' . ($result['success'] ? '成功' : '失败'), [
                    'message' => $result['message'] ?? '',
                ]);
            },
            'WebDAV 自动同步'
        );
    }

    /**
     * 卸载时清理后台菜单
     *
     * AdminMenu::remove() 按路由名称移除菜单项。
     * 数据库迁移回滚由 PluginMigrator 单独处理。
     */
    public function uninstall(): void
    {
        AdminMenu::remove('admin.plugin.storage-webdav.settings');
    }

    /**
     * 插件默认配置（plugin_config 三层合并的最低优先级）
     *
     * 这些值在数据库和 .env 都没有设置时作为兜底。
     * 用户通过后台设置页面修改后，值会写入 settings 表（最高优先级）。
     */
    public function config(): array
    {
        return [
            'webdav_url' => '',
            'webdav_username' => '',
            'webdav_password' => '',
            'webdav_path' => '/backup',
            'keep_count' => '3',
            'sync_enabled' => false,       // 是否启用自动同步
            'sync_frequency' => '24h',     // 预设频率：6h / 12h / 24h / custom
            'sync_cron' => '0 2 * * *',   // 自定义 cron（仅 frequency=custom 时使用）
        ];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }

    // ==================== BackupStorageInterface 实现（4 个方法） ====================

    /**
     * 上传文件到 WebDAV 远程存储
     *
     * @param string $localPath 本地文件绝对路径
     * @param string $remotePath 远程存储相对路径（如 backups/20260324_120000/database.sql.zip）
     * @return bool 上传是否成功
     */
    public function upload(string $localPath, string $remotePath): bool
    {
        $result = $this->getClient()->upload($localPath, $remotePath);
        return $result['success'];
    }

    /**
     * 从 WebDAV 远程存储下载文件
     *
     * @param string $remotePath 远程存储相对路径
     * @param string $localPath 本地保存绝对路径
     * @return bool 下载是否成功
     */
    public function download(string $remotePath, string $localPath): bool
    {
        $result = $this->getClient()->download($remotePath, $localPath);
        return $result['success'];
    }

    /**
     * 列出远程目录中的文件/子目录
     *
     * 使用 WebDAV PROPFIND 方法列出目录内容。
     *
     * @param string $directory 远程目录路径
     * @return array 文件/目录名称列表
     */
    public function list(string $directory): array
    {
        $result = $this->getClient()->listDirectory($directory);
        return $result['success'] ? ($result['dirs'] ?? []) : [];
    }

    /**
     * 删除远程文件或目录
     *
     * @param string $remotePath 远程路径
     * @return bool 删除是否成功
     */
    public function delete(string $remotePath): bool
    {
        try {
            $this->getClient()->delete($remotePath);
            return true;
        } catch (\Exception $e) {
            plugin_context($this->id())->logger()->error('WebDAV 删除失败', [
                'path' => $remotePath,
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }

    // ==================== BackupableInterface 实现 ====================

    /**
     * 声明框架核心需要同步的路径
     *
     * BackupableInterface 是声明式白名单：
     * 同步插件不能自己决定同步什么，每个模块声明自己需要同步的路径。
     * 这里声明框架核心的两个同步项：数据库和环境配置。
     *
     * @return array 同步项列表
     */
    public function backupPaths(): array
    {
        return [
            [
                'label' => '数据库',
                'path' => null,           // 数据库没有文件路径，走 mysqldump
                'type' => 'database',     // 特殊类型标记
                'sensitive' => true,      // 敏感数据
            ],
            [
                'label' => '环境配置',
                'path' => '.env',         // 相对项目根目录
                'type' => null,
                'sensitive' => true,      // .env 包含密钥等敏感信息
            ],
        ];
    }

    // ==================== 私有辅助方法 ====================

    /**
     * 获取 WebDAV 客户端实例（延迟初始化）
     *
     * 使用 null 合并赋值运算符（??=）：
     * 如果 $this->client 为 null，则创建新实例并赋值；否则返回已有实例。
     * 用于 BackupStorageInterface 方法，避免每次调用都创建新的 HTTP 客户端。
     */
    private function getClient(): WebDAVClient
    {
        return $this->client ??= $this->createClient();
    }

    /**
     * 创建 WebDAV 客户端（从 PluginContext 读取配置）
     */
    private function createClient(): WebDAVClient
    {
        $ctx = plugin_context('storage-webdav');
        return new WebDAVClient(
            $ctx->config('webdav_url', ''),
            $ctx->config('webdav_username', ''),
            $ctx->config('webdav_password', ''),
            $ctx->config('webdav_path', '/backup')
        );
    }
}
