<?php

use Illuminate\Console\Command;

/**
 * WebDAV 同步恢复命令（交互式）
 *
 * 列出远程可用的同步快照，用户选择一个时间点和要恢复的组件，
 * 确认后执行恢复操作。
 *
 * 用法：php artisan sync:restore
 *
 * 注意：此命令由 WebDAVPlugin::register() 注册，
 * 不走 Laravel 默认的 Commands 目录自动发现。
 */
class SyncRestoreCommand extends Command
{
    protected $signature = 'sync:restore';
    protected $description = '从 WebDAV 远程同步快照恢复数据（交互式选择）';

    public function handle(): int
    {
        $ctx = plugin_context('storage-webdav');
        $url = $ctx->config('webdav_url', '');

        if (empty($url)) {
            $this->error('WebDAV URL 未配置，请先在后台设置页面配置连接信息');
            return 1;
        }

        // 创建客户端和执行器
        $client = new \WebDAVClient(
            $url,
            $ctx->config('webdav_username', ''),
            $ctx->config('webdav_password', ''),
            $ctx->config('webdav_path', '/backup')
        );
        $executor = new \BackupExecutor($client);

        // 获取远程同步列表
        $this->info('正在获取远程同步列表...');
        $backups = $executor->getBackupList();

        if (empty($backups)) {
            $this->warn('远程没有可用的同步快照');
            return 0;
        }

        // 显示可用快照列表
        $this->table(
            ['#', '时间戳', '同步时间', '包含组件'],
            array_map(function ($b, $i) {
                return [
                    $i + 1,
                    $b['timestamp'],
                    $b['time'],
                    implode(', ', $b['components']),
                ];
            }, $backups, array_keys($backups))
        );

        // 选择快照（输入序号）
        $choice = $this->ask('请输入要恢复的快照序号（1-' . count($backups) . '）');
        $index = (int) $choice - 1;

        if ($index < 0 || $index >= count($backups)) {
            $this->error('无效的序号');
            return 1;
        }

        $selected = $backups[$index];
        $this->info("已选择: {$selected['timestamp']} ({$selected['time']})");

        // 选择恢复组件
        $availableComponents = $selected['components'];
        if (empty($availableComponents)) {
            $this->warn('该快照没有可恢复的组件');
            return 0;
        }

        $componentLabels = ['database' => '数据库', 'env' => '环境配置', 'files' => '文件'];
        $this->line('');
        $this->info('可恢复的组件：');
        foreach ($availableComponents as $i => $c) {
            $this->line('  [' . ($i + 1) . '] ' . ($componentLabels[$c] ?? $c));
        }

        $componentChoices = $this->ask('请输入要恢复的组件序号（逗号分隔，如 1,2；输入 all 恢复全部）');

        if (strtolower(trim($componentChoices)) === 'all') {
            $selectedComponents = $availableComponents;
        } else {
            $selectedComponents = [];
            foreach (explode(',', $componentChoices) as $num) {
                $num = (int) trim($num) - 1;
                if (isset($availableComponents[$num])) {
                    $selectedComponents[] = $availableComponents[$num];
                }
            }
        }

        if (empty($selectedComponents)) {
            $this->error('未选择任何组件');
            return 1;
        }

        $this->line('');
        $this->warn('即将恢复以下组件：' . implode(', ', array_map(fn($c) => $componentLabels[$c] ?? $c, $selectedComponents)));

        if (in_array('database', $selectedComponents)) {
            $this->warn('⚠ 恢复数据库将清空当前所有表！');
        }
        if (in_array('env', $selectedComponents)) {
            $this->warn('⚠ 恢复 .env 将覆盖当前环境配置（会自动备份当前 .env）');
        }

        if ($this->requiresHighRiskConfirmation($selectedComponents)) {
            $phrase = trim((string) $this->ask('恢复数据库或环境配置前，请输入 RESTORE 确认'));

            if ($phrase !== 'RESTORE') {
                $this->error('未输入正确确认短语，已取消恢复');
                return 1;
            }
        }

        if (!$this->confirm('确认执行恢复？此操作不可撤销')) {
            $this->info('已取消');
            return 0;
        }

        // 执行恢复
        $this->info('正在恢复...');
        $result = $executor->restoreFromBackup($selected['timestamp'], $selectedComponents);

        if ($result['success']) {
            $this->info('✓ ' . ($result['message'] ?? '恢复成功'));
        } else {
            $this->error('✗ ' . ($result['message'] ?? '恢复失败'));
        }

        // 显示详细结果
        if (!empty($result['details'])) {
            foreach ($result['details'] as $comp => $detail) {
                $status = ($detail['success'] ?? false) ? '✓' : '✗';
                $this->line("  {$status} " . ($componentLabels[$comp] ?? $comp) . ': ' . ($detail['message'] ?? ''));
            }
        }

        return $result['success'] ? 0 : 1;
    }

    /**
     * 数据库和 .env 恢复都会直接覆盖当前运行态，需要额外确认。
     */
    private function requiresHighRiskConfirmation(array $components): bool
    {
        return in_array('database', $components, true) || in_array('env', $components, true);
    }
}
