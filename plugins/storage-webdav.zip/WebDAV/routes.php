<?php

/**
 * WebDAV 插件路由定义
 *
 * 所有路由集中注册，指向 Controller 方法，无闭包。
 * 由 WebDAVPlugin::register() 中 require 加载。
 */

use Illuminate\Support\Facades\Route;

Route::prefix('admin')
    ->middleware('admin.auth')
    ->group(function () {
        // 设置页
        Route::get('/plugin/storage-webdav/settings', [\WebDAV\Controllers\SettingsController::class, 'index'])
            ->name('admin.plugin.storage-webdav.settings');

        Route::post('/plugin/storage-webdav/settings', [\WebDAV\Controllers\SettingsController::class, 'save'])
            ->name('admin.plugin.storage-webdav.settings.save');

        // AJAX 操作
        Route::post('/plugin/storage-webdav/sync', [\WebDAV\Controllers\SyncController::class, 'sync'])
            ->name('admin.plugin.storage-webdav.sync');

        Route::post('/plugin/storage-webdav/restore', [\WebDAV\Controllers\SyncController::class, 'restore'])
            ->name('admin.plugin.storage-webdav.restore');

        Route::post('/plugin/storage-webdav/test-connection', [\WebDAV\Controllers\SyncController::class, 'testConnection'])
            ->name('admin.plugin.storage-webdav.test-connection');

        Route::get('/plugin/storage-webdav/list', [\WebDAV\Controllers\SyncController::class, 'list'])
            ->name('admin.plugin.storage-webdav.list');
    });
