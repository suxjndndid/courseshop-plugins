<?php

/**
 * 备份日志表迁移
 *
 * 记录每次备份/恢复操作的结果，用于后台查看历史。
 *
 * 匿名类迁移（return new class extends Migration）：
 * PHP 7.0+ 特性，避免迁移类名冲突。Laravel 自动为每个文件创建独立的匿名类实例。
 */

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('backup_logs', function (Blueprint $table) {
            $table->id()->comment('日志ID，主键');
            $table->string('action', 20)->comment('操作类型：backup/restore');
            $table->string('status', 20)->comment('操作状态：success/failure');
            $table->json('components')->nullable()->comment('涉及的组件列表（JSON数组，如 ["database","env","files"]）');
            $table->text('message')->nullable()->comment('操作结果描述');
            $table->decimal('duration_seconds', 8, 2)->nullable()->comment('操作耗时（秒）');
            $table->timestamp('created_at')->nullable()->comment('记录时间');

            // 索引：按操作类型和时间查询
            $table->index('action', 'idx_backup_logs_action');
            $table->index('created_at', 'idx_backup_logs_created_at');
        });

        // 表注释仅在 MySQL 下生效，SQLite 不支持 ALTER TABLE COMMENT 语法
        if (DB::getDriverName() === 'mysql') {
            DB::statement("ALTER TABLE `backup_logs` COMMENT = '备份操作日志表 — storage-webdav 插件'");
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('backup_logs');
    }
};
