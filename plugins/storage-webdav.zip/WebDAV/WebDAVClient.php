<?php

use Illuminate\Support\Facades\Http;

/**
 * WebDAV 客户端
 *
 * 封装所有 WebDAV HTTP 操作（PUT/GET/PROPFIND/DELETE/MKCOL）。
 * 从老项目 WangKeLava/app/Services/Admin/BackupService.php 提取，
 * 将分散在 BackupService 中的 WebDAV 操作集中到独立类。
 *
 * 特点：
 * - 使用 Laravel Http facade（底层 Guzzle）
 * - HTTP Basic Auth 认证
 * - verify=false 跳过 SSL 证书验证（自签名证书场景）
 * - 所有操作记录到 business 日志通道
 */
class WebDAVClient
{
    private string $url;
    private string $username;
    private string $password;
    private string $basePath;

    /**
     * @param string $url WebDAV 服务器地址（如 https://dav.example.com）
     * @param string $username 认证用户名
     * @param string $password 认证密码
     * @param string $basePath 基础路径前缀（如 /backup）
     */
    public function __construct(string $url, string $username, string $password, string $basePath)
    {
        $this->url = rtrim($url, '/');
        $this->username = $username;
        $this->password = $password;
        $this->basePath = trim($basePath, '/');
    }

    /**
     * 上传文件到 WebDAV（HTTP PUT）
     *
     * 使用文件流（fopen）而非一次性读入内存，支持大文件上传。
     * 上传前会自动创建远程目录（MKCOL）。
     *
     * @param string $localFile 本地文件绝对路径
     * @param string $remotePath 远程相对路径（如 backups/20260324_120000/database.sql.zip）
     * @return array ['success' => bool, 'message' => string]
     */
    public function upload(string $localFile, string $remotePath): array
    {
        if (empty($this->url)) {
            return ['success' => false, 'message' => 'WebDAV URL 未配置'];
        }

        // 自动创建远程目录
        $remoteDir = dirname($remotePath);
        $this->createDirectory($remoteDir);

        $fullRemotePath = $this->url . '/' . $this->basePath . '/' . $remotePath;

        try {
            // fopen 返回文件流资源，Http 客户端会以流式方式发送
            $fileStream = fopen($localFile, 'r');
            if ($fileStream === false) {
                return ['success' => false, 'message' => '无法打开本地文件: ' . $localFile];
            }

            /**
             * withBasicAuth()：添加 HTTP Basic Authentication 头
             * withOptions(['verify' => false])：跳过 SSL 证书验证
             * send('PUT', ...)：发送 HTTP PUT 请求（WebDAV 上传用 PUT）
             */
            $response = Http::withBasicAuth($this->username, $this->password)
                ->withOptions([
                    'verify' => false,
                    'body' => $fileStream,
                ])
                ->withHeaders(['Content-Type' => 'application/octet-stream'])
                ->send('PUT', $fullRemotePath);

            // 确保文件流被关闭，is_resource() 检查是否仍为有效资源
            if (is_resource($fileStream)) {
                fclose($fileStream);
            }

            if ($response->successful()) {
                plugin_context('storage-webdav')->logger()->info('WebDAV 上传成功', ['path' => $remotePath]);
                return ['success' => true, 'message' => '上传成功', 'path' => $fullRemotePath];
            }

            plugin_context('storage-webdav')->logger()->error('WebDAV 上传失败', [
                'http_code' => $response->status(),
                'path' => $remotePath,
                'body' => $response->body(),
            ]);
            return ['success' => false, 'message' => '上传失败: HTTP ' . $response->status()];
        } catch (\Exception $e) {
            plugin_context('storage-webdav')->logger()->error('WebDAV 上传异常', [
                'path' => $remotePath,
                'error' => $e->getMessage(),
            ]);
            return ['success' => false, 'message' => '上传失败: ' . $e->getMessage()];
        }
    }

    /**
     * 从 WebDAV 下载文件（HTTP GET + sink）
     *
     * sink 选项让 Guzzle 将响应体直接写入文件，不占用 PHP 内存。
     * 适合下载大型备份文件。
     *
     * @param string $remotePath 远程相对路径
     * @param string $localFile 本地保存绝对路径
     * @return array ['success' => bool, 'message' => string]
     */
    public function download(string $remotePath, string $localFile): array
    {
        if (empty($this->url)) {
            return ['success' => false, 'message' => 'WebDAV URL 未配置'];
        }

        $fullRemotePath = $this->url . '/' . $this->basePath . '/' . $remotePath;

        try {
            /**
             * sink 选项：将 HTTP 响应体直接写入指定文件路径
             * 不会将整个响应加载到内存，适合大文件下载
             */
            $response = Http::withBasicAuth($this->username, $this->password)
                ->withOptions([
                    'verify' => false,
                    'timeout' => 300,
                    'sink' => $localFile,
                ])
                ->get($fullRemotePath);

            if ($response->successful()) {
                if (!file_exists($localFile) || filesize($localFile) === 0) {
                    return ['success' => false, 'message' => '下载文件为空: ' . $remotePath];
                }
                plugin_context('storage-webdav')->logger()->info('WebDAV 下载成功', ['path' => $remotePath]);
                return ['success' => true, 'message' => '下载成功'];
            }

            return ['success' => false, 'message' => '下载失败: HTTP ' . $response->status()];
        } catch (\Exception $e) {
            plugin_context('storage-webdav')->logger()->error('WebDAV 下载异常', [
                'path' => $remotePath,
                'error' => $e->getMessage(),
            ]);
            return ['success' => false, 'message' => '下载失败: ' . $e->getMessage()];
        }
    }

    /**
     * 列出 WebDAV 目录内容（PROPFIND Depth=1）
     *
     * PROPFIND 是 WebDAV 扩展的 HTTP 方法，用于查询资源属性。
     * Depth=1 表示列出当前目录及其直接子项（不递归）。
     * 返回的 XML 响应通过 parseDirectoryList() 解析。
     *
     * @param string $remotePath 远程目录相对路径
     * @return array ['success' => bool, 'dirs' => array]
     */
    public function listDirectory(string $remotePath): array
    {
        if (empty($this->url)) {
            return ['success' => false, 'message' => 'WebDAV URL 未配置', 'dirs' => []];
        }

        $fullPath = $this->url . '/' . $this->basePath . '/' . ltrim($remotePath, '/');

        try {
            $response = Http::withBasicAuth($this->username, $this->password)
                ->withOptions(['verify' => false, 'timeout' => 10])
                ->withHeaders([
                    'Depth' => '1',
                    'Content-Type' => 'application/xml',
                ])
                ->send('PROPFIND', $fullPath);

            if ($response->successful() || $response->status() === 207) {
                $dirs = $this->parseDirectoryList($response->body());
                return ['success' => true, 'dirs' => $dirs];
            }

            return ['success' => false, 'message' => '列目录失败: HTTP ' . $response->status(), 'dirs' => []];
        } catch (\Exception $e) {
            plugin_context('storage-webdav')->logger()->error('WebDAV 列目录异常', [
                'path' => $remotePath,
                'error' => $e->getMessage(),
            ]);
            return ['success' => false, 'message' => '列目录失败: ' . $e->getMessage(), 'dirs' => []];
        }
    }

    /**
     * 删除 WebDAV 远程文件或目录（HTTP DELETE）
     *
     * WebDAV DELETE 会递归删除目录及其所有内容。
     *
     * @param string $remotePath 远程路径（文件或目录）
     */
    public function delete(string $remotePath): void
    {
        if (empty($this->url)) {
            return;
        }

        $fullPath = $this->url . '/' . $this->basePath . '/' . ltrim($remotePath, '/');

        try {
            Http::withBasicAuth($this->username, $this->password)
                ->withOptions(['verify' => false])
                ->send('DELETE', $fullPath);

            plugin_context('storage-webdav')->logger()->info('WebDAV 删除成功', ['path' => $remotePath]);
        } catch (\Exception $e) {
            plugin_context('storage-webdav')->logger()->warning('WebDAV 删除失败', [
                'path' => $remotePath,
                'error' => $e->getMessage(),
            ]);
        }
    }

    /**
     * 测试 WebDAV 连接
     *
     * 分两步测试：
     * 1. PROPFIND Depth=0 测试基础 URL 连通性和认证（如 /dav）
     * 2. 检查 basePath 是否存在（如 /dav/backup_cs），不存在则自动 MKCOL 创建
     *
     * @return array ['success' => bool, 'message' => string]
     */
    public function testConnection(): array
    {
        if (empty($this->url)) {
            return ['success' => false, 'message' => 'WebDAV URL 未配置'];
        }

        try {
            // 第一步：测试基础 URL 连通性 + 认证
            $response = Http::withBasicAuth($this->username, $this->password)
                ->withOptions(['verify' => false, 'timeout' => 10])
                ->withHeaders(['Depth' => '0'])
                ->send('PROPFIND', $this->url);

            if (!$response->successful() && $response->status() !== 207) {
                $code = $response->status();
                $hint = match ($code) {
                    401 => '用户名或密码错误',
                    403 => '无访问权限',
                    default => 'HTTP ' . $code,
                };
                return ['success' => false, 'message' => "连接失败: {$hint}"];
            }

            // 第二步：检查 basePath 是否存在
            if (!empty($this->basePath)) {
                $pathUrl = $this->url . '/' . $this->basePath;
                $pathResponse = Http::withBasicAuth($this->username, $this->password)
                    ->withOptions(['verify' => false, 'timeout' => 10])
                    ->withHeaders(['Depth' => '0'])
                    ->send('PROPFIND', $pathUrl);

                if (!$pathResponse->successful() && $pathResponse->status() !== 207) {
                    // 路径不存在，尝试自动创建
                    $mkcolResponse = Http::withBasicAuth($this->username, $this->password)
                        ->withOptions(['verify' => false, 'timeout' => 10])
                        ->send('MKCOL', $pathUrl);

                    if ($mkcolResponse->successful() || $mkcolResponse->status() === 201) {
                        return ['success' => true, 'message' => '连接成功（远程目录已自动创建）'];
                    }

                    return ['success' => false, 'message' => "连接成功，但远程路径 /{$this->basePath} 不存在且无法自动创建（HTTP {$mkcolResponse->status()}）"];
                }
            }

            return ['success' => true, 'message' => '连接成功'];
        } catch (\Exception $e) {
            return ['success' => false, 'message' => '连接失败: ' . $e->getMessage()];
        }
    }

    /**
     * 递归创建 WebDAV 远程目录（MKCOL）
     *
     * MKCOL 是 WebDAV 的创建目录方法。
     * 按路径层级逐级创建，类似 mkdir -p。
     * 对已存在的目录 MKCOL 会返回 405，直接忽略即可。
     *
     * @param string $dir 相对路径（如 backups/20260324_120000）
     */
    public function createDirectory(string $dir): void
    {
        if (empty($this->url)) {
            return;
        }

        // array_filter 去除空字符串（首尾斜杠 split 产生的空元素）
        $parts = array_filter(explode('/', $dir));
        $currentPath = $this->url . '/' . $this->basePath;

        foreach ($parts as $part) {
            $currentPath .= '/' . $part;

            try {
                Http::withBasicAuth($this->username, $this->password)
                    ->withOptions(['verify' => false])
                    ->send('MKCOL', $currentPath);
            } catch (\Exception $e) {
                // MKCOL 对已存在的目录会返回 405 Method Not Allowed，忽略即可
            }
        }
    }

    /**
     * 解析 PROPFIND XML 响应中的时间戳目录列表
     *
     * WebDAV PROPFIND 返回 XML 格式的目录内容，
     * 使用正则匹配 D:href 标签中的路径，
     * 提取符合时间戳格式（YYYYMMDD_HHMMSS）的目录名。
     *
     * @param string $xml PROPFIND 响应的 XML 字符串
     * @return array 时间戳目录名列表（如 ['20260324_120000', '20260323_020000']）
     */
    public function parseDirectoryList(string $xml): array
    {
        $dirs = [];

        /**
         * 正则说明：
         * <(?:D|d):href> — 匹配 <D:href> 或 <d:href>（WebDAV 命名空间前缀大小写不固定）
         * ([^<]+) — 捕获 href 内容（URL 路径）
         * (?:...) — 非捕获组，只分组不捕获
         * /i — 大小写不敏感
         */
        preg_match_all('/<(?:D|d):href>([^<]+)<\/(?:D|d):href>/i', $xml, $matches);

        if (!empty($matches[1])) {
            foreach ($matches[1] as $href) {
                $decoded = urldecode($href);
                // 提取路径末尾的时间戳目录名（格式：YYYYMMDD_HHMMSS）
                if (preg_match('/(\d{8}_\d{6})\/?$/', rtrim($decoded, '/'), $m)) {
                    $dirs[] = $m[1];
                }
            }
        }

        // array_unique 去重（PROPFIND 可能返回重复条目）
        return array_unique($dirs);
    }
}
