<?php

namespace WebDAV\Controllers;

use App\Models\Setting;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;

/**
 * WebDAV 后台设置控制器
 */
class SettingsController
{
    public function index()
    {
        $settings = Setting::getGroup('storage-webdav');
        return view('storage-webdav::settings', ['settings' => $settings]);
    }

    public function save(Request $request)
    {
        $request->validate([
            'webdav_url'      => 'required|url|max:500',
            'webdav_username' => 'required|string|max:100',
            'webdav_path'     => 'required|string|max:255',
            'keep_count'      => 'required|integer|min:1|max:100',
            'sync_frequency'  => 'required|in:6h,12h,24h,custom',
        ]);

        $settings = [
            'webdav_url'      => $request->input('webdav_url'),
            'webdav_username' => $request->input('webdav_username'),
            'webdav_path'     => $request->input('webdav_path'),
            'keep_count'      => $request->input('keep_count'),
            'sync_enabled'    => $request->boolean('sync_enabled'),
            'sync_frequency'  => $request->input('sync_frequency'),
        ];

        // 自定义 cron 模式下保存表达式
        if ($request->input('sync_frequency') === 'custom') {
            $request->validate(['sync_cron' => 'required|string|max:100']);
            $settings['sync_cron'] = $request->input('sync_cron');
        }

        Setting::setGroup('storage-webdav', $settings);

        // webdav_password 是敏感字段，只在有输入时更新
        if ($request->filled('webdav_password')) {
            Setting::setGroup('storage-webdav', [
                'webdav_password' => $request->input('webdav_password'),
            ]);
        }

        app(ActivityLogService::class)->log('setting', '更新 WebDAV 同步配置');

        return redirect()->route('admin.plugin.storage-webdav.settings')
            ->with('success', 'WebDAV 同步配置已保存');
    }
}
