<?php

namespace WebDAV\Controllers;

use App\Services\ActivityLogService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * WebDAV 同步操作控制器
 *
 * 处理同步执行、恢复、测试连接、列表查询等 AJAX 请求。
 */
class SyncController
{
    /**
     * 触发完整同步
     */
    public function sync(): JsonResponse
    {
        try {
            $client = $this->createClient();
            $executor = new \BackupExecutor($client);
            $result = $executor->syncFull();

            app(ActivityLogService::class)->log(
                'sync',
                $result['success'] ? '完整同步成功' : '同步失败: ' . ($result['message'] ?? '未知错误')
            );

            return response()->json($result);
        } catch (\Exception $e) {
            plugin_context('storage-webdav')->logger()->error('同步执行异常', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => '同步执行异常: ' . $e->getMessage(),
            ]);
        }
    }

    /**
     * 恢复备份
     */
    public function restore(Request $request): JsonResponse
    {
        $request->validate([
            'timestamp'    => 'required|string|regex:/^\d{8}_\d{6}$/',
            'components'   => 'required|array|min:1',
            'components.*' => 'in:database,env,files',
        ]);

        try {
            $client = $this->createClient();
            $executor = new \BackupExecutor($client);
            $result = $executor->restoreFromBackup(
                $request->input('timestamp'),
                $request->input('components')
            );

            app(ActivityLogService::class)->log(
                'restore',
                $result['success'] ? '恢复成功' : '恢复失败: ' . ($result['message'] ?? '未知错误')
            );

            return response()->json($result);
        } catch (\Exception $e) {
            plugin_context('storage-webdav')->logger()->error('恢复执行异常', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => '恢复执行异常: ' . $e->getMessage(),
            ]);
        }
    }

    /**
     * 测试 WebDAV 连接
     */
    public function testConnection(): JsonResponse
    {
        try {
            $client = $this->createClient();
            return response()->json($client->testConnection());
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => '连接测试异常: ' . $e->getMessage(),
            ]);
        }
    }

    /**
     * 列出同步记录
     */
    public function list(): JsonResponse
    {
        try {
            $client = $this->createClient();
            $executor = new \BackupExecutor($client);
            return response()->json([
                'success' => true,
                'backups' => $executor->getBackupList(),
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => '获取同步列表失败: ' . $e->getMessage(),
            ]);
        }
    }

    /**
     * 创建 WebDAV 客户端（每次请求新建，确保配置最新）
     */
    private function createClient(): \WebDAVClient
    {
        $ctx = plugin_context('storage-webdav');
        return new \WebDAVClient(
            $ctx->config('webdav_url', ''),
            $ctx->config('webdav_username', ''),
            $ctx->config('webdav_password', ''),
            $ctx->config('webdav_path', '/backup')
        );
    }
}
