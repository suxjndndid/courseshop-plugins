<?php

use NotificationTelegram\Controllers\SettingsController;
use Illuminate\Support\Facades\Route;

admin_route_group(function () {
    Route::get('/plugin/notification-telegram', [SettingsController::class, 'index'])
        ->name('admin.plugin.notification-telegram');
    Route::post('/plugin/notification-telegram', [SettingsController::class, 'save'])
        ->name('admin.plugin.notification-telegram.save');
});
