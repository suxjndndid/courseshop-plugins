<?php

use Illuminate\Support\Facades\Route;

Route::prefix('admin')->middleware('admin.auth')->group(function () {
    Route::get('/plugin/notification-telegram', [\NotificationTelegram\Controllers\SettingsController::class, 'index'])
        ->name('admin.plugin.notification-telegram');
    Route::post('/plugin/notification-telegram', [\NotificationTelegram\Controllers\SettingsController::class, 'save'])
        ->name('admin.plugin.notification-telegram.save');
});
