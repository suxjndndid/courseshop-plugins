@extends('admin.layouts.app')

@section('title', 'Telegram 机器人设置')

@section('content')
<div class="container mx-auto px-4 py-6">
    <div class="bg-white shadow-md rounded-lg p-6">
        <h2 class="text-2xl font-bold mb-6">Telegram 机器人设置</h2>

        <form action="{{ route('admin.plugin.notification-telegram.save') }}" method="POST">
            @csrf
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="TG_BOT_TOKEN">
                        Bot Token
                    </label>
                    <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                           id="TG_BOT_TOKEN" name="TG_BOT_TOKEN" type="text" value="{{ $settings['TG_BOT_TOKEN'] ?? '' }}" required>
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="TG_USER_ID">
                        User ID / Chat ID
                    </label>
                    <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                           id="TG_USER_ID" name="TG_USER_ID" type="text" value="{{ $settings['TG_USER_ID'] ?? '' }}" required>
                </div>
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="TG_API_HOST">
                    API Host (可选)
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="TG_API_HOST" name="TG_API_HOST" type="text" value="{{ $settings['TG_API_HOST'] ?? '' }}" placeholder="https://api.telegram.org">
                <p class="text-xs text-gray-500 mt-1">留空则使用官方 API 地址</p>
            </div>

            <div class="bg-gray-50 p-4 rounded mb-6">
                <h3 class="text-sm font-bold mb-3 text-gray-600">代理设置 (可选)</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-gray-700 text-xs font-bold mb-1" for="TG_PROXY_HOST">代理地址</label>
                        <input class="shadow appearance-none border rounded w-full py-1 px-2 text-gray-700 text-sm leading-tight" id="TG_PROXY_HOST" name="TG_PROXY_HOST" type="text" value="{{ $settings['TG_PROXY_HOST'] ?? '' }}" placeholder="127.0.0.1">
                    </div>
                    <div>
                        <label class="block text-gray-700 text-xs font-bold mb-1" for="TG_PROXY_PORT">代理端口</label>
                        <input class="shadow appearance-none border rounded w-full py-1 px-2 text-gray-700 text-sm leading-tight" id="TG_PROXY_PORT" name="TG_PROXY_PORT" type="text" value="{{ $settings['TG_PROXY_PORT'] ?? '' }}" placeholder="7890">
                    </div>
                    <div>
                        <label class="block text-gray-700 text-xs font-bold mb-1" for="TG_PROXY_AUTH">代理验证 (user:pass)</label>
                        <input class="shadow appearance-none border rounded w-full py-1 px-2 text-gray-700 text-sm leading-tight" id="TG_PROXY_AUTH" name="TG_PROXY_AUTH" type="text" value="{{ $settings['TG_PROXY_AUTH'] ?? '' }}">
                    </div>
                </div>
            </div>

            <div class="mb-6 rounded-md border border-blue-100 bg-blue-50 p-4 text-sm text-blue-800">
                分发规则已统一迁移到后台“系统 → 通知分发”，这里仅维护 Telegram 机器人的发送参数。
            </div>

            <div class="flex items-center justify-between">
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="submit">
                    保存设置
                </button>
            </div>
        </form>
    </div>
</div>
@endsection
