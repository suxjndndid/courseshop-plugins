<?php

namespace NotificationTelegram\Controllers;

use App\Models\Setting;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;

class SettingsController
{
    public function index()
    {
        $settings = Setting::getGroup('notification-telegram');
        return view('notification-telegram::settings', ['settings' => $settings]);
    }

    public function save(Request $request)
    {
        $request->validate([
            'TG_BOT_TOKEN' => 'required|string',
            'TG_USER_ID' => 'required|string',
        ]);
        
        Setting::setGroup('notification-telegram', [
            'TG_BOT_TOKEN' => $request->input('TG_BOT_TOKEN'),
            'TG_USER_ID' => $request->input('TG_USER_ID'),
            'TG_API_HOST' => $request->input('TG_API_HOST'),
            'TG_PROXY_HOST' => $request->input('TG_PROXY_HOST'),
            'TG_PROXY_PORT' => $request->input('TG_PROXY_PORT'),
            'TG_PROXY_AUTH' => $request->input('TG_PROXY_AUTH'),
        ]);
        Setting::where('setting_group', 'notification-telegram')
            ->whereIn('key', ['enabled_events', 'route_use_legacy_supports'])
            ->delete();

        app(ActivityLogService::class)->log('setting', '更新 Telegram 机器人配置');

        return redirect()->route('admin.plugin.notification-telegram')->with('success', 'Telegram 机器人配置已保存');
    }
}
