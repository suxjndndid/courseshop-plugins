<?php

use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Core\Contracts\NotificationChannelInterface;
use App\Core\Notification\Notification;
use App\Core\Admin\AdminMenu;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Http;

class TelegramPlugin implements PluginInterface, NotificationChannelInterface
{
    public function id(): string { return 'notification-telegram'; }
    public function name(): string { return 'Telegram 机器人'; }
    public function version(): string { return '1.0.0'; }
    public function type(): PluginType { return PluginType::Notification; }

    public function register(): void
    {
        $pluginPath = dirname(__FILE__);
        require_once $pluginPath . '/Controllers/SettingsController.php';
        app('view')->addNamespace('notification-telegram', $pluginPath . '/views');
        AdminMenu::add([
            'group' => AdminMenu::GROUP_NOTIFICATION,
            'items' => [
                ['label' => 'Telegram 机器人', 'icon' => 'send-plane', 'route' => 'admin.plugin.notification-telegram', 'order' => 56],
            ],
        ]);
        require $pluginPath . '/routes.php';
    }

    public function boot(): void
    {
        // 由 NotificationDispatcher 统一分发，不再自行监听事件
    }

    public function uninstall(): void
    {
        AdminMenu::remove('admin.plugin.notification-telegram');
    }

    public function config(): array
    {
        return [
            'bot_token' => '',
            'user_id' => '',
            'api_host' => 'api.telegram.org',
            'proxy_host' => '',
            'proxy_port' => '',
            'proxy_auth' => '',
        ];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }

    // ==================== NotificationChannelInterface ====================

    public function send(Notification $notification): bool
    {
        try {
            $ctx = plugin_context($this->id());
            $token = $ctx->config('bot_token');
            $userId = $ctx->config('user_id');
            $apiHost = $ctx->config('api_host', 'api.telegram.org');

            if (empty($token) || empty($userId)) {
                return false;
            }

            $url = "https://{$apiHost}/bot{$token}/sendMessage";
            
            $client = Http::asJson();

            // Proxy support
            $proxyHost = $ctx->config('proxy_host');
            if ($proxyHost) {
                $proxyPort = $ctx->config('proxy_port');
                $proxyAuth = $ctx->config('proxy_auth');
                $proxyUrl = $proxyHost . ($proxyPort ? ":{$proxyPort}" : '');
                if ($proxyAuth) {
                    $proxyUrl = $proxyAuth . '@' . $proxyUrl;
                }
                $client->withOptions(['proxy' => $proxyUrl]);
            }

            $response = $client->post($url, [
                'chat_id' => $userId,
                'text' => $notification->subject . "\n\n" . $notification->body,
            ]);

            return $response->successful() && $response->json('ok') === true;
        } catch (\Throwable $e) {
            plugin_context($this->id())->logger()->error('Telegram 推送异常', ['error' => $e->getMessage()]);
            return false;
        }
    }

    public function supports(string $eventType): bool
    {
        return true;
    }

}
 }
}
tring $type, string $summary): void
    {
        $this->send(new Notification(
            type: $type,
            subject: "[{$order->order_no}] {$summary}",
            body: "商品: {$order->product_name}\n金额: {$order->final_amount}\n时间: " . now()->format('Y-m-d H:i:s'),
            data: ['order_no' => $order->order_no, 'product_name' => $order->product_name, 'amount' => $order->final_amount]
        ));
    }
}
