<?php

use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Core\Contracts\NotificationChannelInterface;
use App\Core\Notification\Notification;
use App\Core\Admin\AdminMenu;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Http;

class WxPusherPlugin implements PluginInterface, NotificationChannelInterface
{
    public function id(): string { return 'notification-wxpusher'; }
    public function name(): string { return 'WxPusher 微信推送'; }
    public function version(): string { return '1.0.0'; }
    public function type(): PluginType { return PluginType::Notification; }

    public function register(): void
    {
        $pluginPath = dirname(__FILE__);
        require_once $pluginPath . '/Controllers/SettingsController.php';
        app('view')->addNamespace('notification-wxpusher', $pluginPath . '/views');
        AdminMenu::add([
            'group' => AdminMenu::GROUP_NOTIFICATION,
            'items' => [
                ['label' => 'WxPusher 微信推送', 'icon' => 'wechat', 'route' => 'admin.plugin.notification-wxpusher', 'order' => 62],
            ],
        ]);
        require $pluginPath . '/routes.php';
    }

    public function boot(): void
    {
        // 由 NotificationDispatcher 统一分发，不再自行监听事件
    }

    public function uninstall(): void { AdminMenu::remove('admin.plugin.notification-wxpusher'); }

    public function config(): array
    {
        return [
            'app_token' => '',
            'topic_ids' => '',
            'uids' => '',
        ];
    }

    public function requires(): array { return ['core' => '>=1.0']; }

    public function send(Notification $notification): bool
    {
        try {
            $ctx = plugin_context($this->id());
            $appToken = $ctx->config('app_token');
            if (!$appToken) {
                $ctx->logger()->error('WxPusher app_token 未配置');
                return false;
            }

            $topicIds = array_filter(array_map('trim', explode(';', $ctx->config('topic_ids', ''))));
            $uids = array_filter(array_map('trim', explode(';', $ctx->config('uids', ''))));

            if (empty($topicIds) && empty($uids)) {
                $ctx->logger()->error('WxPusher topic_ids 和 uids 均为空');
                return false;
            }

            $response = Http::post('https://wxpusher.zjiecode.com/api/send/message', [
                'appToken' => $appToken,
                'content' => $notification->body,
                // WxPusher API 要求 summary 不超过 100 字符
                'summary' => mb_substr($notification->subject, 0, 100),
                'contentType' => 1,
                'topicIds' => array_map('intval', $topicIds),
                'uids' => $uids,
            ]);

            if (!$response->successful()) {
                $ctx->logger()->error('WxPusher 推送失败', ['status' => $response->status(), 'body' => $response->body()]);
                return false;
            }

            $data = $response->json();
            if (($data['code'] ?? 0) !== 1000) {
                $ctx->logger()->error('WxPusher 业务错误', $data);
                return false;
            }

            return true;
        } catch (\Throwable $e) {
            plugin_context($this->id())->logger()->error('WxPusher 推送异常', ['error' => $e->getMessage()]);
            return false;
        }
    }

    public function supports(string $eventType): bool
    {
        return true;
    }
}
