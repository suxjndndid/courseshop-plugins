<?php

namespace NotificationWxpusher\Controllers;

use App\Models\Setting;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;

class SettingsController
{
    public function index()
    {
        $settings = Setting::getGroup('notification-wxpusher');
        return view('notification-wxpusher::settings', ['settings' => $settings]);
    }

    public function save(Request $request)
    {
        $request->validate([
            'app_token' => 'required|string',
        ]);
        
        Setting::setGroup('notification-wxpusher', [
            'app_token' => $request->input('app_token'),
            'topic_ids' => $request->input('topic_ids'),
            'uids' => $request->input('uids'),
        ]);
        Setting::where('setting_group', 'notification-wxpusher')
            ->whereIn('key', ['enabled_events', 'route_use_legacy_supports'])
            ->delete();

        app(ActivityLogService::class)->log('setting', '更新 WxPusher 配置');

        return redirect()->route('admin.plugin.notification-wxpusher')->with('success', 'WxPusher 配置已保存');
    }
}
