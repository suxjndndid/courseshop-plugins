<?php

use Illuminate\Support\Facades\Route;

Route::prefix('admin')->middleware('admin.auth')->group(function () {
    Route::get('/plugin/notification-wxpusher', [\NotificationWxpusher\Controllers\SettingsController::class, 'index'])
        ->name('admin.plugin.notification-wxpusher');
    Route::post('/plugin/notification-wxpusher', [\NotificationWxpusher\Controllers\SettingsController::class, 'save'])
        ->name('admin.plugin.notification-wxpusher.save');
});
