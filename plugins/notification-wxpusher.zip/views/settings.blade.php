@extends('admin.layouts.app')

@section('title', 'WxPusher 配置')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 class="text-lg font-medium text-gray-900 mb-6">WxPusher 配置</h3>

        @if(session('success'))
            <div class="mb-4 p-4 bg-green-50 border-l-4 border-green-400 text-green-700">
                {{ session('success') }}
            </div>
        @endif

        @if($errors->any())
            <div class="mb-4 p-4 bg-red-50 border-l-4 border-red-400 text-red-700">
                <ul class="list-disc list-inside">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('admin.plugin.notification-wxpusher.save') }}" method="POST">
            @csrf
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700">App Token</label>
                    <input type="text" name="app_token" value="{{ old('app_token', $settings['app_token'] ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" required>
                    <p class="mt-1 text-xs text-gray-500">WxPusher 后台获取的 AppToken</p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Topic IDs</label>
                    <input type="text" name="topic_ids" value="{{ old('topic_ids', $settings['topic_ids'] ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                    <p class="mt-1 text-xs text-gray-500">发送到的主题 ID，多个用分号 (;) 分隔</p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">UIDs</label>
                    <input type="text" name="uids" value="{{ old('uids', $settings['uids'] ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                    <p class="mt-1 text-xs text-gray-500">发送到的用户 UID，多个用分号 (;) 分隔</p>
                </div>

                <div class="rounded-md border border-blue-100 bg-blue-50 p-3 text-sm text-blue-800">
                    分发规则已统一迁移到后台“系统 → 通知分发”，这里仅维护 WxPusher 的发送参数。
                </div>

                <div class="pt-4">
                    <button type="submit" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        保存配置
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
