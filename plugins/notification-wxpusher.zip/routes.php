<?php

use NotificationWxpusher\Controllers\SettingsController;
use Illuminate\Support\Facades\Route;

admin_route_group(function () {
    Route::get('/plugin/notification-wxpusher', [SettingsController::class, 'index'])
        ->name('admin.plugin.notification-wxpusher');
    Route::post('/plugin/notification-wxpusher', [SettingsController::class, 'save'])
        ->name('admin.plugin.notification-wxpusher.save');
});
