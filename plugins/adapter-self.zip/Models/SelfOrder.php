<?php

/**
 * 自营订单 Eloquent 模型
 *
 * 无命名空间（插件通过 require_once 加载）。
 * 对应 self_orders 表，保存每个已支付订单的自营业务入参和人工处理状态。
 */

use App\Models\PaymentOrder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SelfOrder extends Model
{
    protected $table = 'self_orders';

    protected $fillable = [
        'payment_order_id',
        'product_id',
        'handler_key',
        'study_username',
        'study_password',
        'order_payload',
        'order_status',
        'result_payload',
        'admin_remark',
        'failed_reason',
        'processed_at',
    ];

    /**
     * $casts 类型转换：
     * - array：JSON 字段转 PHP 数组
     * - datetime：转 Carbon
     */
    protected $casts = [
        'order_payload' => 'array',
        'result_payload' => 'array',
        'processed_at' => 'datetime',
    ];

    /**
     * 所属支付订单（多对一）
     */
    public function paymentOrder(): BelongsTo
    {
        return $this->belongsTo(PaymentOrder::class);
    }

    // ==================== Query Scopes ====================

    /**
     * 按支付订单 ID 查询
     */
    public function scopeByPaymentOrderId($query, int $paymentOrderId)
    {
        return $query->where('payment_order_id', $paymentOrderId);
    }

    /**
     * 待处理
     */
    public function scopePending($query)
    {
        return $query->where('order_status', 'pending');
    }
}
