<?php

namespace Self\Services;

use App\Models\PaymentOrder;
use Illuminate\Support\Carbon;

/**
 * 自营业务服务
 *
 * 说明：
 * - 按 product_id 动态加载 Handlers/Product{N}Handler.php
 * - 新增商品只需在 Handlers/ 目录下新建对应 Handler 文件，此处无需改动
 * - 提供：查询业务数据 + 支付后自营订单入库 + 查询页附加数据
 */
class SelfBusinessService
{
    private string $pluginId = 'adapter-self';

    /**
     * 查询业务信息：按 product_id 动态加载对应 Handler，返回 html + payload
     *
     * Handler 文件约定：Handlers/Product{N}Handler.php，类名 Product{N}Handler。
     * 找不到对应 Handler 时抛出 InvalidArgumentException。
     *
     * @return array{html:string,payload:array<string,mixed>}
     * @throws \InvalidArgumentException 账号/密码为空或无对应 Handler 时抛出
     */
    /**
     * 查询业务信息：按 handlerKey 动态加载对应 Handler，返回 html + payload
     *
     * @param int    $productId  数据库商品 ID（写入 payload，随订单入库）
     * @param int    $handlerKey 业务处理器编号（来自 products.meta.handler_key），决定加载哪个 Handler 文件
     * @param string $username
     * @param string $password
     * @return array{html:string,payload:array<string,mixed>}
     * @throws \InvalidArgumentException
     */
    public function buildCourseHtml(int $productId, int $handlerKey, string $username, string $password): array
    {
        $username = trim($username);
        if ($username === '' || trim($password) === '') {
            throw new \InvalidArgumentException('账号或密码不能为空');
        }

        $logger  = plugin_context($this->pluginId)->logger();
        $handler = $this->resolveHandler($handlerKey);
        $result  = $handler->query($username, $password, $logger);

        return [
            'html'    => $result['html'],
            'payload' => array_merge([
                'product_id'  => $productId,
                'handler_key' => $handlerKey,
                'username'    => $username,
                'fetched_at'  => now()->toDateTimeString(),
            ], $result['payload']),
        ];
    }

    /**
     * 按 handlerKey 动态加载并返回对应 Handler 实例
     *
     * 文件路径：<pluginRoot>/Handlers/Product{N}Handler.php
     * 类名：Product{N}Handler（namespace Self\Handlers）
     *
     * @throws \InvalidArgumentException 未找到对应 Handler 文件时抛出
     */
    private function resolveHandler(int $handlerKey): \Self\Handlers\ProductHandlerInterface
    {
        // __DIR__ 指向 Services/，向上一级再进入 Handlers/
        $file = dirname(__DIR__) . '/Handlers/Product' . $handlerKey . 'Handler.php';

        if (!file_exists($file)) {
            throw new \InvalidArgumentException(
                '业务标识 ' . $handlerKey . ' 暂未配置处理器（缺少 Handlers/Product' . $handlerKey . 'Handler.php）'
            );
        }

        require_once $file;

        $class = 'Self\\Handlers\\Product' . $handlerKey . 'Handler';

        return new $class();
    }

    /**
     * 支付成功后创建（或获取）自营订单记录
     */
    public function createOrGetSelfOrder(PaymentOrder $order, array $adapterData): \SelfOrder
    {
        $existing = \SelfOrder::where('payment_order_id', $order->id)->first();
        if ($existing) {
            return $existing;
        }

        $selfOrder = \SelfOrder::create([
            'payment_order_id' => $order->id,
            'product_id'       => (int) ($adapterData['product_id'] ?? $order->product_id),
            'handler_key'      => (string) ($adapterData['handler_key'] ?? ''),
            'study_username'   => (string) ($adapterData['study_username'] ?? ''),
            'study_password'   => (string) ($adapterData['study_password'] ?? ''),
            'order_payload'    => $adapterData['course_payload'] ?? [],
            'order_status'     => 'pending',
            'result_payload'   => [],
            'admin_remark'     => null,
            'failed_reason'    => null,
            'processed_at'     => null,
        ]);

        plugin_context($this->pluginId)->logger()->info('创建自营订单记录', [
            'payment_order_id' => $order->id,
            'self_order_id'    => $selfOrder->id,
            'product_id'       => $selfOrder->product_id,
        ]);

        return $selfOrder;
    }

    /**
     * 查询页附加字段
     *
     * 兼容框架 order-query.js 的结构，复用现有卡片渲染与按钮逻辑（不提供刷新/补刷路由）。
     *
     * @param array<string,mixed> $extraData
     * @return array<string,mixed>
     */
    public function appendOrderQueryData(array $extraData, PaymentOrder $order): array
    {
        $selfOrder = \SelfOrder::where('payment_order_id', $order->id)->first();
        if (!$selfOrder) {
            return $extraData;
        }

        $statusMap = [
            'pending'    => '待处理',
            'processing' => '进行中',
            'completed'  => '已完成',
            'failed'     => '失败',
        ];

        $remarks = [];
        if ($selfOrder->admin_remark) {
            $remarks[] = '备注：' . $selfOrder->admin_remark;
        }
        if ($selfOrder->failed_reason) {
            $remarks[] = '失败原因：' . $selfOrder->failed_reason;
        }
        if ($selfOrder->result_payload) {
            $remarks[] = '结果：' . json_encode($selfOrder->result_payload, JSON_UNESCAPED_UNICODE);
        }

        $extraData['study_orders'] = [[
            'id'                => $selfOrder->id,
            'platform_order_id' => 'SELF-' . $selfOrder->id,
            'course_name'       => $order->product_name . '（自营）',
            'school'            => '自营业务',
            'order_status'      => $selfOrder->order_status,
            'status'            => $statusMap[$selfOrder->order_status] ?? $selfOrder->order_status,
            'progress'          => match ($selfOrder->order_status) {
                'completed'  => '100%',
                'processing' => '50%',
                default      => '0%',
            },
            'remarks'       => implode(' | ', $remarks),
            'has_error'     => $selfOrder->order_status === 'failed',
            'error_message' => $selfOrder->failed_reason,
            'started_at'    => $selfOrder->created_at?->format('Y-m-d H:i'),
            'completed_at'  => $selfOrder->processed_at?->format('Y-m-d H:i'),
            'has_local_data' => true,
            'username'      => $selfOrder->study_username,
        ]];

        // 不提供刷新/补刷能力，给空路由让前端按钮直接 no-op
        $extraData['plugin_routes'] = [
            'refresh' => '',
            'rebrush' => '',
        ];

        return $extraData;
    }

    /**
     * 计算处理完成时间
     */
    public function resolveProcessedAt(string $status): ?Carbon
    {
        return in_array($status, ['completed', 'failed'], true) ? now() : null;
    }
}
