/**
 * Self 插件前端脚本
 *
 * 功能：
 * - 读取账号/密码并调用查询接口
 * - 渲染接口返回的 html
 * - 把 payload 写入隐藏字段 course_payload（提交时进入 adapter_data）
 * - 触发 adapter:price-update 维持价格联动
 */
(function () {
    'use strict';

    const cfg = window.__ADAPTER_SELF_CONFIG__ || {};
    const productId = parseInt(cfg.productId, 10) || 0;
    const coursesRoute = cfg.coursesRoute || '';
    const unitPrice = parseFloat(cfg.unitPrice) || 0;
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';

    const usernameEl = document.getElementById('selfStudyUsername');
    const passwordEl = document.getElementById('selfStudyPassword');
    const payloadEl = document.getElementById('selfCoursePayload');
    const fetchBtn = document.getElementById('selfFetchCoursesBtn');
    const resultEl = document.getElementById('selfCourseResult');

    function sanitizeStaticHtml(input) {
        const source = String(input || '');
        const template = document.createElement('template');
        template.innerHTML = source;

        const allowedTags = new Set([
            'div', 'p', 'span', 'br', 'hr',
            'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
            'strong', 'b', 'em', 'i', 'u', 's',
            'ul', 'ol', 'li',
            'table', 'thead', 'tbody', 'tr', 'th', 'td',
            'blockquote', 'pre', 'code',
            'a', 'img', 'label', 'input'
        ]);

        const dangerousTags = new Set([
            'script', 'style', 'iframe', 'object', 'embed',
            'form', 'button', 'textarea', 'select', 'option', 'svg', 'math'
        ]);
        const globalAttrs = new Set(['class', 'id', 'title', 'role', 'style']);
        const perTagAttrs = {
            a: new Set(['href', 'target', 'rel']),
            img: new Set(['src', 'alt', 'width', 'height', 'loading']),
            input: new Set(['type', 'class', 'data-course', 'data-id', 'data-name', 'checked']),
            th: new Set(['colspan', 'rowspan']),
            td: new Set(['colspan', 'rowspan']),
        };

        const allowedCss = new Set([
            'color', 'background-color',
            'font-size', 'font-weight', 'font-style', 'line-height', 'text-decoration',
            'text-align',
            'margin', 'margin-top', 'margin-right', 'margin-bottom', 'margin-left',
            'padding', 'padding-top', 'padding-right', 'padding-bottom', 'padding-left',
            'border', 'border-top', 'border-right', 'border-bottom', 'border-left', 'border-radius',
            'display', 'width', 'height', 'max-width', 'min-width'
        ]);

        const sanitizeStyle = (value) => {
            const rules = String(value || '').split(';');
            const safe = [];
            rules.forEach((rule) => {
                if (!rule || !rule.includes(':')) return;
                const idx = rule.indexOf(':');
                const prop = rule.slice(0, idx).trim().toLowerCase();
                const val = rule.slice(idx + 1).trim();
                if (!allowedCss.has(prop)) return;
                if (!val) return;
                if (/(expression|javascript:|vbscript:|@import|url\s*\()/i.test(val)) return;
                if (val.includes('{') || val.includes('}')) return;
                safe.push(prop + ': ' + val);
            });
            return safe.join('; ');
        };

        const sanitizeUrl = (value, allowDataImage) => {
            const raw = String(value || '').trim();
            if (!raw) return '';
            const lower = raw.toLowerCase();
            if (lower.startsWith('javascript:') || lower.startsWith('vbscript:')) return '';
            if (raw.startsWith('#') || raw.startsWith('/')) return raw;
            if (/^(https?:|mailto:|tel:)/i.test(raw)) return raw;
            if (allowDataImage && /^data:image\/(png|jpe?g|gif|webp);base64,[a-z0-9+/=\s]+$/i.test(raw)) {
                return raw;
            }
            return '';
        };

        const walk = (node) => {
            Array.from(node.childNodes).forEach((child) => {
                if (child.nodeType === Node.COMMENT_NODE) {
                    child.remove();
                    return;
                }

                if (child.nodeType !== Node.ELEMENT_NODE) {
                    return;
                }

                const tag = child.tagName.toLowerCase();
                if (!allowedTags.has(tag)) {
                    if (dangerousTags.has(tag)) {
                        child.remove();
                    } else {
                        while (child.firstChild) {
                            child.parentNode.insertBefore(child.firstChild, child);
                        }
                        child.remove();
                    }
                    return;
                }

                Array.from(child.attributes).forEach((attr) => {
                    const name = attr.name.toLowerCase();
                    const value = attr.value;

                    if (name.startsWith('on')) {
                        child.removeAttribute(attr.name);
                        return;
                    }

                    if (name.startsWith('aria-')) {
                        return;
                    }

                    if (name.startsWith('data-')) {
                        const inputAllowed = tag === 'input' && (perTagAttrs.input || new Set()).has(name);
                        if (!inputAllowed) {
                            child.removeAttribute(attr.name);
                        }
                        return;
                    }

                    const tagAllowed = perTagAttrs[tag] || new Set();
                    if (!globalAttrs.has(name) && !tagAllowed.has(name)) {
                        child.removeAttribute(attr.name);
                        return;
                    }

                    if (name === 'style') {
                        const clean = sanitizeStyle(value);
                        if (clean) child.setAttribute('style', clean);
                        else child.removeAttribute('style');
                        return;
                    }

                    if (name === 'href') {
                        const clean = sanitizeUrl(value, false);
                        if (clean) child.setAttribute('href', clean);
                        else child.removeAttribute('href');
                        return;
                    }

                    if (name === 'src') {
                        const clean = sanitizeUrl(value, true);
                        if (clean) child.setAttribute('src', clean);
                        else child.removeAttribute('src');
                        return;
                    }

                    if (tag === 'input' && name === 'type') {
                        if (String(value || '').toLowerCase() !== 'checkbox') {
                            child.removeAttribute(attr.name);
                        }
                        return;
                    }
                });

                walk(child);
            });
        };

        walk(template.content);
        return template.innerHTML;
    }

    function showMessage(msg, type) {
        if (typeof window.showNotification === 'function') {
            window.showNotification(msg, type);
            return;
        }
        if (type === 'error' || type === 'warning') {
            alert(msg);
        }
    }

    function setLoading(loading) {
        if (!fetchBtn) {
            return;
        }
        fetchBtn.disabled = loading;
        fetchBtn.innerHTML = loading
            ? '<i class="bi bi-hourglass-split me-1"></i>查询中...'
            : '<i class="bi bi-search me-1"></i>查询业务信息';
    }

    function getCheckedCount() {
        return (resultEl ? resultEl.querySelectorAll('.self-course-checkbox:checked').length : 0);
    }

    function notifyPrice() {
        const count = getCheckedCount();
        const subtotal = unitPrice * (count > 0 ? count : 0);
        document.dispatchEvent(new CustomEvent('adapter:price-update', {
            detail: { subtotal: subtotal, count: count }
        }));
    }

    function collectPayload(basePayload) {
        if (!resultEl) return basePayload;
        const checked = resultEl.querySelectorAll('.self-course-checkbox:checked');
        const selected = [];
        checked.forEach(function (cb) {
            selected.push({
                course: cb.dataset.course || '',
                id: cb.dataset.id || '',
                name: cb.dataset.name || ''
            });
        });
        return Object.assign({}, basePayload, { selected_items: selected });
    }

    fetchBtn?.addEventListener('click', async function () {
        const username = usernameEl?.value?.trim() || '';
        const password = passwordEl?.value || '';

        if (!username) {
            showMessage('请输入学习账号', 'warning');
            usernameEl?.focus();
            return;
        }
        if (!password) {
            showMessage('请输入学习密码', 'warning');
            passwordEl?.focus();
            return;
        }

        if (!coursesRoute) {
            showMessage('查询接口未配置', 'error');
            return;
        }

        setLoading(true);
        try {
            const resp = await fetch(coursesRoute, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': csrf
                },
                body: JSON.stringify({
                    product_id: productId,
                    username: username,
                    password: password
                })
            });

            const result = await resp.json();
            if (!result.success) {
                showMessage(result.message || '查询失败', 'error');
                return;
            }

            const html = result.data?.html || '';
            const basePayload = result.data?.payload || {};

            if (resultEl) {
                resultEl.style.display = '';
                resultEl.innerHTML = sanitizeStaticHtml(html);

                // 监听 checkbox 变化：同步 payload + 触发价格更新
                resultEl.querySelectorAll('.self-course-checkbox').forEach(function (cb) {
                    cb.addEventListener('change', function () {
                        if (payloadEl) {
                            payloadEl.value = JSON.stringify(collectPayload(basePayload));
                        }
                        notifyPrice();
                    });
                });
            }

            // 初始 payload（未勾选任何 checkbox 时保留完整 payload）
            if (payloadEl) {
                payloadEl.value = JSON.stringify(collectPayload(basePayload));
            }

            notifyPrice();
            showMessage('查询成功，请勾选项目后提交订单', 'success');
        } catch (e) {
            showMessage('网络错误，请稍后重试', 'error');
        } finally {
            setLoading(false);
        }
    });

    // 页面加载时先同步一次价格（单价）
    notifyPrice();
})();
