/**
 * Self 插件前端脚本
 *
 * 功能：
 * - 读取账号/密码并调用查询接口
 * - 渲染接口返回的 html
 * - 把 payload 写入隐藏字段 course_payload（提交时进入 adapter_data）
 * - 触发 adapter:price-update 维持价格联动
 */
(function () {
    'use strict';

    const cfg = window.__ADAPTER_SELF_CONFIG__ || {};
    const productId = parseInt(cfg.productId, 10) || 0;
    const coursesRoute = cfg.coursesRoute || '';
    const unitPrice = parseFloat(cfg.unitPrice) || 0;
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';

    const usernameEl = document.getElementById('selfStudyUsername');
    const passwordEl = document.getElementById('selfStudyPassword');
    const payloadEl = document.getElementById('selfCoursePayload');
    const fetchBtn = document.getElementById('selfFetchCoursesBtn');
    const resultEl = document.getElementById('selfCourseResult');

    function showMessage(msg, type) {
        if (typeof window.showNotification === 'function') {
            window.showNotification(msg, type);
            return;
        }
        if (type === 'error' || type === 'warning') {
            alert(msg);
        }
    }

    function setLoading(loading) {
        if (!fetchBtn) {
            return;
        }
        fetchBtn.disabled = loading;
        fetchBtn.innerHTML = loading
            ? '<i class="bi bi-hourglass-split me-1"></i>查询中...'
            : '<i class="bi bi-search me-1"></i>查询业务信息';
    }

    function getCheckedCount() {
        return (resultEl ? resultEl.querySelectorAll('.self-course-checkbox:checked').length : 0);
    }

    function notifyPrice() {
        const count = getCheckedCount();
        const subtotal = unitPrice * (count > 0 ? count : 0);
        document.dispatchEvent(new CustomEvent('adapter:price-update', {
            detail: { subtotal: subtotal, count: count }
        }));
    }

    function collectPayload(basePayload) {
        if (!resultEl) return basePayload;
        const checked = resultEl.querySelectorAll('.self-course-checkbox:checked');
        if (checked.length === 0) return basePayload;
        const selected = [];
        checked.forEach(function (cb) {
            selected.push({
                course: cb.dataset.course || '',
                id: cb.dataset.id || '',
                name: cb.dataset.name || ''
            });
        });
        return Object.assign({}, basePayload, { selected_items: selected });
    }

    fetchBtn?.addEventListener('click', async function () {
        const username = usernameEl?.value?.trim() || '';
        const password = passwordEl?.value || '';

        if (!username) {
            showMessage('请输入学习账号', 'warning');
            usernameEl?.focus();
            return;
        }
        if (!password) {
            showMessage('请输入学习密码', 'warning');
            passwordEl?.focus();
            return;
        }

        if (!coursesRoute) {
            showMessage('查询接口未配置', 'error');
            return;
        }

        setLoading(true);
        try {
            const resp = await fetch(coursesRoute, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': csrf
                },
                body: JSON.stringify({
                    product_id: productId,
                    username: username,
                    password: password
                })
            });

            const result = await resp.json();
            if (!result.success) {
                showMessage(result.message || '查询失败', 'error');
                return;
            }

            const html = result.data?.html || '';
            const basePayload = result.data?.payload || {};

            if (resultEl) {
                resultEl.style.display = '';
                resultEl.innerHTML = html;

                // 监听 checkbox 变化：同步 payload + 触发价格更新
                resultEl.querySelectorAll('.self-course-checkbox').forEach(function (cb) {
                    cb.addEventListener('change', function () {
                        if (payloadEl) {
                            payloadEl.value = JSON.stringify(collectPayload(basePayload));
                        }
                        notifyPrice();
                    });
                });
            }

            // 初始 payload（未勾选任何 checkbox 时保留完整 payload）
            if (payloadEl) {
                payloadEl.value = JSON.stringify(basePayload);
            }

            notifyPrice();
            showMessage('查询成功，请勾选项目后提交订单', 'success');
        } catch (e) {
            showMessage('网络错误，请稍后重试', 'error');
        } finally {
            setLoading(false);
        }
    });

    // 页面加载时先同步一次价格（单价）
    notifyPrice();
})();
