<?php

namespace Self\Handlers;

/**
 * Product ID=1 的自营业务处理器
 *
 * 在此填写 product_id=1 对应的实际业务逻辑：
 * 例如调用内部 API、查询数据库、验证账号等。
 * 返回的 html 用于前端回显，payload 随订单入库。
 */
class Product1Handler implements ProductHandlerInterface
{
    /**
     * 查询用户套餐信息
     *
     * @param string $username
     * @param string $password
     * @return array
     * @throws \InvalidArgumentException
     */
    public function query(string $username, string $password, \App\Core\Plugin\PluginLogger $logger): array
    {
        $safeUser = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');

        // 生成加密密码和时间戳
        [$pwd, $ts] = $this->generateCipherText($password);

        $loginUrl = 'https://sso.sflep.com/idsvr/account/login';
        $postData = [
            'account' => $username,
            'pwd'     => $pwd,
            'ts'      => $ts,
        ];

        $logger->debug('Product1Handler: 发起登录请求', [
            'url'      => $loginUrl,
            'username' => $username,
            'ts'       => $ts,
        ]);

        $response = null;

        //TODO: 这里实际业务中可能需要调用第三方 API 验证账号密码，获取课程信息等。此处模拟一个固定响应。
        $debug_model = true;
        if ($debug_model) {
            $logger->debug('Product1Handler: 进入调试模式，使用模拟数据');
            $resData = [
                'code' => 0,
                'msg'  => '登录成功',
                'data' => [
                    // 模拟返回的课程数据
                ],
            ];
        } else {
            $logger->debug('Product1Handler: 发送登录请求到第三方 API', [
                'url'      => $loginUrl,
                'postData' => $postData,
            ]);
            $response = $this->httpPost($loginUrl, $postData);
            $resData  = json_decode($response, true);
        }
        $logger->debug('Product1Handler: 登录接口响应', [
            'username'     => $username,
            'raw_response' => $response,
            'decoded_code' => $resData['code'] ?? null,
        ]);

        if (!$resData || !isset($resData['code'])) {
            $logger->warning('Product1Handler: 登录接口返回异常', [
                'username'     => $username,
                'raw_response' => $response,
            ]);
            throw new \InvalidArgumentException('接口返回异常');
        }

        if ($resData['code'] != 0) {
            $logger->warning('Product1Handler: 账号或密码错误', [
                'username'      => $username,
                'response_code' => $resData['code'],
                'response_msg'  => $resData['msg'] ?? '',
            ]);
            throw new \InvalidArgumentException('账号或密码错误');
        }

        $logger->info('Product1Handler: 登录成功，构建课程数据', ['username' => $username]);

        $courses = [
            '全新版大学高阶英语综合教程1' => ['1.1' => 'Test 1', '1.2' => 'Test 2', '1.3' => 'Test 3', '1.4' => 'Test 4'],
            '全新版大学高阶英语综合教程2' => ['2.1' => 'Test 1', '2.2' => 'Test 2', '2.3' => 'Test 3', '2.4' => 'Test 4'],
            '全新版大学高阶英语综合教程3' => ['3.1' => 'Test 1', '3.2' => 'Test 2', '3.3' => 'Test 3', '3.4' => 'Test 4'],
            '全新版大学高阶英语综合教程4' => ['4.1' => 'Test 1', '4.2' => 'Test 2', '4.3' => 'Test 3'],
        ];

        $html = '<div class="alert alert-info mb-2"><strong>业务 1</strong> 查询成功，账号：' . $safeUser . '</div>';
        foreach ($courses as $courseName => $tests) {
            $html .= '<div class="course"><strong>' . htmlspecialchars($courseName, ENT_QUOTES, 'UTF-8') . '</strong><ul>';
            foreach ($tests as $id => $testName) {
                $html .= '<li><label><input type="checkbox" class="self-course-checkbox" data-course="' . htmlspecialchars($courseName, ENT_QUOTES, 'UTF-8') . '" data-id="' . htmlspecialchars($id, ENT_QUOTES, 'UTF-8') . '" data-name="' . htmlspecialchars($testName, ENT_QUOTES, 'UTF-8') . '" /> ' . htmlspecialchars($testName, ENT_QUOTES, 'UTF-8') . '</label></li>';
            }
            $html .= '</ul></div>';
        }

        $payload = [];
        foreach ($courses as $courseName => $tests) {
            $payload[] = [
                'course' => $courseName,
                'tests'  => array_map(fn($id, $name) => ['id' => $id, 'name' => $name], array_keys($tests), $tests),
            ];
        }

        $logger->debug('Product1Handler: 查询完成', [
            'username'      => $username,
            'course_count'  => count($courses),
        ]);

        return [
            'html'    => $html,
            'payload' => $payload,
        ];
    }

    /**
     * JS generateCipherText PHP 实现
     */
    private function generateCipherText(string $password): array
    {
        $T0 = round(microtime(true) * 1000);
        $P = array_map('ord', str_split($password));
        $V = ($T0 >> 16) & 0xFF;

        foreach ($P as $b) {
            $V ^= $b;
        }

        $remainder = $V % 100;
        $T1 = floor($T0 / 100) * 100 + $remainder;

        $P1 = '';
        foreach ($P as $b) {
            $P1 .= str_pad(dechex($b & 0xFF), 2, '0', STR_PAD_LEFT);
        }

        $S = $T1 . '*' . $P1;
        $E = base64_encode($S);

        return [$E, $T1];
    }

    /**
     * 简单 HTTP POST 请求
     */
    private function httpPost(string $url, array $postData): string
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        return $response ?: '';
    }
}
