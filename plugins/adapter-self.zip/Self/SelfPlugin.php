<?php

/**
 * 自营商品对接插件 — 入口文件
 *
 * 同时实现两个接口（implements 多接口）：
 * - PluginInterface：插件生命周期（register/boot/uninstall）
 * - ProductAdapterInterface：商品类型定义、meta 校验、履约入口
 *
 * 设计说明：
 * - 本插件按 product_id 做轻量硬编码分支，不引入二级插件架构
 * - 仅保留最小闭环：账号密码校验 + 查询课程 + 下单落库 + 手动状态维护
 * - 支付成功后不自动履约，仅发送管理员通知并把订单标记为待处理
 */

use App\Core\Admin\AdminMenu;
use App\Core\Contracts\ProductAdapterInterface;
use App\Core\Hook\Hook;
use App\Core\Plugin\FulfillResult;
use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Models\PaymentOrder;

class SelfPlugin implements PluginInterface, ProductAdapterInterface
{
    /** @var string 插件根目录（register() 中初始化） */
    private string $pluginPath;

    // ==================== PluginInterface ====================

    public function id(): string { return 'adapter-self'; }
    public function name(): string { return '自营商品对接'; }
    public function version(): string { return '1.0.0'; }
    public function type(): PluginType { return PluginType::ProductAdapter; }

    /**
     * 注册阶段：加载依赖、注册视图、菜单、路由
     */
    public function register(): void
    {
        $this->pluginPath = dirname(__FILE__);

        $this->loadDependencies();

        // 视图命名空间：view('adapter-self::settings')
        app('view')->addNamespace('adapter-self', $this->pluginPath . '/views');

        AdminMenu::add([
            'group' => AdminMenu::GROUP_PRODUCT_ADAPTER,
            'items' => [
                [
                    'label' => '自营对接',
                    'icon'  => 'folder',
                    'route' => 'admin.plugin.adapter-self',
                    'order' => 52,
                ],
            ],
        ]);

        // 路由文件（全部走 Controller，不写闭包）
        require $this->pluginPath . '/routes.php';
    }

    /**
     * 启动阶段：注册 Hook
     */
    public function boot(): void
    {
        $this->registerFormHooks();
        $this->registerOrderHooks();
        $this->registerQueryHooks();
        $this->registerDisplayHooks();
    }

    public function uninstall(): void
    {
        AdminMenu::remove('admin.plugin.adapter-self');
    }

    public function config(): array
    {
        // 本插件目前无配置项，保留空数组即可
        return [];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }

    // ==================== ProductAdapterInterface ====================

    public function productType(): string { return 'self'; }
    public function productTypeLabel(): string { return '自营对接'; }
    public function editorComponent(): string { return 'self-editor'; }

    /**
     * 校验商品 meta（后台保存商品时调用）
     *
     * 这里约定 self 商品必须配置 handler_key（通常填 1/2）。
     */
    public function validateMeta(array $meta): array
    {
        $handlerKey = trim((string) ($meta['handler_key'] ?? ''));
        if ($handlerKey === '') {
            throw new \InvalidArgumentException('handler_key（业务标识）不能为空，例如 1 或 2');
        }

        return [
            'handler_key' => $handlerKey,
        ];
    }

    /**
     * 履约入口
     *
     * 本插件按你的要求“不自动履约”，所以统一返回成功并说明“待人工处理”。
     */
    public function fulfill(PaymentOrder $order): FulfillResult
    {
        return FulfillResult::success('订单已支付，等待管理员人工处理', [
            'source' => 'adapter-self',
            'manual' => true,
            'order_no' => $order->order_no,
        ]);
    }

    // ==================== 依赖加载 ====================

    /**
     * 插件不走 Composer 自动加载，需手动 require_once 子模块
     */
    private function loadDependencies(): void
    {
        $p = $this->pluginPath;

        // Model
        require_once $p . '/Models/SelfOrder.php';

        // Handler 接口（具体 Handler 由 SelfBusinessService 按 product_id 按需加载）
        require_once $p . '/Handlers/ProductHandlerInterface.php';

        // Service
        require_once $p . '/Services/SelfBusinessService.php';

        // Controller
        require_once $p . '/Controllers/CourseController.php';
        require_once $p . '/Controllers/SettingsController.php';
        require_once $p . '/Controllers/SelfOrderController.php';
    }

    // ==================== Hook 注册 ====================

    /**
     * 下单页表单与校验 Hook
     */
    private function registerFormHooks(): void
    {
        // 后台商品编辑页注入 meta 配置表单（handler_key）
        Hook::addFilter('admin.product.meta_form', function (string $html, string $productType) {
            if ($productType !== $this->productType()) {
                return $html;
            }

            return view('adapter-self::admin-meta-form')->render();
        }, 10);

        Hook::addFilter('order_form.adapter_ui', function (string $html, $product) {
            if (($product->product_type ?? '') !== $this->productType()) {
                return $html;
            }
            return $this->renderAdapterForm($product);
        }, 10);

        Hook::addFilter('order.validate_adapter_data', function (array $validation, $request, $product) {
            if (($product->product_type ?? '') !== $this->productType()) {
                return $validation;
            }
            return $this->validateAdapterData($validation, $request, $product);
        }, 10);
    }

    /**
     * 支付后处理 Hook
     */
    private function registerOrderHooks(): void
    {
        Hook::addAction('order.after_paid', function (PaymentOrder $order) {
            $this->handleAfterPaid($order);
        }, 10);
    }

    /**
     * 查询扩展 Hook
     */
    private function registerQueryHooks(): void
    {
        // 按学习账号反查订单
        Hook::addFilter('order_query.by_identifier', function (array $orderIds, string $identifier) {
            $ids = \SelfOrder::where('study_username', $identifier)
                ->pluck('payment_order_id')
                ->unique()
                ->toArray();

            return array_values(array_unique(array_merge($orderIds, $ids)));
        }, 10);

        // 查询结果附加自营业务数据
        Hook::addFilter('order_query.extra_data', function (array $extraData, PaymentOrder $order) {
            return (new \Self\Services\SelfBusinessService())->appendOrderQueryData($extraData, $order);
        }, 10);
    }

    /**
     * 展示扩展 Hook
     */
    private function registerDisplayHooks(): void
    {
        Hook::addFilter('product.type_label', function (string $label, string $type) {
            return $type === $this->productType() ? $this->productTypeLabel() : $label;
        }, 10);

        Hook::addFilter('product.detail_extra', function (string $html, $product) {
            if (($product->product_type ?? '') !== $this->productType()) {
                return $html;
            }

            $handlerKey = (string) ($product->meta['handler_key'] ?? '');
            if ($handlerKey === '') {
                return $html;
            }

            return $html . '<div class="text-sm text-gray-500 mt-2">'
                . '<span class="font-medium">业务标识：</span>' . htmlspecialchars($handlerKey)
                . '</div>';
        }, 10);

        Hook::addFilter('order_success.extra_info', function (string $extraInfo, PaymentOrder $order) {
            return $this->renderSuccessExtraInfo($extraInfo, $order);
        }, 10);
    }

    // ==================== Hook 回调实现 ====================

    /**
     * 渲染下单表单
     */
    private function renderAdapterForm($product): string
    {
        return view('adapter-self::adapter-form', [
            'productId'     => (int) $product->id,
            'handlerKey'    => (string) ($product->meta['handler_key'] ?? ''),
            'coursesRoute'  => route('ajax.plugin.adapter-self.courses'),
            'unitPrice'     => (float) $product->sale_price,
            'adapterJsUrl'  => asset('plugins/ProductAdapter/Self/assets/js/adapter.js'),
        ])->render();
    }

    /**
     * 校验下单数据并写入 adapter_data
     */
    private function validateAdapterData(array $validation, $request, $product): array
    {
        $studyUsername = trim((string) $request->input('study_username', ''));
        $studyPassword = (string) $request->input('study_password', '');

        if ($studyUsername === '') {
            return array_merge($validation, ['valid' => false, 'message' => '请输入学习平台账号']);
        }

        if ($studyPassword === '') {
            return array_merge($validation, ['valid' => false, 'message' => '请输入学习平台密码']);
        }

        $coursePayload = $request->input('course_payload', null);
        if (is_string($coursePayload)) {
            $decoded = json_decode($coursePayload, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                $coursePayload = $decoded;
            }
        }

        if (!is_array($coursePayload) || empty($coursePayload)) {
            return array_merge($validation, ['valid' => false, 'message' => '请先查询并确认课程信息']);
        }

        $validation['adapter_data'] = [
            'plugin_id'      => $this->id(),
            'product_id'     => (int) $product->id,
            'handler_key'    => (string) ($product->meta['handler_key'] ?? ''),
            'study_username' => $studyUsername,
            'study_password' => $studyPassword,
            'course_payload' => $coursePayload,
            'course_count'   => 1,
        ];

        return $validation;
    }

    /**
     * 支付成功后：落库自营订单 + 通知管理员 + 更新支付订单履约状态
     */
    private function handleAfterPaid(PaymentOrder $order): void
    {
        $product = $order->product;
        if (!$product || ($product->product_type ?? '') !== $this->productType()) {
            return;
        }

        $adapterData = $order->fulfill_data['adapter_data'] ?? [];

        try {
            $selfOrder = (new \Self\Services\SelfBusinessService())->createOrGetSelfOrder($order, $adapterData);

            // 标记为待处理（人工处理队列）
            if ($order->fulfill_status !== PaymentOrder::FULFILL_PENDING) {
                $order->update(['fulfill_status' => PaymentOrder::FULFILL_PENDING]);
            }

            // 推送管理员通知（参考 ThirdParty 的 notifier 用法）
            plugin_context($this->id())->notifier()->internal(
                type: 'order.self_paid',
                subject: "[{$order->order_no}] 自营订单待处理",
                body: "商品: {$order->product_name}\n金额: {$order->final_amount}\n学习账号: " . ($selfOrder->study_username ?? ''),
                data: [
                    'order_no' => $order->order_no,
                    'product_name' => $order->product_name,
                    'amount' => (string) $order->final_amount,
                    'payment_order_id' => $order->id,
                    'self_order_id' => $selfOrder->id,
                    'product_id' => $selfOrder->product_id,
                    'handler_key' => $selfOrder->handler_key,
                    'study_username' => $selfOrder->study_username,
                    'notification_email' => $order->notification_email ?? '',
                ],
                options: [
                    'level' => 'info',
                    'tags' => ['order', 'self', 'paid', 'internal'],
                    'dedupe_key' => "order.self_paid:{$order->order_no}",
                ],
            );

            plugin_context($this->id())->logger()->info('支付成功后自营订单已入库并通知管理员', [
                'order_no' => $order->order_no,
                'self_order_id' => $selfOrder->id,
                'product_id' => $selfOrder->product_id,
                'handler_key' => $selfOrder->handler_key,
            ]);
        } catch (\Throwable $e) {
            plugin_context($this->id())->logger()->error('支付成功后处理自营订单失败', [
                'order_no' => $order->order_no,
                'error' => $e->getMessage(),
                'exception_class' => get_class($e),
            ]);

            // 记录履约失败，便于后台快速发现异常
            $order->update([
                'fulfill_status' => PaymentOrder::FULFILL_FAILURE,
                'fulfill_data' => array_merge($order->fulfill_data ?? [], [
                    'self_error' => $e->getMessage(),
                ]),
            ]);
        }
    }

    /**
     * 成功页附加信息
     */
    private function renderSuccessExtraInfo(string $extraInfo, PaymentOrder $order): string
    {
        $product = $order->product;
        if (!$product || ($product->product_type ?? '') !== $this->productType()) {
            return $extraInfo;
        }

        $selfOrder = \SelfOrder::where('payment_order_id', $order->id)->first();
        if (!$selfOrder) {
            return $extraInfo;
        }

        return $extraInfo . view('adapter-self::order-success-extra', [
            'selfOrder' => $selfOrder,
        ])->render();
    }
}
