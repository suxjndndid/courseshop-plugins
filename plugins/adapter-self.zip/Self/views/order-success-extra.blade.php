{{--
    订单成功页附加信息（Self）
    变量：$selfOrder
--}}

<div class="alert alert-info mt-3">
    <div class="fw-semibold mb-2">
        <i class="bi bi-info-circle me-1"></i>订单处理状态
    </div>
    <div class="small text-muted">
        <div>订单状态：{{ $selfOrder->order_status }}</div>
        <div>学习账号：{{ $selfOrder->study_username }}</div>
        @if(!empty($selfOrder->admin_remark))
            <div>备注：{{ $selfOrder->admin_remark }}</div>
        @endif
        @if(!empty($selfOrder->failed_reason))
            <div class="text-danger">失败原因：{{ $selfOrder->failed_reason }}</div>
        @endif
    </div>
</div>
