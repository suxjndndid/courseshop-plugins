<?php

namespace Self\Handlers;

/**
 * 自营商品业务处理器接口
 *
 * 每个 product_id 对应一个实现类，放在同目录下命名为 Product{N}Handler.php。
 * SelfBusinessService 按 product_id 动态加载对应处理器，不在 Service 层做任何业务分支。
 *
 * 实现约定：
 * - 文件路径：Handlers/Product{N}Handler.php（N 为 product_id）
 * - 类名：Product{N}Handler
 * - 命名空间：Self\Handlers
 */
interface ProductHandlerInterface
{
    /**
     * 校验账号密码，查询业务信息，返回 html 片段和结构化 payload。
     *
     * @param string $username 学习账号
     * @param string $password 学习密码
     * @param \App\Core\Plugin\PluginLogger $logger 插件日志实例，由 SelfBusinessService 传入
     * @return array{html: string, payload: array<string, mixed>}
     * @throws \InvalidArgumentException 账号/密码为空或校验失败时抛出
     */
    public function query(string $username, string $password, \App\Core\Plugin\PluginLogger $logger): array;
}
