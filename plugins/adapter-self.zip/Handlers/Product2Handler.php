<?php

namespace Self\Handlers;

/**
 * Product ID=2 的自营业务处理器
 *
 * 在此填写 product_id=2 对应的实际业务逻辑。
 */
class Product2Handler implements ProductHandlerInterface
{
    public function query(string $username, string $password, \App\Core\Plugin\PluginLogger $logger): array
    {
        // TODO: 在此实现 product_id=2 的实际查询业务逻辑

        $safeUser = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');

        $items = [
            // TODO: 替换为实际从业务系统获取的数据
            ['code' => 'P2-A', 'name' => '业务2-标准套餐'],
            ['code' => 'P2-B', 'name' => '业务2-高级套餐'],
        ];

        $listHtml = implode('', array_map(
            fn($item) => '<li>' . htmlspecialchars($item['name'], ENT_QUOTES, 'UTF-8') . '</li>',
            $items
        ));

        return [
            'html' => '<div class="alert alert-success mb-2">'
                . '<strong>业务 2</strong> 查询成功，账号：' . $safeUser
                . '</div>'
                . '<ul class="mb-0">' . $listHtml . '</ul>',
            'payload' => [
                'items' => $items,
            ],
        ];
    }
}
