<?php

/**
 * 自营订单表迁移
 *
 * 设计要点：
 * - account 信息单独字段（按当前需求明文存储）
 * - 业务参数/课程参数放 JSON（order_payload / result_payload）
 * - 支持人工状态维护与失败原因记录
 */

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('self_orders', function (Blueprint $table) {
            $table->id()->comment('自营订单ID');
            $table->unsignedBigInteger('payment_order_id')->comment('关联支付订单ID');
            $table->unsignedBigInteger('product_id')->comment('商品ID（用于区分 1/2 等业务）');
            $table->string('handler_key', 50)->default('')->comment('业务标识（来自 products.meta.handler_key）');

            $table->string('study_username', 100)->comment('学习账号');
            $table->string('study_password', 255)->comment('学习密码（按需求明文存储）');

            $table->json('order_payload')->nullable()->comment('下单查询返回/前端提交的业务 JSON');
            $table->string('order_status', 20)->default('pending')->comment('状态：pending/processing/completed/failed');
            $table->json('result_payload')->nullable()->comment('人工处理结果 JSON');
            $table->string('admin_remark', 500)->nullable()->comment('后台备注');
            $table->string('failed_reason', 500)->nullable()->comment('失败原因');
            $table->datetime('processed_at')->nullable()->comment('处理完成时间');

            $table->timestamps();
            $table->softDeletes();

            $table->index('payment_order_id', 'idx_self_payment_order_id');
            $table->index('product_id', 'idx_self_product_id');
            $table->index('order_status', 'idx_self_order_status');
            $table->index(['product_id', 'order_status'], 'idx_self_product_status');

            $table->foreign('payment_order_id')
                ->references('id')
                ->on('payment_orders')
                ->onDelete('restrict');
        });

        if (DB::getDriverName() === 'mysql') {
            DB::statement("ALTER TABLE `self_orders` COMMENT = '自营订单表 — adapter-self 插件'");
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('self_orders');
    }
};
