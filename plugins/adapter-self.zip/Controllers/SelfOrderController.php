<?php

namespace Self\Controllers;

use App\Helpers\ApiResponse;
use App\Services\ActivityLogService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * 后台自营订单管理控制器
 *
 * 提供：
 * - 列表（支持 product_id / 状态 / 关键字筛选）
 * - 手动更新状态（可填写失败原因）
 */
class SelfOrderController
{
    /**
     * 列表页
     */
    public function index(Request $request)
    {
        $query = \SelfOrder::with('paymentOrder');

        if ($keyword = trim((string) $request->input('keyword', ''))) {
            $query->where(function ($q) use ($keyword) {
                $q->where('study_username', 'like', "%{$keyword}%")
                    ->orWhere('handler_key', 'like', "%{$keyword}%")
                    ->orWhere('product_id', 'like', "%{$keyword}%");
            });
        }

        if ($productId = $request->input('product_id')) {
            $query->where('product_id', (int) $productId);
        }

        if ($status = $request->input('status')) {
            $query->where('order_status', $status);
        }

        $selfOrders = $query->orderByDesc('id')->paginate(20);

        $stats = [
            'total' => \SelfOrder::count(),
            'pending' => \SelfOrder::where('order_status', 'pending')->count(),
            'processing' => \SelfOrder::where('order_status', 'processing')->count(),
            'completed' => \SelfOrder::where('order_status', 'completed')->count(),
            'failed' => \SelfOrder::where('order_status', 'failed')->count(),
        ];

        $productIds = \SelfOrder::query()
            ->select('product_id')
            ->distinct()
            ->orderBy('product_id')
            ->pluck('product_id')
            ->all();

        return view('adapter-self::self-orders', [
            'selfOrders' => $selfOrders,
            'stats' => $stats,
            'productIds' => $productIds,
            'filters' => [
                'keyword' => $request->input('keyword', ''),
                'product_id' => $request->input('product_id', ''),
                'status' => $request->input('status', ''),
            ],
        ]);
    }

    /**
     * AJAX：手动更新状态
     */
    public function updateStatus(Request $request): JsonResponse
    {
        $request->validate([
            'id' => 'required|integer|min:1',
            'status' => 'required|in:pending,processing,completed,failed',
            'failed_reason' => 'nullable|string|max:500',
            'admin_remark' => 'nullable|string|max:500',
        ]);

        try {
            $selfOrder = \SelfOrder::findOrFail((int) $request->input('id'));
            $newStatus = (string) $request->input('status');
            $failedReason = trim((string) $request->input('failed_reason', ''));
            $adminRemark = trim((string) $request->input('admin_remark', ''));

            $payload = [
                'order_status' => $newStatus,
                'admin_remark' => $adminRemark === '' ? null : $adminRemark,
                'processed_at' => (new \Self\Services\SelfBusinessService())->resolveProcessedAt($newStatus),
            ];

            if ($newStatus === 'failed') {
                if ($failedReason === '') {
                    return ApiResponse::error('失败状态必须填写失败原因', 422);
                }
                $payload['failed_reason'] = $failedReason;
            } else {
                $payload['failed_reason'] = $failedReason === '' ? null : $failedReason;
            }

            $selfOrder->update($payload);

            // 同步更新 payment_orders.fulfill_status，便于后台总订单页识别
            $paymentOrder = $selfOrder->paymentOrder;
            if ($paymentOrder) {
                $paymentOrder->update([
                    'fulfill_status' => match ($newStatus) {
                        'completed' => \App\Models\PaymentOrder::FULFILL_SUCCESS,
                        'failed' => \App\Models\PaymentOrder::FULFILL_FAILURE,
                        default => \App\Models\PaymentOrder::FULFILL_PENDING,
                    },
                ]);
            }

            app(ActivityLogService::class)->log(
                'self_order',
                sprintf(
                    '更新自营订单状态: #%d %s -> %s',
                    $selfOrder->id,
                    $selfOrder->getOriginal('order_status'),
                    $newStatus
                )
            );

            plugin_context('adapter-self')->logger()->info('后台更新自营订单状态成功', [
                'self_order_id' => $selfOrder->id,
                'new_status' => $newStatus,
                'failed_reason' => $payload['failed_reason'] ?? null,
            ]);

            return ApiResponse::success('状态已更新');
        } catch (\Throwable $e) {
            plugin_context('adapter-self')->logger()->error('后台更新自营订单状态失败', [
                'id' => $request->input('id'),
                'status' => $request->input('status'),
                'error' => $e->getMessage(),
            ]);

            return ApiResponse::error('更新失败：' . $e->getMessage());
        }
    }
}
