<?php

namespace Self\Controllers;

use App\Helpers\ApiResponse;
use App\Models\Product;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * 前端课程操作控制器（Self）
 *
 * 只提供一个查询接口：
 * - 按 product_id 查找商品，取 meta.handler_key 确定业务处理器
 * - 校验账号密码，调对应 Handler
 * - 返回 html + payload，前端直接渲染
 */
class CourseController
{
    /**
     * 查询课程/业务信息
     */
    public function getCourses(Request $request): JsonResponse
    {
        $request->validate([
            'product_id' => 'required|integer|min:1',
            'username'   => 'required|string|max:100',
            'password'   => 'required|string|max:200',
        ]);

        $productId = (int) $request->input('product_id');
        $username  = (string) $request->input('username');
        $password  = (string) $request->input('password');

        // 取商品 meta.handler_key，决定使用哪个 Handler 文件
        $product    = Product::find($productId);
        $handlerKey = (int) (($product->meta['handler_key'] ?? null) ?: $productId);

        try {
            $result = (new \Self\Services\SelfBusinessService())->buildCourseHtml(
                $productId,
                $handlerKey,
                $username,
                $password
            );

            plugin_context('adapter-self')->logger()->info('前端查询成功', [
                'product_id'  => $productId,
                'handler_key' => $handlerKey,
                'username'    => $username,
            ]);

            return ApiResponse::success('查询成功', $result);
        } catch (\Throwable $e) {
            plugin_context('adapter-self')->logger()->warning('前端查询失败', [
                'product_id'  => $productId,
                'handler_key' => $handlerKey,
                'username'    => $username,
                'error'       => $e->getMessage(),
            ]);

            return ApiResponse::error($e->getMessage(), 422);
        }
    }
}
