<?php

namespace Self\Controllers;

/**
 * Self 插件后台主页控制器
 *
 * 当前轻量方案无配置项，页面作为功能说明与入口导航。
 */
class SettingsController
{
    /**
     * 显示说明页
     */
    public function index()
    {
        return view('adapter-self::settings');
    }
}
