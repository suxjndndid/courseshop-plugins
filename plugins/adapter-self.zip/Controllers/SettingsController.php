<?php

namespace Self\Controllers;

use App\Models\Setting;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;

/**
 * Self 插件后台主页控制器
 *
 * 当前提供基础网络配置项（TLS 校验 / 超时），页面同时作为功能说明与入口导航。
 */
class SettingsController
{
    /**
     * 显示说明页
     */
    public function index()
    {
        $settings = Setting::getGroup('adapter-self');
        return view('adapter-self::settings', ['settings' => $settings]);
    }

    /**
     * 保存插件设置
     */
    public function save(Request $request)
    {
        $request->validate([
            'tls_verify' => 'nullable|in:0,1',
            'tls_insecure_fallback' => 'nullable|in:0,1',
            'http_timeout' => 'required|integer|min:5|max:120',
        ]);

        Setting::setGroup('adapter-self', [
            'tls_verify' => $request->boolean('tls_verify') ? '1' : '0',
            'tls_insecure_fallback' => $request->boolean('tls_insecure_fallback') ? '1' : '0',
            'http_timeout' => (string) $request->integer('http_timeout'),
        ]);

        app(ActivityLogService::class)->log('setting', '更新自营对接插件配置');

        return redirect()->route('admin.plugin.adapter-self')
            ->with('success', '自营对接配置已保存');
    }
}
