<?php

/**
 * Self 插件路由定义
 *
 * 规则：
 * - 全部指向 Controller 方法
 * - 不使用闭包
 */

use Illuminate\Support\Facades\Route;

// ==================== 后台路由 ====================

Route::prefix('admin')
    ->middleware('admin.auth')
    ->group(function () {
        Route::get('/plugin/adapter-self', [\Self\Controllers\SettingsController::class, 'index'])
            ->name('admin.plugin.adapter-self');

        Route::get('/plugin/adapter-self/orders', [\Self\Controllers\SelfOrderController::class, 'index'])
            ->name('admin.plugin.adapter-self.orders');

        Route::post('/plugin/adapter-self/orders/update-status', [\Self\Controllers\SelfOrderController::class, 'updateStatus'])
            ->name('admin.plugin.adapter-self.orders.update-status');
    });

// ==================== 前端 AJAX 路由 ====================

Route::prefix('ajax/plugin/adapter-self')
    ->middleware('throttle:20,1')
    ->group(function () {
        Route::post('/courses', [\Self\Controllers\CourseController::class, 'getCourses'])
            ->name('ajax.plugin.adapter-self.courses');
    });
