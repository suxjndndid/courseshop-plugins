<?php

/**
 * Self 插件路由定义
 *
 * 规则：
 * - 全部指向 Controller 方法
 * - 不使用闭包
 */

use Self\Controllers\CourseController;
use Self\Controllers\SelfOrderController;
use Self\Controllers\SettingsController;
use Illuminate\Support\Facades\Route;

// ==================== 后台路由 ====================

admin_route_group(function () {
    Route::get('/plugin/adapter-self', [SettingsController::class, 'index'])
        ->name('admin.plugin.adapter-self');
    Route::post('/plugin/adapter-self', [SettingsController::class, 'save'])
        ->name('admin.plugin.adapter-self.save');

    Route::get('/plugin/adapter-self/orders', [SelfOrderController::class, 'index'])
        ->name('admin.plugin.adapter-self.orders');

    Route::post('/plugin/adapter-self/orders/update-status', [SelfOrderController::class, 'updateStatus'])
        ->name('admin.plugin.adapter-self.orders.update-status');
});

// ==================== 前端 AJAX 路由 ====================

Route::prefix('ajax/plugin/adapter-self')
    ->middleware('throttle:20,1')
    ->group(function () {
        Route::post('/courses', [CourseController::class, 'getCourses'])
            ->name('ajax.plugin.adapter-self.courses');
    });
