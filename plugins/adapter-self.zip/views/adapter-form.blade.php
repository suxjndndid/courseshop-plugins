{{--
    Self 插件下单表单
    由 SelfPlugin::renderAdapterForm() 注入
    变量：$productId, $handlerKey, $coursesRoute, $unitPrice, $adapterJsUrl
--}}

<div class="adapter-form-self" id="adapterFormSelf">
    <div class="mb-3">
        <label class="form-label fw-semibold">
            <i class="bi bi-person-circle me-1"></i>学习账号 <span class="text-danger">*</span>
        </label>
        <input type="text"
               id="selfStudyUsername"
               name="study_username"
               class="form-control"
               data-adapter-field="study_username"
               placeholder="请输入学习平台账号"
               required
               autocomplete="username">
    </div>

    <div class="mb-3">
        <label class="form-label fw-semibold">
            <i class="bi bi-lock-fill me-1"></i>学习密码 <span class="text-danger">*</span>
        </label>
        <input type="password"
               id="selfStudyPassword"
               name="study_password"
               class="form-control"
               data-adapter-field="study_password"
               placeholder="请输入学习平台密码"
               required
               autocomplete="current-password">
    </div>

    <input type="hidden" name="course_payload" id="selfCoursePayload" data-adapter-field="course_payload" value="">

    <div class="mb-3">
        <button type="button" id="selfFetchCoursesBtn" class="btn btn-primary w-100">
            <i class="bi bi-search me-1"></i>查询业务信息
        </button>
    </div>

    <div id="selfCourseResult" class="border rounded p-3 bg-light" style="display:none;"></div>
</div>

<script>
window.__ADAPTER_SELF_CONFIG__ = {
    productId: {{ $productId }},
    handlerKey: '{{ $handlerKey }}',
    coursesRoute: '{{ $coursesRoute }}',
    unitPrice: {{ $unitPrice }}
};
</script>
<script src="{{ $adapterJsUrl }}"></script>
