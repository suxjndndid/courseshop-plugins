{{--
    Self 插件下单表单
    由 SelfPlugin::renderAdapterForm() 注入
    变量：$productId, $handlerKey, $coursesRoute, $unitPrice, $adapterJsUrl
--}}

<div class="adapter-form-self" id="adapterFormSelf">
    <div class="mb-3">
        <label class="form-label fw-semibold">
            <i class="bi bi-person-circle me-1"></i>学习账号 <span class="text-danger">*</span>
        </label>
        <input type="text"
               id="selfStudyUsername"
               name="study_username"
               class="form-control"
               data-adapter-field="study_username"
               placeholder="请输入学习平台账号"
               required
               autocomplete="username">
    </div>

    <div class="mb-3">
        <label class="form-label fw-semibold">
            <i class="bi bi-lock-fill me-1"></i>学习密码 <span class="text-danger">*</span>
        </label>
        <div class="input-group password-input-group">
            <input type="password"
                   id="selfStudyPassword"
                   name="study_password"
                   class="form-control"
                   data-adapter-field="study_password"
                   placeholder="请输入学习平台密码"
                   required
                   autocomplete="current-password">
            <button type="button" class="btn btn-toggle-password" onclick="toggleSelfPasswordVisibility()">
                <i class="bi bi-eye" id="toggleSelfPasswordIcon"></i>
            </button>
        </div>
    </div>

    <input type="hidden" name="course_payload" id="selfCoursePayload" data-adapter-field="course_payload" value="">

    <div class="mb-3">
        <button type="button" id="selfFetchCoursesBtn" class="btn btn-primary w-100 mt-2">
            <i class="bi bi-search me-1"></i>查询业务信息
        </button>
    </div>

    <div id="selfCourseResult" class="border rounded p-3 bg-light" style="display:none;"></div>
</div>

<script>
window.__ADAPTER_SELF_CONFIG__ = {
    productId: {{ $productId }},
    handlerKey: '{{ $handlerKey }}',
    coursesRoute: '{{ $coursesRoute }}',
    unitPrice: {{ $unitPrice }}
};

/**
 * 切换自营商品密码可见性
 */
function toggleSelfPasswordVisibility() {
    const passwordInput = document.getElementById('selfStudyPassword');
    const toggleIcon = document.getElementById('toggleSelfPasswordIcon');
    if (!passwordInput || !toggleIcon) return;

    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleIcon.classList.remove('bi-eye');
        toggleIcon.classList.add('bi-eye-slash');
    } else {
        passwordInput.type = 'password';
        toggleIcon.classList.remove('bi-eye-slash');
        toggleIcon.classList.add('bi-eye');
    }
}
</script>
<script src="{{ $adapterJsUrl }}"></script>
