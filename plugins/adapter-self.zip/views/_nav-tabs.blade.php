{{--
    Self 插件页面内 Tab 导航
    接收变量：$currentTab ('settings' | 'orders')
--}}
<div class="mb-6 border-b border-gray-200">
    <nav class="flex space-x-6" aria-label="插件导航">
        <a href="{{ route('admin.plugin.adapter-self') }}" wire:navigate
           class="inline-flex items-center px-1 pb-3 text-sm font-medium border-b-2 transition-colors
                  {{ $currentTab === 'settings'
                     ? 'border-indigo-500 text-indigo-600'
                     : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' }}">
            插件说明
        </a>
        <a href="{{ route('admin.plugin.adapter-self.orders') }}" wire:navigate
           class="inline-flex items-center px-1 pb-3 text-sm font-medium border-b-2 transition-colors
                  {{ $currentTab === 'orders'
                     ? 'border-indigo-500 text-indigo-600'
                     : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' }}">
            自营订单
        </a>
    </nav>
</div>
