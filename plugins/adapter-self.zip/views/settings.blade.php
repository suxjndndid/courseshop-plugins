@extends('admin.layouts.app')

@section('title', '自营对接说明')

@section('content')
@include('adapter-self::_nav-tabs', ['currentTab' => 'settings'])

<div class="max-w-3xl mx-auto">
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 class="text-xl font-semibold mb-4">Self 插件使用说明</h2>

        <div class="text-sm text-gray-700 space-y-3 leading-relaxed">
            <p>当前版本采用轻量方案：仅支持账号/密码查询、下单数据 JSON 落库、管理员手动处理状态。</p>
            <p>商品分支按 <code>product_id</code> 和 <code>products.meta.handler_key</code> 区分，无二级插件体系。</p>
            <p>支付成功后会自动给管理员发一条内部通知（类型：<code>order.self_paid</code>）。</p>
        </div>

        <div class="mt-6 bg-gray-50 rounded-lg p-4">
            <h3 class="font-medium text-gray-800 mb-2">商品配置要求</h3>
            <ol class="list-decimal list-inside text-sm text-gray-600 space-y-1">
                <li>商品类型选择 <code>自营对接 (self)</code></li>
                <li>在商品 Meta 中填写 <code>handler_key</code>（例如 1 或 2）</li>
                <li>前台下单时输入账号密码并点击“查询业务信息”后提交</li>
            </ol>
        </div>
    </div>
</div>
@endsection
