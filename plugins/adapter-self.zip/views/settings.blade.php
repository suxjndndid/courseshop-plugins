@extends('admin.layouts.app')

@section('title', '自营对接说明')

@section('content')
@include('adapter-self::_nav-tabs', ['currentTab' => 'settings'])

<div class="max-w-3xl mx-auto">
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 class="text-xl font-semibold mb-4">Self 插件使用说明</h2>

        @if(session('success'))
            <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded mb-4">
                {{ session('success') }}
            </div>
        @endif

        @if($errors->any())
            <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
                @foreach($errors->all() as $error)
                    <p>{{ $error }}</p>
                @endforeach
            </div>
        @endif

        <div class="text-sm text-gray-700 space-y-3 leading-relaxed">
            <p>当前版本采用轻量方案：仅支持账号/密码查询、下单数据 JSON 落库、管理员手动处理状态。</p>
            <p>商品分支按 <code>product_id</code> 和 <code>products.meta.handler_key</code> 区分，无二级插件体系。</p>
            <p>支付成功后会自动给管理员发一条内部通知（类型：<code>order.self_paid</code>）。</p>
        </div>

        <form action="{{ route('admin.plugin.adapter-self.save') }}" method="POST" class="mt-6 border-t border-gray-200 pt-6">
            @csrf
            <h3 class="font-medium text-gray-800 mb-3">网络请求配置</h3>

            <div class="space-y-3 text-sm">
                <label class="flex items-start gap-2">
                    <input type="checkbox"
                           name="tls_verify"
                           value="1"
                           class="mt-0.5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                           @checked((string) ($settings['tls_verify'] ?? '1') === '1')>
                    <span>
                        <span class="font-medium text-gray-800">启用 TLS 证书校验（推荐）</span><br>
                        <span class="text-gray-500">开启后会严格验证 HTTPS 证书链，安全性更高。</span>
                    </span>
                </label>

                <label class="flex items-start gap-2">
                    <input type="checkbox"
                           name="tls_insecure_fallback"
                           value="1"
                           class="mt-0.5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                           @checked((string) ($settings['tls_insecure_fallback'] ?? '1') === '1')>
                    <span>
                        <span class="font-medium text-gray-800">证书失败时自动降级重试一次</span><br>
                        <span class="text-gray-500">仅在 TLS 校验失败时触发，便于兼容证书链不完整的目标服务。</span>
                    </span>
                </label>
            </div>

            <div class="mt-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">请求超时（秒）</label>
                <input type="number"
                       name="http_timeout"
                       min="5"
                       max="120"
                       required
                       value="{{ (int) ($settings['http_timeout'] ?? 20) }}"
                       class="w-full max-w-xs px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500">
            </div>

            <div class="mt-4">
                <button type="submit"
                        class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors">
                    保存配置
                </button>
            </div>
        </form>

        <div class="mt-6 bg-gray-50 rounded-lg p-4">
            <h3 class="font-medium text-gray-800 mb-2">商品配置要求</h3>
            <ol class="list-decimal list-inside text-sm text-gray-600 space-y-1">
                <li>商品类型选择 <code>自营对接 (self)</code></li>
                <li>在商品 Meta 中填写 <code>handler_key</code>（例如 1 或 2）</li>
                <li>前台下单时输入账号密码并点击“查询业务信息”后提交</li>
            </ol>
        </div>
    </div>
</div>
@endsection
