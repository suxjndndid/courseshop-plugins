{{--
    Self 插件：后台商品 Meta 配置片段
    由 Hook admin.product.meta_form 注入
--}}
<div class="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
    <h4 class="text-sm font-medium text-emerald-800 mb-3">
        <svg class="inline w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
        </svg>
        自营对接配置
    </h4>
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">
            业务标识 (handler_key) <span class="text-red-500">*</span>
        </label>
        <input type="text" wire:model="form_meta.handler_key"
               placeholder="例如：1 或 2"
               class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none">
        <p class="text-xs text-gray-500 mt-1">用于 Self 插件按业务分支处理（当前版本通常填 1/2）</p>
    </div>
</div>
