@extends('admin.layouts.app')

@section('title', '自营订单管理')

@section('content')
@include('adapter-self::_nav-tabs', ['currentTab' => 'orders'])

<div class="container mx-auto px-4 py-6"
     x-data="selfOrderPage()"
     x-init="init()">
    <h2 class="text-xl font-bold text-gray-800 mb-4">自营订单管理</h2>

    <div class="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
        <div class="bg-white rounded-lg shadow p-4 text-center">
            <div class="text-2xl font-bold text-gray-800">{{ $stats['total'] }}</div>
            <div class="text-sm text-gray-500">总订单</div>
        </div>
        <div class="bg-white rounded-lg shadow p-4 text-center border-t-2 border-gray-500">
            <div class="text-2xl font-bold text-gray-700">{{ $stats['pending'] }}</div>
            <div class="text-sm text-gray-500">待处理</div>
        </div>
        <div class="bg-white rounded-lg shadow p-4 text-center border-t-2 border-blue-500">
            <div class="text-2xl font-bold text-blue-600">{{ $stats['processing'] }}</div>
            <div class="text-sm text-gray-500">进行中</div>
        </div>
        <div class="bg-white rounded-lg shadow p-4 text-center border-t-2 border-green-500">
            <div class="text-2xl font-bold text-green-600">{{ $stats['completed'] }}</div>
            <div class="text-sm text-gray-500">已完成</div>
        </div>
        <div class="bg-white rounded-lg shadow p-4 text-center border-t-2 border-red-500">
            <div class="text-2xl font-bold text-red-600">{{ $stats['failed'] }}</div>
            <div class="text-sm text-gray-500">失败</div>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow p-4 mb-4">
        <form method="GET" class="flex flex-wrap gap-3 items-end">
            <div class="flex-1 min-w-[200px]">
                <label class="block text-sm text-gray-600 mb-1">关键字</label>
                <input type="text" name="keyword" value="{{ $filters['keyword'] }}"
                       placeholder="账号 / handler_key / product_id"
                       class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
            </div>
            <div>
                <label class="block text-sm text-gray-600 mb-1">商品 ID</label>
                <select name="product_id" class="px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
                    <option value="">全部</option>
                    @foreach($productIds as $pid)
                        <option value="{{ $pid }}" {{ (string)$filters['product_id'] === (string)$pid ? 'selected' : '' }}>
                            {{ $pid }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="block text-sm text-gray-600 mb-1">状态</label>
                <select name="status" class="px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
                    <option value="">全部</option>
                    <option value="pending" {{ $filters['status'] === 'pending' ? 'selected' : '' }}>待处理</option>
                    <option value="processing" {{ $filters['status'] === 'processing' ? 'selected' : '' }}>进行中</option>
                    <option value="completed" {{ $filters['status'] === 'completed' ? 'selected' : '' }}>已完成</option>
                    <option value="failed" {{ $filters['status'] === 'failed' ? 'selected' : '' }}>失败</option>
                </select>
            </div>
            <button type="submit" class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">筛选</button>
            <a href="{{ route('admin.plugin.adapter-self.orders') }}" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">重置</a>
        </form>
    </div>

    <div class="bg-white rounded-lg shadow overflow-x-auto">
        <table class="min-w-max w-full text-sm">
            <thead class="bg-gray-50 text-gray-600 uppercase text-xs">
                <tr>
                    <th class="px-4 py-3 text-left">ID</th>
                    <th class="px-4 py-3 text-left">商品ID</th>
                    <th class="px-4 py-3 text-left">账号</th>
                    <th class="px-4 py-3 text-left">业务标识</th>
                    <th class="px-4 py-3 text-left">状态</th>
                    <th class="px-4 py-3 text-left">支付订单</th>
                    <th class="px-4 py-3 text-left">失败原因</th>
                    <th class="px-4 py-3 text-left">操作</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                @forelse($selfOrders as $so)
                    <tr id="row-{{ $so->id }}">
                        <td class="px-4 py-3 text-gray-500">{{ $so->id }}</td>
                        <td class="px-4 py-3">{{ $so->product_id }}</td>
                        <td class="px-4 py-3">{{ $so->study_username }}</td>
                        <td class="px-4 py-3">{{ $so->handler_key ?: '-' }}</td>
                        <td class="px-4 py-3">
                            @switch($so->order_status)
                                @case('completed')
                                    <span class="px-2 py-0.5 rounded-full text-xs bg-green-100 text-green-700">已完成</span>
                                    @break
                                @case('processing')
                                    <span class="px-2 py-0.5 rounded-full text-xs bg-blue-100 text-blue-700">进行中</span>
                                    @break
                                @case('failed')
                                    <span class="px-2 py-0.5 rounded-full text-xs bg-red-100 text-red-700">失败</span>
                                    @break
                                @default
                                    <span class="px-2 py-0.5 rounded-full text-xs bg-gray-100 text-gray-700">待处理</span>
                            @endswitch
                        </td>
                        <td class="px-4 py-3">
                            <code class="text-xs">{{ $so->paymentOrder->order_no ?? '-' }}</code>
                        </td>
                        <td class="px-4 py-3 text-red-600">{{ $so->failed_reason ?: '-' }}</td>
                        <td class="px-4 py-3">
                            <div class="flex gap-1">
                                <button type="button"
                                        class="text-xs px-2 py-1 bg-indigo-50 text-indigo-600 rounded hover:bg-indigo-100"
                                        @click="openStatusModal(@js([
                                            'id' => $so->id,
                                            'status' => $so->order_status,
                                            'failed_reason' => $so->failed_reason,
                                            'admin_remark' => $so->admin_remark,
                                        ]))">更新状态</button>
                                <button type="button"
                                        class="text-xs px-2 py-1 bg-gray-50 text-gray-600 rounded hover:bg-gray-100"
                                        @click="showDetail(@js($so->toArray()))">详情</button>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="8" class="px-4 py-8 text-center text-gray-400">暂无自营订单</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $selfOrders->withQueryString()->links() }}
    </div>

    {{-- ==================== 详情弹窗 ==================== --}}
    <div x-show="detailOpen" x-cloak
         class="fixed inset-0 z-50 flex items-center justify-center"
         @keydown.escape.window="detailOpen = false">
        <div class="fixed inset-0 bg-black/50" @click="detailOpen = false"></div>
        <div class="relative bg-white rounded-xl shadow-2xl w-full max-w-lg mx-4 max-h-[85vh] overflow-y-auto"
             x-transition>
            <div class="flex items-center justify-between px-6 py-4 border-b">
                <h3 class="text-lg font-semibold text-gray-800">订单详情</h3>
                <button @click="detailOpen = false" class="text-gray-400 hover:text-gray-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>
            <div class="px-6 py-4 space-y-3">
                <template x-if="detail">
                    <div class="space-y-3">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <p class="text-xs text-gray-500">ID</p>
                                <p class="font-mono text-sm" x-text="detail.id"></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500">状态</p>
                                <p class="text-sm font-semibold" x-text="statusText(detail.order_status)"></p>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <p class="text-xs text-gray-500">商品 ID</p>
                                <p class="font-mono text-sm" x-text="detail.product_id"></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500">业务标识 (handler_key)</p>
                                <p class="font-mono text-sm" x-text="detail.handler_key || '-'"></p>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <p class="text-xs text-gray-500">学习账号</p>
                                <p class="font-mono text-sm" x-text="detail.study_username"></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500">学习密码</p>
                                <div class="flex items-center gap-1">
                                    <p class="font-mono text-sm" x-text="showPwd ? detail.study_password : '••••••••'"></p>
                                    <button @click="showPwd = !showPwd" class="text-gray-400 hover:text-gray-600">
                                        <svg x-show="!showPwd" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                        <svg x-show="showPwd" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L6.59 6.59m7.532 7.532l3.29 3.29M3 3l18 18"/></svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div>
                            <p class="text-xs text-gray-500">支付订单 ID</p>
                            <p class="font-mono text-xs" x-text="detail.payment_order_id || '-'"></p>
                        </div>
                        <template x-if="detail.order_payload && Object.keys(detail.order_payload).length">
                            <div class="bg-gray-50 rounded-lg p-3">
                                <p class="text-xs text-gray-500 font-semibold mb-2">下单数据 (order_payload)</p>
                                <pre class="text-xs text-gray-700 whitespace-pre-wrap break-all" x-text="JSON.stringify(detail.order_payload, null, 2)"></pre>
                            </div>
                        </template>
                        <template x-if="detail.result_payload && Object.keys(detail.result_payload).length">
                            <div class="bg-blue-50 rounded-lg p-3">
                                <p class="text-xs text-blue-500 font-semibold mb-2">处理结果 (result_payload)</p>
                                <pre class="text-xs text-blue-700 whitespace-pre-wrap break-all" x-text="JSON.stringify(detail.result_payload, null, 2)"></pre>
                            </div>
                        </template>
                        <template x-if="detail.failed_reason">
                            <div class="bg-red-50 rounded-lg p-3">
                                <p class="text-xs text-red-500 font-semibold mb-1">失败原因</p>
                                <p class="text-sm text-red-700" x-text="detail.failed_reason"></p>
                            </div>
                        </template>
                        <template x-if="detail.admin_remark">
                            <div class="bg-amber-50 rounded-lg p-3">
                                <p class="text-xs text-amber-500 font-semibold mb-1">后台备注</p>
                                <p class="text-sm text-amber-700" x-text="detail.admin_remark"></p>
                            </div>
                        </template>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <p class="text-xs text-gray-500">创建时间</p>
                                <p class="text-sm" x-text="detail.created_at || '-'"></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500">处理时间</p>
                                <p class="text-sm" x-text="detail.processed_at || '-'"></p>
                            </div>
                        </div>
                    </div>
                </template>
            </div>
            <div class="px-6 py-3 border-t bg-gray-50 rounded-b-xl flex justify-end">
                <button @click="detailOpen = false" class="px-4 py-2 text-sm bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">关闭</button>
            </div>
        </div>
    </div>

    {{-- ==================== 更新状态弹窗 ==================== --}}
    <div x-show="modalOpen" x-cloak class="fixed inset-0 z-50 flex items-center justify-center">
        <div class="fixed inset-0 bg-black/50" @click="modalOpen = false"></div>
        <div class="relative bg-white rounded-xl shadow-2xl w-full max-w-lg mx-4 p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">更新自营订单状态</h3>

            <div class="space-y-3">
                <div>
                    <label class="block text-sm text-gray-600 mb-1">状态</label>
                    <select x-model="form.status" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
                        <option value="pending">待处理</option>
                        <option value="processing">进行中</option>
                        <option value="completed">已完成</option>
                        <option value="failed">失败</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm text-gray-600 mb-1">失败原因（状态=失败时必填）</label>
                    <textarea x-model="form.failed_reason" rows="3"
                              class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"></textarea>
                </div>

                <div>
                    <label class="block text-sm text-gray-600 mb-1">后台备注</label>
                    <textarea x-model="form.admin_remark" rows="3"
                              class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"></textarea>
                </div>
            </div>

            <div class="mt-6 flex justify-end gap-2">
                <button type="button" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300" @click="modalOpen = false">
                    取消
                </button>
                <button type="button" class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700" @click="submitUpdate()">
                    保存
                </button>
            </div>
        </div>
    </div>
</div>

<script>
(function() {
    function register() {
        Alpine.data('selfOrderPage', () => ({
        modalOpen: false,
        detailOpen: false,
        detail: null,
        showPwd: false,
        form: {
            id: null,
            status: 'pending',
            failed_reason: '',
            admin_remark: ''
        },
        CSRF: document.querySelector('meta[name="csrf-token"]')?.content || '',
        updateRoute: @json(route('admin.plugin.adapter-self.orders.update-status')),

        init() {},

        statusText(s) {
            return { pending: '待处理', processing: '进行中', completed: '已完成', failed: '失败' }[s] || s;
        },

        showDetail(data) {
            this.detail = data;
            this.showPwd = false;
            this.detailOpen = true;
        },

        openStatusModal(data) {
            this.form.id = data.id;
            this.form.status = data.status || 'pending';
            this.form.failed_reason = data.failed_reason || '';
            this.form.admin_remark = data.admin_remark || '';
            this.modalOpen = true;
        },

        async submitUpdate() {
            const resp = await fetch(this.updateRoute, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': this.CSRF
                },
                body: JSON.stringify(this.form)
            });
            const result = await resp.json();

            if (!result.success) {
                alert(result.message || '更新失败');
                return;
            }

            this.modalOpen = false;
            location.reload();
        }
    }));
    }
    if (window.Alpine) { register(); } else { document.addEventListener('alpine:init', register); }
})();
</script>
@endsection
