<?php

use App\Core\Contracts\FrontendThemeInterface;
use App\Core\Hook\Hook;
use App\Core\Plugin\PluginInterface;
use App\Core\Plugin\PluginType;
use App\Services\FrontendThemeService;

class AuroraThemePlugin implements PluginInterface, FrontendThemeInterface
{
    public function id(): string
    {
        return 'theme-aurora';
    }

    public function name(): string
    {
        return '极光玻璃主题';
    }

    public function version(): string
    {
        return '1.0.0';
    }

    public function type(): PluginType
    {
        return PluginType::Theme;
    }

    public function register(): void
    {
        app('view')->addNamespace('theme-aurora', dirname(__FILE__) . '/views');
    }

    public function boot(): void
    {
        Hook::addFilter('frontend.head', function (string $html): string {
            if (!app(FrontendThemeService::class)->isActiveTheme($this->id())) {
                return $html;
            }

            return $html . "\n" . view('theme-aurora::styles.shared')->render() . "\n";
        }, 10);
    }

    public function uninstall(): void
    {
    }

    public function config(): array
    {
        return [];
    }

    public function requires(): array
    {
        return ['core' => '>=1.0'];
    }

    public function frontendThemeLabel(): string
    {
        return '极光玻璃';
    }

    public function frontendThemeDescription(): string
    {
        return '冷色渐层和通透面板会让整个页面更轻盈，氛围感也更明显。';
    }

    public function frontendThemeOrder(): int
    {
        return 50;
    }
}
