<style>
@include('theme-aurora::styles.fragments.shell')
@include('theme-aurora::styles.fragments.catalog')
@include('theme-aurora::styles.fragments.detail')
@include('theme-aurora::styles.fragments.query')
@include('theme-aurora::styles.fragments.overrides')
</style>
