body.frontend-body .frontend-brand,
body.frontend-body .brutal-hero-title,
body.frontend-body .brutal-section-title,
body.frontend-body .brutal-panel-title,
body.frontend-body .results-head h2,
body.frontend-body .brutal-query-title-bar h1,
body.frontend-body .payment-wait-title,
body.frontend-body .payment-redirect-title {
    letter-spacing: -0.02em;
}

body.frontend-body .frontend-brand-mark,
body.frontend-body .frontend-footer-mark,
body.frontend-body .frontend-nav-toggle,
body.frontend-body .frontend-theme-switcher-trigger,
body.frontend-body .frontend-theme-switcher-panel,
body.frontend-body .frontend-theme-switcher-close,
body.frontend-body .frontend-theme-option,
body.frontend-body .custom-toast,
body.frontend-body .confirm-dialog,
body.frontend-body .confirm-btn,
body.frontend-body .brutal-home-hero,
body.frontend-body .brutal-hitokoto-box,
body.frontend-body .brutal-announcement-strip,
body.frontend-body .brutal-query-title-bar,
body.frontend-body .brutal-query-shell,
body.frontend-body .results-shell,
body.frontend-body .brutal-detail-ticker,
body.frontend-body .brutal-product-hero,
body.frontend-body .brutal-hero-media,
body.frontend-body .brutal-panel,
body.frontend-body .brutal-detail-block,
body.frontend-body .brutal-price-card,
body.frontend-body .brutal-status-card,
body.frontend-body .brutal-price-breakdown,
body.frontend-body .query-help,
body.frontend-body .order-card,
body.frontend-body .order-remarks,
body.frontend-body .payment-redirect-card,
body.frontend-body .payment-wait-card,
body.frontend-body .payment-wait-meta,
body.frontend-body .payment-wait-status,
body.frontend-body .brutal-product,
body.frontend-body .brutal-biz-result,
body.frontend-body .brutal-chip,
body.frontend-body .frontend-pagination .page-link,
body.frontend-body .query-tab,
body.frontend-body .brutal-input,
body.frontend-body .brutal-textarea,
body.frontend-body .query-input,
body.frontend-body #product-adapter-ui .form-control,
body.frontend-body .brutal-button,
body.frontend-body .brutal-ghost-button,
body.frontend-body .query-btn,
body.frontend-body .clear-btn,
body.frontend-body .brutal-submit-btn,
body.frontend-body .brutal-coupon-btn,
body.frontend-body .brutal-buy-btn,
body.frontend-body .payment-wait-button,
body.frontend-body #product-adapter-ui .btn,
body.frontend-body .order-actions .btn,
body.frontend-body .course-card-body,
body.frontend-body .course-card-check,
body.frontend-body #selfCourseResult {
    border-color: var(--theme-line) !important;
    background: linear-gradient(180deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.04)) !important;
    box-shadow: var(--theme-shadow-sm) !important;
    backdrop-filter: blur(18px);
}

body.frontend-body .frontend-nav-shell,
body.frontend-body .frontend-footer-shell {
    border-color: rgba(172, 227, 255, 0.14);
}

body.frontend-body .frontend-brand-mark,
body.frontend-body .frontend-footer-mark {
    background:
        radial-gradient(circle at 30% 30%, rgba(255, 255, 255, 0.3), transparent 56%),
        linear-gradient(135deg, rgba(124, 228, 255, 0.22), rgba(255, 216, 116, 0.12)) !important;
}

body.frontend-body .frontend-theme-switcher-trigger,
body.frontend-body .frontend-theme-switcher-panel,
body.frontend-body .brutal-home-hero,
body.frontend-body .brutal-query-shell,
body.frontend-body .results-shell,
body.frontend-body .brutal-product-hero,
body.frontend-body .brutal-panel,
body.frontend-body .payment-wait-card,
body.frontend-body .payment-redirect-card {
    background:
        radial-gradient(circle at top left, rgba(124, 228, 255, 0.12), transparent 34%),
        radial-gradient(circle at top right, rgba(255, 216, 116, 0.08), transparent 28%),
        linear-gradient(180deg, rgba(255, 255, 255, 0.11), rgba(255, 255, 255, 0.04)) !important;
}

body.frontend-body .frontend-nav-link.active,
body.frontend-body .frontend-nav-link:hover,
body.frontend-body .frontend-footer-links a:hover,
body.frontend-body .frontend-theme-switcher-trigger-copy strong,
body.frontend-body .frontend-theme-switcher-trigger-action,
body.frontend-body .frontend-theme-switcher-head strong,
body.frontend-body .brutal-hitokoto-head,
body.frontend-body .brutal-announcement-btn,
body.frontend-body .brutal-announcement-title,
body.frontend-body .brutal-announcement-tag,
body.frontend-body .query-help-item strong,
body.frontend-body .brutal-product-price,
body.frontend-body .price-value,
body.frontend-body .payment-wait-badge,
body.frontend-body .payment-wait-status {
    color: var(--theme-accent) !important;
}

body.frontend-body .frontend-theme-switcher-trigger-action,
body.frontend-body .payment-wait-badge,
body.frontend-body .brutal-announcement-tag,
body.frontend-body .brutal-panel-kicker,
body.frontend-body .ticker-label,
body.frontend-body .ticker-note,
body.frontend-body .brutal-eyebrow,
body.frontend-body .count-badge {
    background: rgba(124, 228, 255, 0.16) !important;
    color: var(--theme-accent) !important;
}

body.frontend-body .brutal-button,
body.frontend-body .query-btn,
body.frontend-body .brutal-submit-btn,
body.frontend-body .payment-wait-button,
body.frontend-body .brutal-buy-btn,
body.frontend-body #product-adapter-ui .btn-primary,
body.frontend-body .btn-refresh,
body.frontend-body .confirm-btn.confirm-btn-accept {
    border: 1px solid rgba(255, 255, 255, 0.14) !important;
    background: linear-gradient(135deg, rgba(124, 228, 255, 0.96), rgba(92, 176, 255, 0.88)) !important;
    color: #081120 !important;
    box-shadow: 0 14px 30px rgba(43, 132, 214, 0.24) !important;
}

body.frontend-body .brutal-ghost-button,
body.frontend-body .clear-btn,
body.frontend-body .brutal-coupon-btn,
body.frontend-body .btn-toggle-password,
body.frontend-body #product-adapter-ui .btn,
body.frontend-body .order-actions .btn {
    border: 1px solid rgba(255, 255, 255, 0.14) !important;
    background: linear-gradient(135deg, rgba(255, 216, 116, 0.92), rgba(255, 179, 82, 0.76)) !important;
    color: #241708 !important;
}

body.frontend-body .brutal-announcement-strip {
    background:
        linear-gradient(90deg, rgba(124, 228, 255, 0.14), rgba(255, 216, 116, 0.08)),
        linear-gradient(180deg, rgba(255, 255, 255, 0.08), rgba(255, 255, 255, 0.04)) !important;
    border-left-color: rgba(124, 228, 255, 0.56);
}

body.frontend-body .brutal-announcement-btn {
    width: 28px;
    height: 28px;
    display: inline-grid;
    place-items: center;
    border: 1px solid rgba(255, 255, 255, 0.14);
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.08);
}

body.frontend-body .brutal-announcement-dot {
    background: rgba(255, 255, 255, 0.2);
}

body.frontend-body .brutal-announcement-dot.is-active {
    background: var(--theme-accent);
}

body.frontend-body .brutal-hitokoto-box,
body.frontend-body .brutal-detail-ticker,
body.frontend-body .brutal-query-title-bar,
body.frontend-body .query-help,
body.frontend-body .brutal-biz-result,
body.frontend-body .brutal-price-card,
body.frontend-body .brutal-price-breakdown,
body.frontend-body .order-header,
body.frontend-body .order-remarks,
body.frontend-body .payment-wait-meta,
body.frontend-body .payment-wait-status {
    background:
        linear-gradient(180deg, rgba(255, 255, 255, 0.09), rgba(255, 255, 255, 0.03)),
        rgba(11, 21, 47, 0.66) !important;
}

body.frontend-body .brutal-input,
body.frontend-body .brutal-textarea,
body.frontend-body .query-input,
body.frontend-body #product-adapter-ui .form-control {
    color: var(--theme-ink) !important;
}

body.frontend-body .brutal-input:focus,
body.frontend-body .brutal-textarea:focus,
body.frontend-body .query-input:focus,
body.frontend-body #product-adapter-ui .form-control:focus {
    border-color: rgba(124, 228, 255, 0.46) !important;
    box-shadow: 0 0 0 4px rgba(124, 228, 255, 0.12) !important;
}

body.frontend-body .brutal-product {
    background:
        radial-gradient(circle at top right, rgba(124, 228, 255, 0.12), transparent 28%),
        linear-gradient(180deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.04)) !important;
}

body.frontend-body .brutal-product:hover {
    border-color: rgba(124, 228, 255, 0.34) !important;
    box-shadow: var(--theme-shadow) !important;
}

body.frontend-body .remark-item,
body.frontend-body .badge-status,
body.frontend-body .course-card.selected .course-card-check {
    border-color: rgba(255, 255, 255, 0.14) !important;
}

body.frontend-body .remark-item {
    background: rgba(124, 228, 255, 0.14) !important;
    color: var(--theme-accent) !important;
}

body.frontend-body .remark-item.highlight {
    background: rgba(255, 216, 116, 0.16) !important;
    color: #ffe5a3 !important;
}

body.frontend-body .payment-wait-countdown-number {
    background: linear-gradient(135deg, rgba(124, 228, 255, 0.96), rgba(92, 176, 255, 0.86));
    color: #081120;
    box-shadow: 0 20px 40px rgba(48, 141, 255, 0.26);
}

@media (max-width: 991px) {
    body.frontend-body .brutal-home-hero,
    body.frontend-body .brutal-product-hero,
    body.frontend-body .brutal-query-shell,
    body.frontend-body .brutal-work-grid {
        grid-template-columns: 1fr;
    }

    body.frontend-body .brutal-work-grid {
        grid-template-areas:
            'buy'
            'biz';
    }

    body.frontend-body #brutal-buy-panel {
        position: static;
    }
}

@media (max-width: 720px) {
    body.frontend-body .frontend-theme-switcher-trigger,
    body.frontend-body .frontend-nav-shell {
        align-items: flex-start;
        flex-direction: column;
    }

    body.frontend-body .brutal-detail-ticker,
    body.frontend-body .brutal-price-strip,
    body.frontend-body .query-form,
    body.frontend-body .brutal-coupon-row,
    body.frontend-body .order-actions {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 575px) {
    body.frontend-body .brutal-home-hero {
        margin-top: 28px;
    }

    body.frontend-body .brutal-products-grid {
        grid-template-columns: 1fr;
    }

    body.frontend-body .frontend-footer-shell,
    body.frontend-body .frontend-footer-brand,
    body.frontend-body .frontend-footer-links {
        width: 100%;
    }
}
